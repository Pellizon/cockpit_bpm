(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.autenticacao
     * 
     * @description
     * Módulo de autenticacao da arquitetura base.
     */
    angular.module("arq-spa-base.autenticacao", ["angular-jwt"]);
})();
(function () {
    "use strict";

    angular.module("arq-spa-base.autenticacao").factory("sfAutenticador", sfAutenticador);

    sfAutenticador.$inject = ["appSettings", "sfContexto", "sfUtilitarios", "sfConectorAPI", "jwtHelper", "$q", "$timeout", "sfLogger", "$rootScope", "$window"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.autenticacao.factories:sfAutenticador
     * @module arq-spa-base.autenticacao
     * 
     * @requires $http
     * @requires appSettings
     * @requires sfUtilitarios
     * 
     * @description
     * Factory resposável pela autenticacao
    */
    function sfAutenticador(appSettings, sfContexto, sfUtilitarios, sfConectorAPI, jwtHelper, $q, $timeout, sfLogger, $rootScope, $window) {

        var renovacaoTimeoutPromise,
            timestampObtencaoUltimoToken;

        return {
            autenticar: autenticar,
            logoff: logoff
        };

        /**
         * @ngdoc method
         * @name autenticar
         *
         * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
         *  
         * @description
         * Método responsável por realizar autenticacao
         * 
         * @param {object} parametros Objeto enviado pela aplicação.
         * @param {boolean} exibirLoader Indicador se o loader deve ser exibido ou não.
        */
        function autenticar(parametros, exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfAutenticador.autenticar", "", "", "Info");

            if (angular.isDefined(renovacaoTimeoutPromise)) {
                $timeout.cancel(renovacaoTimeoutPromise);
            }

            if (angular.isDefined(parametros) && angular.isObject(parametros)) {
                var configHttp = {
                    method: "POST",
                    url: sfUtilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autenticacao/autenticar"]),
                    data: parametros
                };

                var deferred = $q.defer();

                sfConectorAPI.executar(configHttp, exibirLoader)
                    .then(tratamentoToken)
                    .catch(tratamentoErroAutenticacao);

                return deferred.promise;
            } else {
                sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.autenticar", "", "", "Info");
                throw new Error("Parâmetros não definidos");
            }

            /**
             * @ngdoc method
             * @name tratamentoToken
             *
             * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
             *  
             * @description
             * Método responsável por mandar tratar a response e resolver o retorno.
             * 
             * @param {object} response Objeto enviado pelo controlador.
            */
            function tratamentoToken(response) {
                manipulacaoToken(response);
                delete response.data.token;
                sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.autenticar", "", "", "Info");
                deferred.resolve(response);
            }

            /**
             * @ngdoc method
             * @name tratamentoErroAutenticacao
             *
             * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
             *  
             * @description
             * Método responsável por interpretar o erro e reijetar os dados para a promise.
             *
             * @param {object} response Objeto enviado pelo controlador.
             */
            function tratamentoErroAutenticacao(erro) {
                sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.autenticar", "", "", "Info");

                var ultimoToken = sfContexto.obterValorContextoSessao("token");
                if (angular.isDefined(ultimoToken) && ultimoToken !== "") {
                    tratarErroDuranteElevacaoToken(ultimoToken);
                }

                deferred.reject(erro);

                /**
                 * @ngdoc method
                 * @name tratarErroDuranteElevacaoToken
                 *
                 * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
                 *  
                 * @description
                 * Método responsável por tratar o token o timeout da renovacao do token anterior
                 */
                function tratarErroDuranteElevacaoToken(ultimoToken) {
                    var diferencaTimestamp = Date.now() - timestampObtencaoUltimoToken;
                    
                    var dataExpiracao = jwtHelper.getTokenExpirationDate(ultimoToken);
                    var dataEmissao = dataDeEmissaoToken(ultimoToken);
                    var tempoRenovacaoDefault = dataExpiracao - dataEmissao - 30000;
                    var deltaRenovacao = tempoRenovacaoDefault - diferencaTimestamp;
                    
                    if (deltaRenovacao > 0) {
                        renovacaoTimeoutPromise = $timeout(renovarToken, deltaRenovacao);
                    } else {
                        renovarToken();
                    }
                }
            }
        }

        /**
         * @ngdoc method
         * @name manipulacaoToken
         *
         * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
         *  
         * @description
         * Método responsável por manipular e realizar todas as validações do token JWT recebido.
         *
         *  @param {object} response Objeto enviado pelo controlador.
        */
        function manipulacaoToken(response) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfAutenticador.manipulacaoToken", "", "", "Info");
            var retornoJwt = response.data;
            var dataExpiracao, dataEmissao, expiracao;

            if (angular.isDefined(retornoJwt) &&
                angular.isDefined(retornoJwt.token)) {
                jwtHelper.decodeToken(retornoJwt.token);
                dataExpiracao = jwtHelper.getTokenExpirationDate(retornoJwt.token);
                dataEmissao = dataDeEmissaoToken(retornoJwt.token);

                if (dataExpiracao === null ||
                    dataEmissao === null ||
                    isNaN(dataExpiracao.getTime()) ||
                    isNaN(dataEmissao.getTime())) {
                    sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.manipulacaoToken", "", "", "Info");
                    throw new Error("Erro ao obter data de Emissão/Expiracao do Token.");
                } else {
                    expiracao = dataExpiracao - dataEmissao - 30000;
                    if (expiracao <= 0) {
                        sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.manipulacaoToken", "", "", "Info");
                        throw new Error("O tempo de expiração não pode ser menor ou igual a 1 minuto.");
                    }
                }

                timestampObtencaoUltimoToken = Date.now();
                renovacaoTimeoutPromise = $timeout(renovarToken, expiracao);
                sfContexto.definirValorContextoSessao("token", retornoJwt.token);
                $rootScope.$broadcast("eventoAutenticacaoFinalizada");

                if ("workId" in retornoJwt) {
                    sfContexto.definirValorContextoTrabalho("IdTrabalho", retornoJwt.workId);
                } else {
                    var idTrabalho = new $window.Chance().guid();
                    sfContexto.definirValorContextoTrabalho("IdTrabalho", idTrabalho);
                }

                sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.manipulacaoToken", "", "", "Info");
            } else {
                sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.manipulacaoToken", "", "", "Info");
                throw new Error("O token da autenticação não está definido.");
            }

        }

        /**
         * @ngdoc method
         * @name renovarToken
         *
         * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
         *  
         * @description 
         * Método responsável por renovar o token assim que o tempo de expiração for atingido.
        */
        function renovarToken() {
            sfLogger.escreverLogExecucao("Início de execução.", "sfAutenticador.renovarToken", "", "", "Info");

            var configHttp = {
                method: "POST",
                url: sfUtilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autenticacao/renovar"]),
                data: {
                    token: sfContexto.obterValorContextoSessao("token")
                }
            };

            sfConectorAPI.executar(configHttp, false)
                .then(manipulacaoToken)
                .catch(erroRenovacao);
        }

        /**
         * @ngdoc method
         * @name erroRenovacao
         *
         * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
         *  
         * @description
         * Método responsável por interpretar o erro (da renovação) e dar raise em um throw.
         * 
         * @param {object} response Objeto enviado pelo controlador.
        */
        function erroRenovacao(erro) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfAutenticador.erroRenovacao", "", "", "Info");
            if (erro.status === 480) { //Limite de renovação excedido.
                $rootScope.$broadcast("eventoExpiracaoSessaoPermanencia", sfContexto.obterValorContextoTrabalho("IdTrabalho"));
            } else {
                sfLogger.escreverLogExecucao("Fim de execução.", "sfAutenticador.erroRenovacao", "", "", "Info");
                
                var mensagem = "Erro inesperado durante a renovação do JWT.";
                if (erro.data) {
                    mensagem = "Erro inesperado ao renovar token\n httpStatus: " + erro.data.code + " mensagem: " + erro.data.message;
                }
                throw new Error(mensagem);
            }
        }

        /**
         * @ngdoc method
         * @name dataDeEmissaoToken
         *
         * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
         *  
         * @description
         * Método responsável por interpretar a data de emissão do token (iat).
         * 
         * @param {object} token Objeto enviado pela funcao tratamentoToken.
        */
        function dataDeEmissaoToken(token) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfAutenticador.dataDeEmissaoToken", "", "", "Info");

            var decoded = jwtHelper.decodeToken(token);

            if (typeof decoded.iat === "undefined") {
                return null;
            }

            var d = new Date(0);
            d.setUTCSeconds(decoded.iat);

            sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.dataDeEmissaoToken", "", "", "Info");

            return d;
        }

        /**
         * @ngdoc method
         * @name logoff
         *
         * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
         *  
         * @description
         * Método responsável por realizar o logoff da aplicação
         * 
         * @param {boolean} exibirLoader Indicador se o loader deve ser exibido ou não.
        */
        function logoff(exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfAutenticador.logoff", "", "", "Info");
            var erro, sucesso;

            if (angular.isDefined(renovacaoTimeoutPromise)) {
                $timeout.cancel(renovacaoTimeoutPromise);
            }

            var deferred = $q.defer();

            if (angular.isUndefined(sfContexto.obterValorContextoSessao("token"))
                || sfContexto.obterValorContextoSessao("token") === "") {
                deferred.reject({});
                return deferred.promise;
            }

            var configHttp = {
                method: "POST",
                url: sfUtilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "autenticacao/cancelar"]),
                data: {
                    token: sfContexto.obterValorContextoSessao("token")
                }
            };

            sfConectorAPI.executar(configHttp, exibirLoader)
                .then(sucessoLogoff)
                .catch(erroLogoff)
                .finally(posExecutarLogoff);


            sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.logoff", "", "", "Info");
            return deferred.promise;

            /**
             * @ngdoc method
             * @name sucessoLogoff
             *
             * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
             *  
             * @description
             * Método responsável por remover o token de contexto e resolver a promise.
             * 
             * @param {object} response Objeto enviado pelo controlador.
            */
            function sucessoLogoff(response) {
                sfLogger.escreverLogExecucao("Início de execução.", "sfAutenticador.sucessoLogoff", "", "", "Info");

                if (!angular.isDefined(appSettings.configuracao.limparContextoTrabalhoLogoff)
                    || appSettings.configuracao.limparContextoTrabalhoLogoff !== false) {
                    sfContexto.reiniciarContextoTrabalho();
                }

                sucesso = response;

                sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.sucessoLogoff", "", "", "Info");
            }

            /**
             * @ngdoc method
             * @name erroLogoff
             *
             * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
             *  
             * @description
             * Método responsável por interpretar o erro do logoff e reijetar os dados para a promise.
             *
             * @param {object} response Objeto enviado pelo controlador.
            */
            function erroLogoff(err) {
                sfLogger.escreverLogExecucao("Início de execução.", "sfAutenticador.erroLogoff", "", "", "Info");

                erro = err;

                sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.erroLogoff", "", "", "Info");
            }

            /**
             * @ngdoc method
             * @name posExecutarLogoff
             *
             * @methodOf arq-spa-base.autenticacao.factories:sfAutenticador
             *  
             * @description
             * Método responsável por executar os passos pós-execução do logoff
             *
            */
            function posExecutarLogoff() {
                sfLogger.escreverLogExecucao("Início de execução.", "sfAutenticador.posExecutarLogoff", "", "", "Info");

                sfContexto.definirValorContextoSessao("token", "");
                if (angular.isDefined(sucesso)) {
                    deferred.resolve(sucesso);
                } else {
                    deferred.reject(erro);
                }


                sfLogger.escreverLogExecucao("Término de execução.", "sfAutenticador.posExecutarLogoff", "", "", "Info");

            }


        }
    }
})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.comunicacao
     * 
     * @require $httpProvider
     * 
     * @description
     * Módulo de comunicação da arquitetura base que provê os recursos necessários para configuração e execução de comunicações com o APIs.
     */
    angular.module("arq-spa-base.comunicacao", [
        "arq-spa-base.logging",
        "arq-spa-base.recursos",
        "arq-spa-base.controles-visuais",
        "arq-spa-base.criptografia"
    ]).config(gerenciadorComunicacao);
    
    gerenciadorComunicacao.$inject = ["$httpProvider"];
    
    /**
     * @ngdoc overview
     * @name arq-spa-base.comunicacao
     * 
     * @require $httpProvider
     * 
     * @description
     * Funçao de comunicação da arquitetura base que provê os recursos necessários para configuração e execução de comunicações com o APIs.
     */
    function gerenciadorComunicacao($httpProvider) {
        $httpProvider.interceptors.push("gerenciadorComunicacao");
    }
})();
(function () {
    "use strict";

    angular.module("arq-spa-base.comunicacao").factory("sfHeadersArquitetura", sfHeadersArquitetura);

    sfHeadersArquitetura.$inject = ["sfContexto", "$window", "appSettings"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.comunicacao.factories:sfHeadersArquitetura
     * @module arq-spa-base.comunicacao
     * 
     * @requires sfContexto
     * @requires $window
     * @requires appSettings
     * 
     * @description
     * Factory resposável por obter os headers de comunicação da arquitetura
     */
    function sfHeadersArquitetura(sfContexto, $window, appSettings) {

        return {
            obterHeaders: obterHeaders
        };

        /**
         * @ngdoc method
         * @name obterHeaders
         *
         * @methodOf arq-spa-base.personalizacao.factories:sfHeadersArquitetura
         *  
         * @description
         * Método responsável por retornar os headers de comunicação da arquitetura
         * 
         * @param {object} headers Headers do contexto do angular que serão mergeados.
         * @param {object} versaoEndpoint versão do endpoint parametrizada no configHttp.
         * @param {object} logar indica se a requisição trata-se de log.
         */
        function obterHeaders(headers, versaoEndpoint, logar) {
            headers = headers || {};
            logar = angular.isDefined(logar) ? logar : true;            

            if (sfContexto.contextoIniciado()) {
                headers = angular.merge(headers, {
                    "amc-message-id": new $window.Chance().guid(),
                    "amc-session-id": sfContexto.obterValorContextoSessao("IdSessao"),
                    "Accept-Language": sfContexto.obterValorContextoSessao("idioma"),
                    "amc-aplicacao": appSettings.configuracao.aplicacao,
                    "amc-work-id": sfContexto.verificarExistenciaContextoTrabalho("IdTrabalho") ? sfContexto.obterValorContextoTrabalho("IdTrabalho") : ""
                });

                if (sfContexto.obterValorContextoSessao("token") !== "" && logar) {
                    headers.authorization = "Bearer " + sfContexto.obterValorContextoSessao("token");
                }
            }

            if ($window.navigator && $window.navigator.userAgent &&
                $window.navigator.userAgent.match(/(.NET)|(MSIE)|(Trident)/)) {
                headers["Cache-Control"] = "no-cache";
                headers["Pragma"] = "no-cache";
            }

            headers["accept-version"] = versaoEndpoint ? versaoEndpoint : "";
            
            return headers;
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc factory
     * @name arq-spa-base.comunicacao.agregadorComunicacao.factories
     * 
     * @module arq-spa-base.comunicacao.agregadorComunicacao
     * 
     * @description
     * Serviço responsável por prover os recursos de agregação de comunicação
     */
    angular.module("arq-spa-base.comunicacao").factory("sfAgregadorComunicacao", sfAgregadorComunicacao);

    sfAgregadorComunicacao.$inject = ["$q", "sfLogger"];

    /**
    * @ngdoc overview
    * @name sfAgregadorComunicacao
    * 
    * @methodOf arq-spa-base.comunicacao.sfAgregadorComunicacao.factories
    * 
    * @description
    * Método responsável por iniciar a factory do sfAgregadorComunicacao.
    */
    function sfAgregadorComunicacao($q, sfLogger) {
        var agregador = function (listaExecucoes, interpretadorResposta, dictionaryInterpretadores) {
            return new AgregadorComunicacao(listaExecucoes, interpretadorResposta, dictionaryInterpretadores);
        };

        return agregador;

        /**
         * @ngdoc overview
         * @name AgregadorComunicacao
         * 
         * @methodOf arq-spa-base.comunicacao.sfAgregadorComunicacao.factories
         * 
         * @description
         * Instância da factory.
         */
        function AgregadorComunicacao(listaExecucoes_, interpretadorResposta_, dictionaryInterpretadores_) {
            sfLogger.escreverLogExecucao("Instância do AgregadorComunicacao.", "sfAgregadorComunicacao.AgregadorComunicacao", "", "", "Info",
                { classe: "sfAgregadorComunicacao", metodo: "AgregadorComunicacao" });
            var execucoes = listaExecucoes_;
            var retornos = [];
            var interpretadorResposta = interpretadorResposta_;
            var dictionaryInterpretadores = dictionaryInterpretadores_;

            angular.forEach(execucoes, executarChamada);

            this.executar = function () {
                return $q.all(retornos);
            };

            /**
             * @ngdoc overview
             * @name executarChamada
             * 
             * @methodOf arq-spa-base.comunicacao.executarChamada.factories
             * 
             * @description
             * Função responsável por executar todas as chamadas agregadas.
             */
            function executarChamada(execucao) {
                sfLogger.escreverLogExecucao("Início de execução.", "sfAgregadorComunicacao.AgregadorComunicacao.executarChamada", "", "", "Info",
                    { classe: "sfAgregadorComunicacao", metodo: "executarChamada" });

                var deferred = $q.defer();
                retornos.push(deferred.promise);

                if (angular.isDefined(interpretadorResposta) &&
                    angular.isDefined(dictionaryInterpretadores) &&
                    angular.isArray(dictionaryInterpretadores) &&
                    dictionaryInterpretadores.length > 0) {
                    for (var i = 0; i < dictionaryInterpretadores.length; i++) {
                        interpretadorResposta(execucao)[dictionaryInterpretadores[i].chamada](dictionaryInterpretadores[i].sucesso ? callbackSucesso : callbackErro);
                    }
                } else {
                    execucao.then(callbackSucesso).catch(callbackErro);
                }

                /**
                 * @ngdoc overview
                 * @name callbackSucesso
                 * 
                 * @methodOf arq-spa-base.comunicacao.executarChamada.factories
                 * 
                 * @description
                 * Função responsável por informar o sucesso da promise.
                 */
                function callbackSucesso(response) {
                    sfLogger.escreverLogExecucao("Fim de execução.", "sfAgregadorComunicacao.AgregadorComunicacao.executarChamada", "", "", "Info",
                        { classe: "sfAgregadorComunicacao", metodo: "executarChamada" });
                    deferred.resolve(response);
                }

                /**
                 * @ngdoc overview
                 * @name callbackErro
                 * 
                 * @methodOf arq-spa-base.comunicacao.executarChamada.factories
                 * 
                 * @description
                 * Função responsável por informar o erro da promise.
                 */
                function callbackErro(err) {
                    sfLogger.escreverLogExecucao("Fim de execução.", "sfAgregadorComunicacao.AgregadorComunicacao.executarChamada", "", "", "Info",
                        { classe: "sfAgregadorComunicacao", metodo: "executarChamada" });
                    deferred.reject(err);
                }
            }
        }
    }
})();
(function () {
    "use strict";

    angular.module("arq-spa-base.comunicacao").factory("sfConectorAPI", sfConectorAPI);

    sfConectorAPI.$inject = ["$document", "$http", "$q", "sfUtilitarios", "appSettings", "sfLoader", "$interval", "sfContexto", "$timeout"];


    /**
     * @ngdoc overview
     * @name arq-spa-base.comunicacao.factories:sfConectorAPI
     * @module arq-spa-base.comunicacao
     * 
     * @requires $http
     * @requires sfUtilitarios
     * @requires appSettings
     * 
     * @description
     * Factory que define as capacidades de comunicação da aplicação com as APIs.
     */
    function sfConectorAPI($document, $http, $q, sfUtilitarios, appSettings, sfLoader, $interval, sfContexto, $timeout) {

        return {
            executar: executar
        };

        /**
         * @ngdoc method
         * @name executar
         *
         * @methodOf arq-spa-base.comunicacao.factories:sfConectorAPI
         *  
         * @description
         * Método responsável por efetuar as chamadas HTTP através das configurações definidas.
         * 
         * @param {object} configuracao Configurações HTTP para comunicação.
         * @param {boolean} exibirLoader Indicador se o loader deve ou não ser exibido. Caso não seja informado, o mesmo será exibido por padrão.
         * @param {string} mensagem Mensagem que será exibida caso for diferente de vazio
         * @param {bool} deveObterDadosLocais Indicador que controla se deve obter dados locais 
         * 
         * @returns {object} Resultado da chamada HTTP efetuada.
         */
        function executar(configuracao, exibirLoader, mensagem) {
            var deferred = $q.defer();
            var logar = false;
            var criptografar = false;
            var promiseTimeout;
            var promiseCancelamentoTimeout;
            var chaveLoader = Date.now();

            if (!sfUtilitarios.comecaCom(configuracao.url, "http")) {
                configuracao.url = sfUtilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, configuracao.url]);
            }

            if (angular.isDefined(appSettings.comunicacao.timeoutPadrao) &&
                angular.isNumber(appSettings.comunicacao.timeoutPadrao)) {
                promiseTimeout = $q.defer();
                configuracao.timeout = promiseTimeout.promise;

                var timeout;
                if (angular.isDefined(appSettings.comunicacao.timeoutsEspecificos) &&
                    appSettings.comunicacao.timeoutsEspecificos.length > 0) {
                    timeout = appSettings.comunicacao.timeoutPadrao;
                    appSettings.comunicacao.timeoutsEspecificos.forEach(function (obj) {
                        if (configuracao.url.indexOf(obj.dominio) >= 0) {
                            timeout = obj.timeout;
                        }
                    });
                }
                else {
                    timeout = appSettings.comunicacao.timeoutPadrao;
                }
                promiseCancelamentoTimeout = $timeout(timeoutRequisicao, timeout);
            }

            if (angular.isUndefined(exibirLoader) || exibirLoader) {
                sfLoader.mostrarLoader(chaveLoader, mensagem);
            }

            if (sfUtilitarios.comecaCom(configuracao.url, "http")) {
                logar = !(angular.isDefined(configuracao.log) && configuracao.log);
                criptografar = angular.isDefined(appSettings.configuracao.criptografia) &&
                    appSettings.configuracao.criptografia.habilitada &&
                    !configuracao.handshake &&
                    logar &&
                    configuracao.url.indexOf("localhost") < 0;
            }

            var handshakeIniciado = sfContexto.obterValorContextoSessao("handshakeFinalizado");

            if (criptografar) {
                switch (handshakeIniciado) {
                    case "": {
                        var verificacao = $interval(verificarHanshake, 200);
                        break;
                    }
                    case "true": {
                        enviarRequisicao();
                        break;
                    }
                    case "false":
                    default:
                        {
                            tratarHandshakeNaoFinalizado();
                            break;
                        }
                }
            } else {
                enviarRequisicao();
            }

            return deferred.promise;

            /**
             * @ngdoc method
             * @name tratarHandshakeNaoFinalizado
             *
             * @methodOf arq-spa-base.comunicacao.factories:conectorAPI
             *  
             * @description
             * Método responsável tratar o handshake finalizado com erro (não realizado)
             * 
             */
            function tratarHandshakeNaoFinalizado() {
                sfLoader.esconderLoader(chaveLoader);
                deferred.reject({ handshakeNaoRealizado: true });
            }

            /**
             * @ngdoc method
             * @name timeoutRequisicao
             *
             * @methodOf arq-spa-base.comunicacao.factories:conectorAPI
             *  
             * @description
             * Método responsável tratar o timeout de comunicação
             * 
             */
            function timeoutRequisicao() {
                if (angular.isDefined(promiseCancelamentoTimeout)) {
                    $timeout.cancel(promiseCancelamentoTimeout);
                }

                if (angular.isDefined(promiseTimeout)) {
                    promiseTimeout.resolve();
                }
            }

            /**
             * @ngdoc method
             * @name enviarRequisicao
             *
             * @methodOf arq-spa-base.comunicacao.factories:conectorAPI
             *  
             * @description
             * Método responsável por enviar a requisicao http
             * 
             */
            function enviarRequisicao() {
                $http(configuracao)
                    .then(resolver)
                    .catch(rejeitar)
                    .finally(posExecutar);
            }

            /**
             * @ngdoc method
             * @name verificarHanshake
             *
             * @methodOf arq-spa-base.comunicacao.factories:conectorAPI
             *  
             * @description
             * Método responsável por verificar se o handshake foi executado
             * 
             */
            function verificarHanshake() {
                handshakeIniciado = sfContexto.obterValorContextoSessao("handshakeFinalizado");
                if (handshakeIniciado !== "") {
                    $interval.cancel(verificacao);

                    if (handshakeIniciado === "true") {
                        enviarRequisicao();
                    } else {
                        tratarHandshakeNaoFinalizado();
                    }
                }
            }

            /**
             * @ngdoc method
             * @name resolver
             *
             * @methodOf arq-spa-base.comunicacao.factories:conectorAPI
             *  
             * @description
             * Método responsável por resolver a promise derivada
             * 
             * @param {data} valor.
             */
            function resolver(data) {
                if (angular.isDefined(promiseCancelamentoTimeout)) {
                    $timeout.cancel(promiseCancelamentoTimeout);
                }

                deferred.resolve(data);
            }

            /**
             * @ngdoc method
             * @name rejeitar
             *
             * @methodOf arq-spa-base.comunicacao.factories:conectorAPI
             *  
             * @description
             * Método responsável por criar uma promise que é  resolvida como rejeitada com a razão especificada
             *  
             * @param {string} mensagem.
             */
            function rejeitar(msg) {
                if (angular.isDefined(promiseTimeout) && promiseTimeout.promise.$$state.status === 0) {
                    if (angular.isDefined(promiseCancelamentoTimeout)) {
                        $timeout.cancel(promiseCancelamentoTimeout);
                    }

                    if (msg.status === -1) {
                        deferred.reject({ erroConexao: true });
                    } else {
                        deferred.reject(msg);
                    }
                } else {
                    deferred.reject({ timeoutConector: true });
                }
            }

            /**
             * @ngdoc method
             * @name posExecutar
             *
             * @methodOf arq-spa-base.comunicacao.factories:conectorAPI
             *  
             * @description
             * Método responsável pelo tratamento pós executar.
             *  
             * @param {string} mensagem.
             */
            function posExecutar() {
                sfLoader.esconderLoader(chaveLoader);
            }
        }
    }
})();
(function () {
    "use strict";

    angular
        .module("arq-spa-base.comunicacao")
        .factory("gerenciadorComunicacao", gerenciadorComunicacao);

    gerenciadorComunicacao.$inject = ["$q", "$injector", "sfContexto", "sfUtilitarios", "appSettings", "sfCriptografia", "$window", "sfHeadersArquitetura", "sfZlib"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.comunicacao.factories:gerenciadorComunicacao
     * @module arq-spa-base.comunicacao
     * 
     * @requires $q
     * @requires sfContexto
     * 
     * @description
     * Método responsável por definir o interceptador que será utilizado para tratamento das comunicações efetuadas entre a aplicação e as APIs.
     */
    function gerenciadorComunicacao($q, $injector, sfContexto, sfUtilitarios, appSettings, sfCriptografia, $window, sfHeadersArquitetura, sfZlib) {
        return {
            request: request,
            requestError: requestError,
            response: response,
            responseError: responseError
        };

        /**
         * @ngdoc object
         * @name request
         *
         * @methodOf arq-spa-base.comunicacao.factories:gerenciadorComunicacao
         *  
         * @description
         * Método responsável por interceptar os requests http, efetuar as rotinas de instrumentação necessárias e incluir as informações de headers pertinentes.
         * 
         * @param {object} config_ Objeto que representa a configuração do request.
         * 
         * @returns {object} Objeto que representa a configuração do request.
         */
        function request(config_) {
            var logar = false,
                criptografar = false,
                arquivo = false,
                comprimir = false;

            if (sfUtilitarios.comecaCom(config_.url, "http")) {
                logar = !(angular.isDefined(config_.log) && config_.log);
                arquivo = !(angular.isDefined(config_.arquivo) && config_.arquivo);
                criptografar = angular.isDefined(appSettings.configuracao.criptografia) &&
                    appSettings.configuracao.criptografia.habilitada &&
                    !config_.handshake &&
                    logar &&
                    arquivo &&
                    config_.url.indexOf("localhost") < 0;
                comprimir = angular.isDefined(appSettings.comunicacao.compactarDados) &&
                    appSettings.comunicacao.compactarDados &&
                    !config_.handshake &&
                    logar &&
                    arquivo &&
                    config_.url.indexOf("localhost") < 0;
            }

            var idMensagem = new $window.Chance().guid();

            config_.headers = sfHeadersArquitetura.obterHeaders(config_.headers, config_.version, logar);

            if (angular.isDefined(config_.data) &&
                angular.isObject(config_.data)) {
                if (comprimir) {
                    config_.data = sfZlib.comprimir(config_.data);
                }
                if (criptografar) {
                    config_.data = sfCriptografia.criptografarPayloadJWE(config_.data);
                }
            }

            if (logar) {
                var sfLogger = $injector.get("sfLogger");

                var headersLog = angular.copy(config_);
                delete headersLog.headers.authorization;
                delete headersLog.data;

                sfLogger.escreverLogComunicacao("Requisição efetuada", "gerenciadorComunicacao.request", "Request", headersLog, "Info", idMensagem, "",
                    { classe: "gerenciadorComunicacao", metodo: "request" });
            }

            return config_;
        }

        /**
         * @ngdoc object
         * @name requestError
         *
         * @methodOf arq-spa-base.comunicacao.factories:gerenciadorComunicacao
         *  
         * @description
         * Método responsável por interceptar os erros de requests http e efetuar as rotinas de instrumentação necessárias .
         * 
         * @param {object} rejeicao_ Objeto que representa a rejeição da request recebida.
         * 
         * @returns {promisse} Promisse de rejeição do request.
         */
        function requestError(rejeicao_) {
            var sfLogger = $injector.get("sfLogger");

            var headersLog = angular.copy(rejeicao_.config);
            delete headersLog.headers.authorization;
            delete headersLog.data;

            sfLogger.escreverLogComunicacao("Erro na requisição", "gerenciadorComunicacao.requestError", "Request", headersLog, "Warn", rejeicao_.config.headers["amc-message-id"], "",
                { classe: "gerenciadorComunicacao", metodo: "requestError" });

            return $q.reject(rejeicao_);
        }

        /**
         * @ngdoc object
         * @name response
         *
         * @methodOf arq-spa-base.comunicacao.factories:gerenciadorComunicacao
         *  
         * @description
         * Método responsável por interceptar os responses http, efetuar as rotinas de instrumentação necessárias e extrair as informações pertinentes para armazenamento no sfContexto.
         * 
         * @param {object} resposta_ Objeto que representa a resposta obtida.
         * 
         * @returns {object} Objeto que representa a resposta obtida.
         */
        function response(resposta_) {
            var logar = false,
                criptografar = false,
                arquivo = false,
                descomprimir = false;

            if (sfUtilitarios.comecaCom(resposta_.config.url, "http")) {
                logar = (!angular.isDefined(resposta_.config.log) || !resposta_.config.log);
                arquivo = (!angular.isDefined(resposta_.config.arquivo) || !resposta_.config.arquivo);
                criptografar = angular.isDefined(appSettings.configuracao.criptografia) &&
                    appSettings.configuracao.criptografia.habilitada &&
                    !resposta_.config.handshake &&
                    logar &&
                    arquivo &&
                    resposta_.config.url.indexOf("localhost") < 0;
                descomprimir = angular.isDefined(appSettings.comunicacao.compactarDados) &&
                    appSettings.comunicacao.compactarDados &&
                    !resposta_.config.handshake &&
                    logar &&
                    arquivo &&
                    resposta_.config.url.indexOf("localhost") < 0;
            }

            if (logar) {
                var sfLogger = $injector.get("sfLogger");

                var headersLog = angular.copy(resposta_.config);
                delete headersLog.headers.authorization;
                delete headersLog.data;

                sfLogger.escreverLogComunicacao("Resposta obtida com sucesso", "gerenciadorComunicacao.response", "Response", headersLog, "Info", resposta_.config.headers["amc-message-id"], resposta_.status,
                    { classe: "gerenciadorComunicacao", metodo: "response" });
            }

            if (angular.isDefined(resposta_.data) &&
                angular.isString(resposta_.data) &&
                resposta_.data !== "") {
                if (criptografar) {
                    resposta_.data = sfCriptografia.descriptografarPayloadJWE(resposta_.data);
                }
                if (descomprimir && resposta_.data.data) {
                    resposta_.data = sfZlib.descomprimir(resposta_.data.data);
                }
            }

            return resposta_;
        }

        /**
         * @ngdoc object
         * @name responseError
         *
         * @methodOf arq-spa-base.comunicacao.factories:gerenciadorComunicacao
         *  
         * @description
         * Método responsável por interceptar os erros de response http e efetuar as rotinas de instrumentação necessárias, bem como eventuais tratamentos gerais.
         * 
         * @param {object} rejeicao_ Objeto que representa a rejeição do response recebida.
         * 
         * @returns {promisse} Promisse de rejeição do response.
         */
        function responseError(rejection) {
            var logar = false,
                criptografar = false,
                descomprimir = false;

            var sfLogger;

            if (angular.isDefined(rejection) && angular.isDefined(rejection.config) &&
                sfUtilitarios.comecaCom(rejection.config.url, "http")) {
                logar = (!angular.isDefined(rejection.config.log) || !rejection.config.log);
                criptografar = angular.isDefined(appSettings.configuracao.criptografia) &&
                    appSettings.configuracao.criptografia.habilitada &&
                    !rejection.config.handshake &&
                    logar &&
                    rejection.config.url.indexOf("localhost") < 0;
                descomprimir = angular.isDefined(appSettings.comunicacao.compactarDados) &&
                    appSettings.comunicacao.compactarDados &&
                    !rejection.config.handshake &&
                    logar &&
                    rejection.config.url.indexOf("localhost") < 0;
            }

            if (logar) {
                sfLogger = $injector.get("sfLogger");

                if (angular.isDefined(rejection) && angular.isDefined(rejection.config)) {
                    var headersLog = angular.copy(rejection.config);
                    delete headersLog.headers.authorization;
                    delete headersLog.data;

                    sfLogger.escreverLogComunicacao("Resposta obtida com erro", "gerenciadorComunicacao.responseError", "Response", headersLog, "Warn", rejection.config.headers["amc-message-id"], rejection.status);
                }

            }

            if (angular.isDefined(rejection.data) &&
                angular.isString(rejection.data) &&
                rejection.data !== "") {
                if (criptografar) {
                    rejection.data = sfCriptografia.descriptografarPayloadJWE(rejection.data);
                }
                if (descomprimir && rejection.data.data) {
                    rejection.data = sfZlib.descomprimir(rejection.data.data);
                }
            }

            if (angular.isDefined(rejection) &&
                angular.isDefined(rejection.headers())) {

                var resHeader = rejection.headers();

                switch (resHeader["amc-criptografia"]) {
                    case "erro":
                        {
                            if (sfLogger != null) {
                                sfLogger.escreverLogExecucao("Identificou header 'amc-criptografia' com valor 'erro'. Reiniciando o handshake." + "\n" + "Response Headers: " + JSON.stringify(resHeader), "gerenciadorComunicacao.responseError", "", "", "Warn",
                                    { classe: "gerenciadorComunicacao", metodo: "response" });
                            }

                            var sfHandshake = $injector.get("sfHandshake");
                            sfHandshake.tratarRenovacaoHandshake();

                            break;
                        }
                    default:
                        break;
                }
            }

            return $q.reject(rejection);
        }
    }
})();
(function () {
    "use strict";

	/**
     * @ngdoc overview
     * @name arq-spa-base.comunicacao.factories:sfZlib
     * @module arq-spa-base.comunicacao
     */
    angular.module("arq-spa-base.comunicacao")
        .factory("sfZlib", sfZlib);

    sfZlib.$inject = ["$window"];

	/**
     * @ngdoc overview
     * @name * @name arq-spa-base.comunicacao:sfZlib
     * @module arq-spa-base.comunicacao
     * 
     * @requires $window
     * 
     * @description
     * Factory responsável por comprimir e descomprir dados
     */
    function sfZlib($window) {
        return {
            comprimir: comprimir,
            descomprimir: descomprimir
        };

        /**
         * @ngdoc method
         * @name comprimir
         *
         * @methodOf arq-spa-base.comunicacao.factories:sfZlib
         *  
         * @description
         * Método responsável por comprimir a string
         * 
         * @param {string} dados dados que serão comprimidos.
         */
        function comprimir(dados) {
            var data = $window.pako.deflate(JSON.stringify(dados), { to: "string" });
            var compactado = $window.forge.util.encode64(data);
            return { data: compactado };
        }

        /**
         * @ngdoc method
         * @name descomprimir
         *
         * @methodOf arq-spa-base.comunicacao.factories:sfZlib
         *  
         * @description
         * Método responsável por descomprimir a string
         * 
         * @param {string} dados dados que serão comprimidos.
         */
        function descomprimir(dados) {
            var data = $window.forge.util.decode64(dados);
            var descompactado = $window.pako.inflate(data, { to: "string" });

            try {
                return JSON.parse(descompactado);
            } catch (err) {
                return descompactado;
            }
        }
    }
})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.configuracao
     * 
     * @description
     * Módulo de configuração da arquitetura base que provê os recursos necessários para execução da aplicação.
     */
    angular.module("arq-spa-base.configuracao", [
        "arq-spa-base.navegacao",
        "LocalStorageModule",
        "arq-spa-base.criptografia"
    ]);
})();
(function () {
    "use strict";

    /**
     * @ngdoc factory
     * @name arq-spa-base.configuracao.factories:configuracaoAplicacao
     * 
     * @module arq-spa-base.configuracao
     * 
     * @description
     * Serviço responsável por prover os recursos de configuração da aplicação.
     */
    angular.module("arq-spa-base.configuracao").provider("configuradorAplicacao", configuradorAplicacao);

    configuradorAplicacao.$inject = ["sfNavegadorProvider", "appSettings", "sfTradutorProvider", "localStorageServiceProvider", "$sceDelegateProvider", "$analyticsProvider", "sfLoggerProvider", "$compileProvider"];

    /**
     * @ngdoc overview
     * @name configuracao
     * 
     * @methodOf arq-spa-base.configuracao.providers:configuracaoAplicacao
     * 
     * @description
     * Método responsável por definir a factory do configuração.
    */
    function configuradorAplicacao(navegador, appSettings, sfTradutorProvider, localStorageServiceProvider, $sceDelegateProvider, $analyticsProvider, sfLoggerProvider, $compileProvider) {
        this.configurarModuloPrincipal = configurarModuloPrincipal;
        this.$get = get;

        get.$inject = ["$http", "sfContexto", "sfNavegador", "appSettings", "sfFiltro", "sfUtilitarios", "sfHandshake", "sfConfiguracaoDinamica", "$location", "sfLogger", "$window", "amMoment", "$rootScope", "$timeout", "sfTradutor"];


        /**
         * @ngdoc object
         * @name $get
         *
         * @methodOf arq-spa-base.configuracao.providers:configuracaoAplicacao
         *  
         * @description
         * Método responsável por retornar a instância deste provider.
         * 
         * @returns {object} Objeto que representa a instância deste provider.
         */
        function get($http, sfContexto, sfNavegador, appSettings, sfFiltro, sfUtilitarios, sfHandshake, sfConfiguracaoDinamica, $location, sfLogger, $window, amMoment, $rootScope, $timeout, sfTradutor) {
            sfLoggerProvider.enfileirarLogExecucao("Início de execução.", "configuradorAplicacao.get", "", "", "Info",
                { classe: "configuradorAplicacao", metodo: "get" });
            var servico = new ConfiguradorAplicacao($http, sfContexto, sfNavegador, appSettings, sfFiltro, sfUtilitarios, sfHandshake, sfConfiguracaoDinamica, $location, sfLogger, $window, amMoment, $rootScope, $timeout, sfTradutor);

            sfLoggerProvider.enfileirarLogExecucao("Término de execução.", "configuradorAplicacao.get", "", "", "Info",
                { classe: "configuradorAplicacao", metodo: "get" });

            return servico;
        }

        /**
         * @ngdoc object
         * @name configurarModuloPrincipal
         * 
         * @methodOf arq-spa-base.configuracao.factories:configuracao
         * 
         * @description
         * Método responsável por efetuar os procedimentos da etapa de configuração do módulo principal.
         */
        function configurarModuloPrincipal() {
            var debugInfoEnabled = appSettings.configuracao.debugInfoEnabled || false;
            $compileProvider.debugInfoEnabled(debugInfoEnabled);

            sfLoggerProvider.enfileirarLogExecucao("Início de execução.", "configuradorAplicacao.configurarModuloPrincipal", "", "", "Info",
                { classe: "configuradorAplicacao", metodo: "configurarModuloPrincipal" });
            sfTradutorProvider.configurarTradutor();

            if (appSettings.configuracao.aplicacao && angular.isString(appSettings.configuracao.aplicacao) &&
                appSettings.configuracao.aplicacao !== "") {
                localStorageServiceProvider.setPrefix(appSettings.configuracao.aplicacao);
            } else {
                localStorageServiceProvider.setPrefix("");
            }

            if (appSettings.configuracao.memorizador.expiracao && angular.isNumber(appSettings.configuracao.memorizador.expiracao) &&
                appSettings.configuracao.memorizador.expiracao >= 0) {
                localStorageServiceProvider.setStorageCookie(appSettings.configuracao.memorizador.expiracao);
            } else {
                localStorageServiceProvider.setStorageCookie(3650);
            }

            localStorageServiceProvider.setStorageType("localStorage");
            localStorageServiceProvider.setNotify(false, false);

            $analyticsProvider.virtualPageviews(false);

            if (angular.isDefined(appSettings.configuracao.seguranca.urlWhiteList) &&
                angular.isArray(appSettings.configuracao.seguranca.urlWhiteList)) {
                var whitelist = appSettings.configuracao.seguranca.urlWhiteList.slice(0);
                whitelist.push("self");
                $sceDelegateProvider.resourceUrlWhitelist(whitelist);
            }

            sfLoggerProvider.enfileirarLogExecucao("Término de execução.", "configuradorAplicacao.configurarModuloPrincipal", "", "", "Info",
                { classe: "configuradorAplicacao", metodo: "configurarModuloPrincipal" });
        }
    }

    /**
     * @ngdoc service
     * @name arq-spa-base.navegacao.services:Navegador
     * @module arq-spa-base.navegacao
     * 
     * @requires $http
     * @requires sfContexto
     * @requires sfNavegador
     * @requires appSettings {object} Objeto que representa as configurações constantes do arquivo appSettings
     * @requires sfFiltro
     * 
     * @description
     * Definição do serviço responsável por prover os recursos de configuração da aplicação.
     */
    function ConfiguradorAplicacao($http, sfContexto, sfNavegador, appSettings, sfFiltro, sfUtilitarios, sfHandshake, sfConfiguracaoDinamica, $location, sfLogger, $window, amMoment, $rootScope, $timeout, sfTradutor) {
        this.executarModuloPrincipal = executarModuloPrincipal;

        /**
         * @ngdoc object
         * @name executarModuloPrincipal
         * 
         * @methodOf arq-spa-base.configuracao.factories:configuracao
         * 
         * @description
         * Método responsável por efetuar os procedimentos da etapa de execução do módulo principal.
         */
        function executarModuloPrincipal() {
            // Inicialização do sfContexto
            if (appSettings.configuracao.caminhoArquivoConfigContexto && appSettings.configuracao.caminhoArquivoConfigContexto !== "") {
                $http.get(appSettings.configuracao.caminhoArquivoConfigContexto).then(sucessoRecuperacaoConfig).catch(erroConfiguracaoConfig);
            }
            else {
                throw new Error("O caminho para o arquivo de configuração não foi definido em tempo de configuração.");
            }

            /**
             * @ngdoc run
             * @name arq-spa-base.configuracao.run:sucessoRecuperacaoConfig
             * @module arq-spa-base.configuracao
             * 
             * @params configuracaoContexto {object} Objeto que contém as configurações de sfContexto
             * 
             * @description
             * Método responsável por realizar o callback de sucesso inicializando o sfContexto.
             */
            function sucessoRecuperacaoConfig(configuracaoContexto) {
                sfContexto.iniciar(configuracaoContexto.data);

                $rootScope.$on("translatePartialLoaderStructureChanged", function(name) {
                    console.log(name);
                    sfTradutor.atualizar();
                });

                var numeroMaximoTentativas, quantidadeTentativas;

                //Cria um GUID e inclui na session id do contexto
                var idSessao;
                var portaUrlContainer;
                var erroDistribuicao;
                var informacoesUrl = $location.search();

                if (angular.isDefined(informacoesUrl)) {
                    idSessao = ("sessionID" in informacoesUrl) ? informacoesUrl.sessionID : new $window.Chance().guid();
                    portaUrlContainer = ("portaUrlContainer" in informacoesUrl) ? informacoesUrl.portaUrlContainer : 8080;
                    erroDistribuicao = ("erroDistribuicao" in informacoesUrl) ? informacoesUrl.erroDistribuicao : false;
                }
                else {
                    idSessao = new $window.Chance().guid();
                    portaUrlContainer = 8080;
                    erroDistribuicao = false;
                }

                sfContexto.definirValorContextoSessao("IdSessao", idSessao);
                sfContexto.definirValorContextoSessao("PortaUrlContainer", portaUrlContainer);
                sfContexto.definirValorContextoSessao("erroDistribuicao", erroDistribuicao);

                sfLogger.escreverLogExecucao("Início de execução.", "configuradorAplicacao.sucessoRecuperacaoConfig", "", "", "Info",
                    { classe: "configuradorAplicacao", metodo: "sucessoRecuperacaoConfig" });

                // Inicialização do handshake
                if (angular.isDefined(appSettings.configuracao.criptografia) &&
                    appSettings.configuracao.criptografia.habilitada) {
                    numeroMaximoTentativas = appSettings.configuracao.criptografia.numeroMaximoTentativas || 1;
                    quantidadeTentativas = 0;

                    sfHandshake.iniciar()
                        .then(sucessoHandshake)
                        .catch(erroHandshake);
                }

                tratarInicializacaoConfigurador();

                sfLogger.escreverLogExecucao("Término de execução.", "configuradorAplicacao.sucessoRecuperacaoConfig", "", "", "Info",
                    { classe: "configuradorAplicacao", metodo: "sucessoRecuperacaoConfig" });

                /**
                 * @ngdoc run
                 * @name arq-spa-base.configuracao.run:erroHandShake
                 * @module arq-spa-base.configuracao
                 *  
                 * @description
                 * Método responsável por tratar os erros durante a execução do handshake
                 */
                function erroHandshake(err) {
                    var delayTentativaHandshake = appSettings.configuracao.criptografia.delayTentativaHandshake || 500;

                    $timeout(tentativaHandhsake, delayTentativaHandshake);

                    /**
                     * @ngdoc object
                     * @name tentativaHandhsake
                     *
                     * @methodOf arq-spa-base.comunicacao.factories:gerenciadorComunicacao
                     *  
                     * @description
                     * Método responsável por tratar a tentativa de realizar o handshake
                     * 
                     */
                    function tentativaHandhsake() {
                        quantidadeTentativas++;
                        if (quantidadeTentativas < numeroMaximoTentativas) {
                            sfHandshake.iniciar(err.chavesCliente)
                                .then(sucessoHandshake)
                                .catch(erroHandshake);
                        } else {
                            sfLogger.escreverLogExecucao("Handshake não foi reiniciado após " + quantidadeTentativas + " tentativas.", "gerenciadorComunicacao.responseError", "", "", "Warn",
                                { classe: "configuradorAplicacao", metodo: "erroHandshake" });
                            sfContexto.definirValorContextoSessao("handshakeFinalizado", "false");
                            $rootScope.$broadcast("eventoErroHandshake", quantidadeTentativas);
                        }
                    }
                }

                /**
                 * @ngdoc run
                 * @name arq-spa-base.configuracao.run:sucessoHandshake
                 * @module arq-spa-base.configuracao
                 * 
                 * @description
                 * Método responsável por tratar o sucesso na execução do handshake
                 */
                function sucessoHandshake() {
                    sfLogger.escreverLogExecucao("Handshake foi iniciado após " + quantidadeTentativas + " tentativa(s).", "configuradorAplicacao.sucessoRecuperacaoConfig", "", "", "Info",
                        { classe: "configuradorAplicacao", metodo: "sucessoHandshake" });
                    sfContexto.definirValorContextoSessao("handshakeFinalizado", "true");
                }

                /**
                 * @ngdoc run
                 * @name arq-spa-base.configuracao.run:tratarInicializacaoConfigurador
                 * @module arq-spa-base.configuracao
                 * 
                 * @description
                 * Método responsável tratar a inicialização restante do configurador
                 */
                function tratarInicializacaoConfigurador() {
                    sfLogger.escreverLogExecucao("Início de execução.", "configuradorAplicacao.tratarInicializacaoConfigurador", "", "", "Info",
                        { classe: "configuradorAplicacao", metodo: "tratarInicializacaoConfigurador" });

                    sfConfiguracaoDinamica.obterTodasConfiguracoes();
                    sfConfiguracaoDinamica.obterConfiguracoesLog();

                    // Inicialização do filtro
                    sfFiltro.iniciar();

                    // Inicialização do navegador
                    sfNavegador.iniciar();

                    // Definir o localização / timezone para data e hora
                    configurarLocalizacao();

                    sfNavegador.iniciarFluxo(appSettings.navegacao.fluxoInicial);

                    sfLogger.escreverLogExecucao("Término de execução.", "configuradorAplicacao.tratarInicializacaoConfigurador", "", "", "Info",
                        { classe: "configuradorAplicacao", metodo: "tratarInicializacaoConfigurador" });
                }

                /**
                 * @ngdoc run
                 * @name arq-spa-base.configuracao.run:configurarLocalizacao
                 * @module arq-spa-base.configuracao
                 * 
                 * @description
                 * Método responsável por definir o local e timezone das datas e horários.
                 */
                function configurarLocalizacao() {
                    sfLogger.escreverLogExecucao("Início de execução.", "configuradorAplicacao.configurarLocalizacao", "", "", "Info",
                        { classe: "configuradorAplicacao", metodo: "configurarLocalizacao" });
                    if (angular.isDefined(appSettings.configuracao.localizacao)) {
                        if (angular.isDefined(appSettings.configuracao.localizacao.timezone)) {
                            amMoment.changeTimezone(appSettings.configuracao.localizacao.timezone);
                        }

                        if (angular.isDefined(appSettings.configuracao.localizacao.local)) {
                            var customizacaoLocal = appSettings.configuracao.localizacao.customizacaoLocal || undefined;
                            amMoment.changeLocale(appSettings.configuracao.localizacao.local, customizacaoLocal);
                            sfContexto.definirValorContextoSessao("idioma", appSettings.configuracao.localizacao.local);
                        }
                    }
                    sfLogger.escreverLogExecucao("Término de execução.", "configuradorAplicacao.configurarLocalizacao", "", "", "Info",
                        { classe: "configuradorAplicacao", metodo: "configurarLocalizacao" });
                }


            }

            /**
             * @ngdoc run
             * @name arq-spa-base.navegacao.run:erroConfiguracaoConfig
             * @module arq-spa-base.navegacao
             * 
             * @params dadosErro {object} Objeto que contém o erro retornado na recuperação da configuração
             * 
             * @description
             * Método responsável por realizar o callback de erro exibindo os dados da falha obtida.
             */
            function erroConfiguracaoConfig(dadosErro) {
                throw new Error("Não foi possível obter as informações para configuração do sfContexto à partir do arquivo '" + appSettings.configuracao.caminhoArquivoConfigContexto + "'. Erro: " + dadosErro);
            }
        }
    }
})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.controles-visuais
     * 
     * @requires spinjs
     * 
     * @description
     * Módulo que disponibiliza os controles visuais criados pela arquitetura
     */
    angular.module("arq-spa-base.controles-visuais", []);
})();
(function () {
    "use strict";

    angular.module("arq-spa-base.controles-visuais").directive("sfLoader", sfLoader);

    /**
     * @ngdoc directive
     * @name arq-spa-base.controles-visuais: sfLoader
     * @module arq-spa-base.controles-visuais
     */
    function sfLoader() {
        return {
            restrict: "E",
            template: "<div class=\"loader-backdrop\"><sf-spinner loader=\"true\"></sf-spinner><div class=\"loader-conteiner\"><p class=\"loader-paragrafo\"><strong ng-bind='mensagem'></strong></p></div></div>",
            scope: {
                mensagem: "="
            },
            link: link
        };

        function link($scope, element) {
            $scope.$on("$destroy", function () {
                element.remove();
            });
        }
    }

})();
(function () {
    "use strict";

    angular.module("arq-spa-base.controles-visuais").directive("sfLoaderEspecifico", sfLoaderEspecifico);

    sfLoaderEspecifico.$inject = ["appSettings"];

    /**
     * @ngdoc directive
     * @name arq-spa-base.controles-visuais: sfLoaderEspecifico
     * @module arq-spa-base.controles-visuais
     */
    function sfLoaderEspecifico(appSettings) {
        return {
            restrict: "EA",
            templateUrl: appSettings.tipoSpinner.loader.caminhoTemplate,
            scope: {
                mensagens: "="
            },
            link: link
        };

        function link($scope, element) {
            $scope.$on("$destroy", function () {
                element.remove();
            });
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.controles-visuais.factories:sfLoader
     * @module arq-spa-base.controles-visuais
     *
     * @description
     * 
     */
    angular.module("arq-spa-base.controles-visuais").factory("sfLoader", sfLoader);

    sfLoader.$inject = ["$compile", "$rootScope", "$document"];

    /**
     * @ngdoc overview
     * @name sfLoader
     *
     * @methodOf arq-spa-base.controles-visuais.factories:sfLoader
     *
     * @description
     * Exibe o loader
     */
    function sfLoader($compile, $rootScope, $document) {
        var div = null;
        var isShowing = false;
        var body = $document.find("body").eq(0);
        var overflowBefore = undefined;
        var pilhaOrdenada = {};
        var chaveLoaderPrioritario;
        var childScope;

        return {
            mostrarLoader: mostrarLoader,
            esconderLoader: esconderLoader
        };

        /**
         * @ngdoc method
         * @name mostrarLoader
         *
         * @methodOf arq-spa-base.controles-visuais.factories:sfLoader
         *  
         * @description
         * Método responsável por inserir no corpo da página html um conteiner com spinner.
         * 
         * @param {string} chave de exibição de loader.
         * @param {(string|JSON)} mensagem "Carregando" | { mensagem1: "Carregando", mensagem2: "Finalizando" } -
         *  texto ou objeto contendo as mensagens para exibicação do loader específico
         * @param {boleano} devePriorizar indicador se deve priorizar esse loader
         */
        function mostrarLoader(chave, mensagem, devePriorizar) {
            mensagem = mensagem || "";
            pilhaOrdenada[chave] = mensagem;

            if (isShowing) {
                return;
            }

            if (devePriorizar === true) {
                chaveLoaderPrioritario = chave;
            }

            childScope = $rootScope.$new();
            var template = recuperarTemplate();
            div = $compile(angular.element(template))(childScope);
            overflowBefore = body.css("overflow");
            body.css("overflow", "hidden");
            body.append(div);

            isShowing = true;

            /**
             * @ngdoc method
             * @name sfLoader: recuperarTemplate
             * @module arq-spa-base.controles-visuais
             * 
             * @description
             * Responsável por montar o template do loader
             */
            function recuperarTemplate() {
                childScope.mensagem = mensagem;
                if (angular.isObject(mensagem)) {
                    return "<sf-loader-especifico mensagens='mensagem'><sf-loader-especifico/>";
                } else {
                    return "<sf-loader mensagem='mensagem'><sf-loader/>";
                }
            }
        }

        /**
         * @ngdoc method
         * @name esconderLoader
         *
         * @methodOf arq-spa-base.controles-visuais.factories:sfLoader
         *  
         * @description
         * Método responsável por remover do corpo html o conteiner do loader.
         * 
         * @param {string} chave do loader que está sendo exibido.
         */
        function esconderLoader(chave) {
            if (!isShowing) {
                return;
            }

            if (pilhaOrdenada.hasOwnProperty(chave)) {
                delete pilhaOrdenada[chave];
            }

            if (angular.isDefined(chaveLoaderPrioritario) &&
                chaveLoaderPrioritario !== chave) {
                return;
            }

            chaveLoaderPrioritario = undefined;
            body.css("overflow", overflowBefore);
            childScope.$destroy();
            div.remove();
            div = null;
            isShowing = false;

            if (Object.keys(pilhaOrdenada).length !== 0) {
                var novaChave;
                for (var chavePilha in pilhaOrdenada) {
                    if (pilhaOrdenada.hasOwnProperty(chavePilha)) {
                        novaChave = chavePilha;
                        break;
                    }
                }
                mostrarLoader(novaChave, pilhaOrdenada[novaChave]);
            }
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc directive
     * @name arq-spa-base.recursos.directives:sfMenu
     * 
     * @module arq-spa-base.recursos
     * 
     * @description
     * Diretiva responsável por efetuar a animação swipe do menu.
     */
    angular.module("arq-spa-base.controles-visuais").directive("sfMenu", sfMenu);

    sfMenu.$inject = ["$rootScope"];

    /**
     * @ngdoc method
     * @name sfMenu
     * 
     * @methodOf arq-spa-base.recursos.directives:sfMenu
     * 
     * @description
     * Método responsável por definir a diretiva "sfMenu".
     */
    function sfMenu($rootScope) {
        sfMenuController.$inject = ["$scope"];

        return {
            restrict: "A",
            replace: true,
            scope: {
                posicao: "@sfMenu",
                habilitado: "@sfMenuHabilitado"
            },
            transclude: true,
            template: "<div ng-swipe-left=\"movimentoFecharMenu()\" ng-swipe-right=\"movimentoAbrirMenu()\" ng-transclude></div>",
            controller: sfMenuController
        };

        /**
         * @ngdoc method
         * @name sfMenuController
         * 
         * @methodOf arq-spa-base.recursos.directives:sfMenu
         * 
         * @description
         * Método responsável por definir o estado inicial do menu.
         */
        function sfMenuController($scope) {
            $scope.movimentoFecharMenu = movimentoFecharMenu;
            $scope.movimentoAbrirMenu = movimentoAbrirMenu;

            if ($scope.posicao == "fechado") {
                adicionarClassesMenuFechado();
            }
            else if ($scope.posicao == "aberto") {
                adicionarClassesMenuAberto();
            }
            else {
                throw new Error("Deve ser utilizada uma das opções: \"aberto\" ou \"fechado\".");
            }

            /**
             * @ngdoc method
             * @name sfMenuController
             * 
             * @methodOf arq-spa-base.recursos.directives:sfMenu
             * 
             * @description
             * Método responsável por definir o estado inicial do menu.
             */
            function adicionarClassesMenuFechado() {
                $rootScope.navegacaoClass = "navegacao-movimento";
                $rootScope.conteudoClass = "";
                $rootScope.menuConteudoClass = "menu-conteudo-fechado-class";
            }
            
            /**
             * @ngdoc method
             * @name sfMenuController
             * 
             * @methodOf arq-spa-base.recursos.directives:sfMenu
             * 
             * @description
             * Método responsável por definir o estado inicial do menu.
             */
            function adicionarClassesMenuAberto() {
                $rootScope.navegacaoClass = "";
                $rootScope.conteudoClass = "conteudo-movimento";
                $rootScope.menuConteudoClass = "menu-conteudo-aberto-class";
            }

            /**
             * @ngdoc method
             * @name sfMenuController
             * 
             * @methodOf arq-spa-base.recursos.directives:sfMenu
             * 
             * @description
             * Método responsável por definir o estado inicial do menu.
             */
            function movimentoFecharMenu() {
                if ($scope.habilitado !== "false") {
                    adicionarClassesMenuFechado();
                }
            }

            /**
             * @ngdoc method
             * @name sfMenuController
             * 
             * @methodOf arq-spa-base.recursos.directives:sfMenu
             * 
             * @description
             * Método responsável por definir o estado inicial do menu.
             */
            function movimentoAbrirMenu() {
                if ($scope.habilitado !== "false") {
                    adicionarClassesMenuAberto();
                }
            }
        }
    }
})();


(function () {
    "use strict";

    /**
     * @ngdoc directive
     * @name arq-spa-base.recursos.directives:sfMenuAbre
     * 
     * @module arq-spa-base.recursos
     * 
     * @description
     * Diretiva responsável por efetuar a animação de abertura menu.
     */
    angular.module("arq-spa-base.controles-visuais").directive("sfMenuAbrir", sfMenuAbrir);

    sfMenuAbrir.$inject = ["$rootScope"];
    
    /**
     * @ngdoc method
     * @name sfMenuAbrir
     * 
     * @methodOf arq-spa-base.recursos.directives:sfMenuAbrir
     * 
     * @description
     * Método responsável por definir a diretiva "sfMenuAbrir".
     */
    function sfMenuAbrir($rootScope) {
        return {
            restrict: "A",
            priority: 1,
            terminal: false,
            link: linkAbrirMenu
        };
        

        /**
         * @ngdoc method
         * @name linkAbrirMenu
         * 
         * @methodOf arq-spa-base.recursos.directives:linkAbrirMenu
         * 
         * @description
         * Método responsável por tratar o evento "link" da diretiva.
         */
        function linkAbrirMenu(scope_, element_) {
            element_.bind("click", eventoClick);

            /**
             * @ngdoc method
             * @name eventoClick
             * 
             * @methodOf arq-spa-base.recursos.directives:eventoClick
             * 
             * @description
             * Método responsável por o evento de clique com ação de abrir o menu.
             */
            function eventoClick($event) {
                $rootScope.$apply(function () {
                    $rootScope.navegacaoClass = "";
                    $rootScope.conteudoClass = "conteudo-movimento";
                    $rootScope.menuConteudoClass = "menu-conteudo-aberto-class";
                });
                
                $event.stopPropagation();
            }
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc directive
     * @name arq-spa-base.recursos.directives:sfMenuConteudo
     * 
     * @module arq-spa-base.recursos
     * 
     * @description
     * Diretiva responsável por definir o conteúdo que será deslocado pelo slide do menu.
     */
    angular.module("arq-spa-base.controles-visuais").directive("sfMenuConteudo", sfMenuConteudo);
    
    sfMenuConteudo.$inject = ["$rootScope"];

    /**
     * @ngdoc method
     * @name sfMenuConteudo
     * 
     * @methodOf arq-spa-base.recursos.directives:sfMenuConteudo
     * 
     * @description
     * Método responsável por definir a diretiva "sfMenuConteudo".
     */
    function sfMenuConteudo($rootScope) {
        return {
            restrict: "A",
            replace: true,
            transclude: true,
            template: "<div ng-class=\"conteudoClass\"><div id=\"conteudoArea\" ng-class=\"menuConteudoClass\"><svg height=\"100%\" width=\"100%\"><rect class=\"menu-conteudo-sobreposto\" height=\"100%\" width=\"100%\"></rect></svg></div><div class=\"conteudo-menu\" ng-transclude></div></div>",
            link: linkFecharMenu
        };
        
        /**
         * @ngdoc method
         * @name sfMenuFecha
         * 
         * @methodOf arq-spa-base.recursos.directives:linkFecharMenu
         * 
         * @description
         * Método responsável por tratar o evento "link" da diretiva.
         */
        function linkFecharMenu(scope_, element_) {
            element_.bind("click", eventoClick);

            /**
             * @ngdoc method
             * @name eventoClick
             * 
             * @methodOf arq-spa-base.recursos.directives:eventoClick
             * 
             * @description
             * Método responsável por o evento de clique com ação de fechar o menu.
             */
            function eventoClick() {
                $rootScope.$apply(function () {                    
                    $rootScope.navegacaoClass = "navegacao-movimento";
                    $rootScope.conteudoClass = "";
                    $rootScope.menuConteudoClass = "menu-conteudo-fechado-class";
                });
            }
        }
    }
})();


(function () {
    "use strict";

    /**
     * @ngdoc directive
     * @name arq-spa-base.recursos.directives:sfMenuFecha
     * 
     * @module arq-spa-base.recursos
     * 
     * @description
     * Diretiva responsável por efetuar a animação de fechamento menu.
     */
    angular.module("arq-spa-base.controles-visuais").directive("sfMenuFechar", sfMenuFechar);

    sfMenuFechar.$inject = ["$rootScope"];
    
    /**
     * @ngdoc method
     * @name sfMenuFechar
     * 
     * @methodOf arq-spa-base.recursos.directives:sfMenuFechar
     * 
     * @description
     * Método responsável por definir a diretiva "sfMenuFechar".
     */
    function sfMenuFechar($rootScope) {
        return {
            restrict: "A",
            priority: 1,
            terminal: false,
            link: linkFecharMenu
        };

        /**
         * @ngdoc method
         * @name sfMenuFecha
         * 
         * @methodOf arq-spa-base.recursos.directives:linkFecharMenu
         * 
         * @description
         * Método responsável por tratar o evento "link" da diretiva.
         */
        function linkFecharMenu(scope_, element_) {
            element_.bind("click", eventoClick);

            /**
             * @ngdoc method
             * @name eventoClick
             * 
             * @methodOf arq-spa-base.recursos.directives:eventoClick
             * 
             * @description
             * Método responsável por o evento de clique com ação de fechar o menu.
             */
            function eventoClick() {
                $rootScope.$apply(function () {
                    $rootScope.navegacaoClass = "navegacao-movimento";
                    $rootScope.conteudoClass = "";
                    $rootScope.menuConteudoClass = "menu-conteudo-fechado-class";
                });
            }
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc directive
     * @name arq-spa-base.recursos.directives:sfMenuNavegacao
     * 
     * @module arq-spa-base.recursos
     * 
     * @description
     * Diretiva responsável por definir o menu a ser deslocado.
     */
    angular.module("arq-spa-base.controles-visuais").directive("sfMenuNavegacao", sfMenuNavegacao);


    /**
     * @ngdoc method
     * @name sfMenuNavegacao
     * 
     * @methodOf arq-spa-base.recursos.directives:sfMenuNavegacao
     * 
     * @description
     * Método responsável por definir a diretiva "sfMenuNavegacao".
     */
    function sfMenuNavegacao() {
        return {
            restrict: "A",
            replace: true,
            transclude: true,
            template: "<div ng-class='navegacaoClass' ng-transclude></div>"
        };
    }
})();


(function () {
    "use strict";

    angular.module("arq-spa-base.controles-visuais").factory("sfObterMenu", sfObterMenu);

    sfObterMenu.$inject = ["$http", "appSettings", "sfUtilitarios", "sfConectorAPI", "sfLogger", "$q"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.menu.factories:sfObterMenu
     * @module arq-spa-base.menu
     * 
     * @requires $http
     * @requires appSettings
     * @requires sfUtilitarios
     * @requires sfConectorAPI
     * 
     * @description
     * Factory responsável por obter arquivos de configuração de menu
     */
    function sfObterMenu($http, appSettings, sfUtilitarios, sfConectorAPI, sfLogger, $q) {
        var listaMenu = [];
        return {
            consultar: consultar,
            obterItensBusca: obterItensBusca
        };

        /**
         * @ngdoc method
         * @name consultar
         *
         * @methodOf arq-spa-base.menu.factories:sfObterMenu
         * 
         * @requires nomeMenu
         *  
         * @description
         * Método responsável por retornar os itens de um menu e suas propriedades, exibindo Loader durante o processamento.
         * 
         * @param {string} nomeMenu Nome do menu que será consultado no backend.
         * @param {boolean} exibirLoader Indicador se o loader deve ser exibido ou não.
         */
        function consultar(nomeMenu, forcarBusca, exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfObterMenu.consultar", "", "", "Info",
                { classe: "sfObterMenu", metodo: "consultar" });
            var aplicacao = appSettings.configuracao.aplicacao;

            var configHttp = {
                method: "GET",
                url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "menus", aplicacao, nomeMenu])
            };

            var menu = buscarMenu(nomeMenu);

            var deferred = $q.defer();

            if (!angular.isDefined(menu)) {
                sfConectorAPI.executar(configHttp, exibirLoader).then(sucessoConsulta).catch(erroConsulta);
            } else {
                deferred.resolve(menu.estrutura);
            }

            return deferred.promise;

            /**
             * @ngdoc method
             * @name sucessoConsulta
             *
             * @methodOf arq-spa-base.menu.factories:sfObterMenu
             *  
             * @description
             * Método responsável tratar a resposta de sucesso ao obterMenu.
             * 
             */
            function sucessoConsulta(response) {
                sfLogger.escreverLogExecucao("Término de execução.", "sfObterMenu.consultar", "", "", "Info",
                    { classe: "sfObterMenu", metodo: "sucessoConsulta" });

                listaMenu = listaMenu.filter(function (menu) {
                    return menu.nome !== nomeMenu;
                });

                var menu = {
                    nome: nomeMenu,
                    estrutura: response
                };

                listaMenu.push(menu);
                deferred.resolve(menu.estrutura);
            }

            /**
             * @ngdoc method
             * @name erroConsulta
             *
             * @methodOf arq-spa-base.menu.factories:sfObterMenu
             *  
             * @description
             * Método responsável tratar a resposta de erro ao obterMenu.
             * 
             */
            function erroConsulta(msg) {
                sfLogger.escreverLogExecucao("Término de execução.", "sfObterMenu.consultar", "", "", "Info",
                    { classe: "sfObterMenu", metodo: "erroConsulta" });
                deferred.reject(msg);
            }

            /**
             * @ngdoc method
             * @name buscarMenu
             *
             * @methodOf arq-spa-base.menu.factories:sfObterMenu
             *  
             * @description
             * Método responsável por recuperar a estrutura do menu
             * 
             */
            function buscarMenu(nomeMenu) {
                if (forcarBusca === true) {
                    return undefined;
                }

                var menuRecuperado;
                listaMenu.some(function (item) {
                    if (item.nome === nomeMenu) {
                        menuRecuperado = {
                            menu: item.nome,
                            estrutura: item.estrutura
                        };
                    }
                });
                return menuRecuperado;
            }
        }

        /**
         * @ngdoc method
         * @name consultar
         *
         * @methodOf arq-spa-base.menu.factories:sfObterMenu
         * 
         * @requires nomeMenu
         *  
         * @description
         * Método responsável por retornar os itens de um menu e suas propriedades, exibindo Loader durante o processamento.
         * 
         * @param {string} nomeMenu Nome do menu que será consultado no backend.
         * @param {string} forcarBusca Indicador se deve forçar a busca independente do armazenamento do menu em memória.
         * @param {boolean} exibirLoader Indicador se o loader deve ser exibido ou não.
         */
        function obterItensBusca(nomeMenu, forcarBusca, exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfObterMenu.obterItensBusca", "", "", "Info",
                { classe: "sfObterMenu", metodo: "obterItensBusca" });

            var deferred = $q.defer();

            consultar(nomeMenu, forcarBusca, exibirLoader)
                .then(sucessoConsulta)
                .catch(erroConsulta);

            return deferred.promise;

            /**
             * @ngdoc method
             * @name sucessoConsulta
             *
             * @methodOf arq-spa-base.menu.factories:sfObterMenu
             *  
             * @description
             * Método responsável tratar a resposta de sucesso ao obterMenu.
             * 
             */
            function sucessoConsulta(response) {
                var menuBuscaViva = [];

                if (angular.isDefined(response) &&
                    angular.isDefined(response.data) &&
                    angular.isArray(response.data.itens)) {
                    montarItensMenuBusca(response.data.itens);
                }

                deferred.resolve(menuBuscaViva);

                /**
                 * @ngdoc method
                 * @name montarItensMenuBusca
                 *
                 * @methodOf arq-spa-base.menu.factories:sfObterMenu
                 *  
                 * @description
                 * Método responsável montar a lista de itens para a busca viva.
                 * 
                 */
                function montarItensMenuBusca(listaItens, descricaoAnterior) {
                    descricaoAnterior = descricaoAnterior || "";
                    listaItens.forEach(function (item) {
                        var fluxo;
                        var descricao;
                        var descricaoCompleta;
                        var culturaPadrao = item.culturaPadrao;

                        if (angular.isDefined(item.fluxo)) {
                            fluxo = item.fluxo;
                        }

                        var itemDescricao = item.descricoes.filter(function (descricao) {
                            return descricao.cultura === culturaPadrao;
                        });

                        if (angular.isDefined(itemDescricao) &&
                            angular.isArray(itemDescricao) &&
                            itemDescricao.length > 0) {
                            descricao = itemDescricao[0].valor || "";
                            descricaoCompleta = descricaoAnterior.length > 0 ? descricaoAnterior.concat("|", descricao) : descricao;
                        }

                        if (angular.isDefined(fluxo) &&
                            fluxo.length > 0 &&
                            angular.isDefined(descricao) &&
                            descricao.length > 0 &&
                            angular.isDefined(descricaoCompleta) &&
                            descricaoCompleta.length > 0) {
                            menuBuscaViva.push({
                                descricao: descricao,
                                descricaoCompleta: descricaoCompleta,
                                fluxo: fluxo
                            });
                        }

                        if (angular.isDefined(item.itens) &&
                            angular.isArray(item.itens) &&
                            item.itens.length > 0) {
                            montarItensMenuBusca(item.itens, descricaoCompleta);
                        }

                    }, this);
                }
            }

            /**
             * @ngdoc method
             * @name erroConsulta
             *
             * @methodOf arq-spa-base.menu.factories:sfObterMenu
             *  
             * @description
             * Método responsável tratar a resposta de erro ao obterMenu.
             * 
             */
            function erroConsulta(msg) {
                sfLogger.escreverLogExecucao("Término de execução.", "sfObterMenu.obterItensBusca", "", "", "Info",
                    { classe: "sfObterMenu", metodo: "erroConsulta" });
                deferred.reject(msg);
            }
        }
    }
})();


(function () {
    "use strict";

    angular.module("arq-spa-base.controles-visuais").factory("sfGeradorQRCode", sfGeradorQRCode);

    sfGeradorQRCode.$inject = ["appSettings", "sfUtilitarios", "sfConectorAPI", "sfLogger"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.menu.factories:sfGeradorQRCode
     * @module arq-spa-base.menu
     * 
     * @requires $http
     * @requires appSettings
     * @requires sfUtilitarios
     * @requires sfConectorAPI
     * 
     * @description
     * Factory responsável por gerar um QRCode a partir da chamada do serviços canal
     */
    function sfGeradorQRCode(appSettings, sfUtilitarios, sfConectorAPI, sfLogger) {
        return {
            gerar: gerar
        };

        /**
         * @ngdoc method
         * @name gerar
         *
         * @methodOf arq-spa-base.menu.factories:sfGeradorQRCode
         * 
         * @requires texto
         *  
         * @description
         * Método responsável por retornar a string do QRCode, exibindo Loader durante o processamento.
         * 
         * @param {string} texto texto que será gerado no valor do QRCode.
         * @param {boolean} exibirLoader Indicador se o loader deve ser exibido ou não.
         * @param {string} mensagem mensagem que será exibida no loader.
         */
        function gerar(texto, exibirLoader, mensagem) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfGeradorQRCode.gerar", "", "", "Info",
                { classe: "sfGeradorQRCode", metodo: "gerar" });

            var configHttp = {
                method: "POST",
                url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "qrcode"]),
                data: { texto: texto }
            };

            sfLogger.escreverLogExecucao("Fim de execução.", "sfGeradorQRCode.gerar", "", "", "Info",
                { classe: "sfGeradorQRCode", metodo: "gerar" });
            return sfConectorAPI.executar(configHttp, exibirLoader, mensagem);
        }
    }
})();


(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.controles-visuais.directives:sfRecebimentoConteudo
     * @module arq-spa-base.controles-visuais
     *
     * @description
     * 
     */
    angular.module("arq-spa-base.controles-visuais").directive("sfRecebimentoConteudo", sfRecebimentoConteudo);

    sfRecebimentoConteudo.$inject = ["$window", "sfObterConteudo", "sfLogger", "sfNavegador"];

    /**
     * @ngdoc overview
     * @name sfRecebimentoConteudo
     *
     * @methodOf arq-spa-base.controles-visuais.directives:sfRecebimentoConteudo
     *
     * @description Diretiva de recebimento de conteúdo, renderizando um html e definindo uma ação
     * de click para navegar ou abrir uma url
     * 
     */
    function sfRecebimentoConteudo($window, sfObterConteudo, sfLogger, sfNavegador) {

        /**
         * @ngdoc overview
         * @name renderizar
         *
         * @methodOf arq-spa-base.controles-visuais.directives:sfRecebimentoConteudo
         *
         * @description Método de que irá consultar o conteúdo e definir a ação a ser tomada.
         * 
         */
        function renderizar(scope_) {
            var tipo, url, fluxoDestino;

            sfObterConteudo.consultar(scope_.identificacao, scope_.parametros, false)
                .then(sucessoRecuperarConteudo)
                .catch(erroRecuperarConteudo);


            /**
             * @ngdoc overview
             * @name acaoConteudo
             *
             * @methodOf arq-spa-base.controles-visuais.directives:sfRecebimentoConteudo
             *
             * @description Método que irá resolver o click, definindo a ação de abrir uma url 
             * ou iniciar um fluxo.
             * 
             */
            function acaoConteudo() {

                if (angular.isDefined(tipo) && tipo === "url" &&
                    angular.isDefined(fluxoDestino) && fluxoDestino !== "") {
                    $window.open(fluxoDestino, "_blank");
                }
                else if (angular.isDefined(tipo) && tipo === "fluxo" &&
                    angular.isDefined(fluxoDestino) && fluxoDestino !== "") {
                    sfNavegador.iniciarFluxo(fluxoDestino, scope_.parametros);
                }
                else {
                    sfLogger.escreverLogErro("Ação do conteúdo não executada, tipo, url e fluxoDestino não parametrizados", "", "Baixa",
                        { classe: "sfRecebimentoConteudo", metodo: "acaoConteudo" });
                }
            }

            /**
             * @ngdoc overview
             * @name sucessoRecuperarConteudo
             *
             * @methodOf arq-spa-base.controles-visuais.directives:sfRecebimentoConteudo
             *
             * @description Método de sucesso na recuperaçao de conteúdo, definindo as variáveis
             * e ações da diretiva
             * 
             */
            function sucessoRecuperarConteudo(response) {
                if (angular.isDefined(response.data) &&
                    angular.isArray(response.data) && response.data.length > 0) {

                    var conteudo = response.data[0];

                    if (angular.isArray(conteudo.definicoes) && conteudo.definicoes.length > 0) {
                        var definicao = conteudo.definicoes[0];

                        fluxoDestino = definicao.urlDestino;
                        url = definicao.urlOrigem;
                        tipo = definicao.tipo;

                        var urlSegura = sfObterConteudo.verificarPermissaoUrl(url);
                        if (!urlSegura) {
                            throw new Error("A url " + url + " não está cadastrada na lista de sites permitidos no appSettings. O conteúdo não será exibido");
                        }
                        scope_.conteudo = url;
                    }

                    if (angular.isDefined(scope_.enviarParametros())) {
                        prepararEnvioParametros();
                    }

                    scope_.parametros = conteudo.parametros;
                    scope_.acaoConteudo = acaoConteudo;
                    scope_.url = url;
                    scope_.visibilidade = "visible";
                } else {
                    scope_.visibilidade = "hidden";
                    sfLogger.escreverLogErro("Contéudo esperado não retornado." + "\n" + response, null, "Baixa",
                        { classe: "sfRecebimentoConteudo", metodo: "renderizar.sucessoRecuperarConteudo" });
                }

                /**
                 * @ngdoc overview
                 * @name prepararEnvioParametros
                 *
                 * @methodOf arq-spa-base.controles-visuais.directives:sfRecebimentoConteudo
                 *
                 * @description Método que executa a função parametrizada via atributo da diretiva
                 * retornando via parametrização os parametros oriundos do serviço de canais recebimento de conteúdo 
                 * 
                 */
                function prepararEnvioParametros() {
                    conteudo.parametros.inicioVigencia = conteudo.inicioVigencia;
                    conteudo.parametros.fimVigencia = conteudo.fimVigencia;

                    var fnEnviarParametrosParametros = scope_.enviarParametros();
                    fnEnviarParametrosParametros(conteudo.parametros);
                }
            }

            /**
             * @ngdoc overview
             * @name erroRecuperarConteudo
             *
             * @methodOf arq-spa-base.controles-visuais.directives:sfRecebimentoConteudo
             *
             * @description Método de erro na recuperaçao de conteúdo,
             * 
             */
            function erroRecuperarConteudo(msg) {
                scope_.visibilidade = "hidden";
                sfLogger.escreverLogErro("Erro na consulta de conteúdo." + "\n" + msg, "", "Alta",
                    { classe: "sfRecebimentoConteudo", metodo: "renderizar.erroRecuperarConteudo" });
            }
        }

        return {
            restrict: "E",
            scope: {
                identificacao: "@sfRecebimentoConteudoIdentificacao",
                parametros: "@sfRecebimentoConteudoParametros",
                altura: "@sfRecebimentoConteudoAltura",
                largura: "@sfRecebimentoConteudoLargura",
                enviarParametros: "&sfRecebimentoConteudoObterParametros"
            },
            link: renderizar,
            template: "<div id=\"framearea\" style=\"height: {{::altura}}; width: {{::largura}}; cursor: pointer; visibility: {{::visibilidade}}\" ng-click=\"acaoConteudo()\" tabindex=\"-1\"><div id=\"framecover\" style=\"position: absolute; z-index: 2; height:{{::altura}}; width:{{::largura}}\"><svg ng-attr-width=\"{{::largura}}\" ng-attr-height=\"{{::altura}}\"><rect ng-attr-width=\"{{::largura}}\" ng-attr-height=\"{{::altura}}\" fill-opacity=\"0\" fill=\"white\"></svg></div><iframe ng-src=\"{{::conteudo}}\" width=\"{{::largura}}\" height=\"{{::altura}}\" scrolling=\"no\" tabindex=\"-1\" frameborder=\"0\" sandbox></iframe></div>"
        };
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.controles-visuais.factories:sfObterConteudo
     * @module arq-spa-base.controles-visuais
     *
     * @description
     * 
     */
    angular.module("arq-spa-base.controles-visuais").factory("sfObterConteudo", sfObterConteudo);

    sfObterConteudo.$inject = ["$http", "appSettings", "sfUtilitarios", "sfConectorAPI", "sfLogger"];

    /**
     * @ngdoc overview
     * @name sfObterConteudo
     *
     * @methodOf arq-spa-base.controles-visuais.factories:sfObterConteudo
     *
     * @description
     * 
     */
    function sfObterConteudo($http, appSettings, sfUtilitarios, sfConectorAPI, sfLogger) {
        return {
            consultar: consultar,
            verificarPermissaoUrl: verificarPermissaoUrl
        };

        /**
         * @ngdoc overview
         * @name consultar
         *
         * @methodOf arq-spa-base.controles-visuais.factories:sfObterConteudo
         *
         * @description Método responsável por realizar a requisição de recebimento de conteúdo para o serviço canal 
         * 
         * @returns {string} identificacao
         * @returns {array of objects} parametros
         * @returns {boolean} exibirLoader
         * 
         */
        function consultar(identificacao, parametros, exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfObterConteudo.consultar", "", "", "Info",
                { classe: "sfObterConteudo", metodo: "consultar" });

            identificacao = identificacao || "";
            parametros = parametros || "";

            var params = {
                identificacao: identificacao,
                parametros: parametros
            };

            if (params.identificacao === "") {
                delete params.identificacao;
            }

            if (params.parametros === "") {
                delete params.parametros;
            }

            var configHttp = {
                method: "GET",
                url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "recebimento-conteudo"]),
                params: params
            };

            sfLogger.escreverLogExecucao("Término de execução.", "sfObterConteudo.consultar", "", "", "Info",
                { classe: "sfObterConteudo", metodo: "consultar" });
            return sfConectorAPI.executar(configHttp, exibirLoader);
        }


        /**
         * @ngdoc overview
         * @name consultar
         *
         * @methodOf arq-spa-base.controles-visuais.factories:sfObterConteudo
         *
         * @description Método responsável por verificar se a url (http://**) está adicionada na lista de permissões
         * 
         * @returns {string} urlOrigem
         * 
         */
        function verificarPermissaoUrl(urlOrigem) {
            if (!sfUtilitarios.comecaCom(urlOrigem, "http")) { return true; }
            else {
                var existeUrl = appSettings.configuracao.seguranca.urlWhiteList.some(function (urlCadastrada) {
                    if (sfUtilitarios.contem(urlCadastrada, "/**")) {
                        urlCadastrada = urlCadastrada.substring(0, urlCadastrada.indexOf("/**"));
                        return sfUtilitarios.contem(urlOrigem, urlCadastrada);
                    } else {
                        return urlOrigem === urlCadastrada;
                    }
                });

                return existeUrl;
            }
        }
    }
})();
(function () {
    "use strict";

    angular.module("arq-spa-base.controles-visuais").directive("sfSpinner", sfSpinner);

    sfSpinner.$inject = ["$window", "appSettings", "$compile"];

    /**
     * @ngdoc directive
     * @name arq-spa-base.spinner: sfSpinner
     * @module arq-spa-base.spinner
     * 
     * @description      
     * Responsável por exibir o spinner utilizando spin.js
     */
    function sfSpinner($window, appSettings, $compile) {
        return {
            restrict: "E",
            scope: {
                "loader": "@"
            },
            link: function link(scope, element) {
                element.css("display", "inline-block");
                element.css("vertical-align", "middle");

                var spinner = null;

                /**
                 * @ngdoc method
                 * @name sfSpinner: iniciar
                 * @module arq-spa-base.spinner
                 * 
                 * @description
                 * Responsável por iniciar o movimento do spinner
                 */
                function iniciar() {
                    if (spinner) {
                        if (appSettings.tipoSpinner.gif === true) {
                            $compile(spinner)(scope);
                            element.append(spinner);
                        } else {
                            spinner.spin(element[0]);
                        }
                    }
                }

                /**
                 * @ngdoc method
                 * @name sfSpinner: parar
                 * @module arq-spa-base.spinner
                 * 
                 * @description
                 * Responsável por parar o movimento do spinner
                 */
                function parar() {
                    if (spinner && appSettings.tipoSpinner.gif !== true) {
                        spinner.spin();
                    }
                }

                /**
                 * @ngdoc method
                 * @name sfSpinner: criarSpinner
                 * @module arq-spa-base.spinner
                 * 
                 * @description
                 * Responsável por criar o componente spinner utilizando a biblioteca Spin.js
                 */
                function criarSpinner() {
                    parar();

                    if (appSettings.tipoSpinner.gif === true) {
                        spinner = angular.element("<span/>");
                        spinner.addClass("spinner-imagem");
                        if (scope.loader) {
                            spinner.addClass("loader-imagem");
                        }              
                    } else if (scope.loader) {
                        spinner = new $window.Spinner({
                            color: appSettings.tipoSpinner.loader.color
                        });
                    } else {
                        element.css("height", appSettings.tipoSpinner.spinner.elementHeight);
                        element.css("width", appSettings.tipoSpinner.spinner.elementWidth);
                        spinner = new $window.Spinner({
                            "top": appSettings.tipoSpinner.spinner.top,
                            "left": appSettings.tipoSpinner.spinner.left,
                            "position": appSettings.tipoSpinner.spinner.position,
                            "zIndex": appSettings.tipoSpinner.spinner.zIndex,
                            "length": appSettings.tipoSpinner.spinner.length,
                            "width": appSettings.tipoSpinner.spinner.width,
                            "radius": appSettings.tipoSpinner.spinner.radius,
                            "color": appSettings.tipoSpinner.spinner.color
                        });
                    }
                    iniciar();
                }

                scope.$on("$destroy", function () {
                    parar();
                    spinner = null;
                });

                criarSpinner();
            }
        };
    }
})();

(function () {
  "use strict";

  /**
   * @ngdoc overview
   * @name arq-spa-base.tree.directives:sfUiTreeSelecionarParents
   * @module arq-spa-base.tree
   *
   * @description
   * 
   */
  angular.module("arq-spa-base.controles-visuais").directive("sfUiTreeSelecionarParents", sfUiTreeSelecionarParents);

  sfUiTreeSelecionarParents.$inject = ["sfUtilitarios", "$window"];
  /**
   * @ngdoc overview
   * @name sfUiTreeSelecionarParents
   *
   * @methodOf arq-spa-base.tree.directives:sfUiTreeSelecionarParents
   *
   * @description
   * 
   */
  function sfUiTreeSelecionarParents(sfUtilitarios, $window) {
    return {
      restrict: "A",
      require: ["^uiTreeNode", "^uiTreeNodes", "^uiTree"],
      terminal: false,
      scope: {
        sfUiTreeSelecionarParentsSubItens: "@sfUiTreeSelecionarParentsSubItens",
        sfUiTreeSelecionarParentsCheck: "@sfUiTreeSelecionarParentsCheck"
      },
      link: linkSelecionarParents
    };

    /**
    * ngdoc method
    * @name linkSelecionarParents
    * 
    * @methodOf arq-spa-base.navegacao.directives:linkSelecionarParents
    * 
    * @description
    * Função responsável pelo tratamento de LINK da diretiva
    */
    function linkSelecionarParents(scope_, element_) {
      element_.bind("change", eventoChecked);

      /**
       * ngdoc method
       * @name eventoChecked
       * 
       * @methodOf arq-spa-base.navegacao.directives:eventoChecked
       * 
       * @description
       * Método responsável por tratar o evento "click" do elemento ao qual a diretiva está associado e efetuar a inicialização do fluxo definido como parâmetro.
       */
      function eventoChecked() {
        scope_.$apply(function () {

          var propriedadesBrowser = sfUtilitarios.verificarBrowser($window.navigator);

          //Verificando se é IE ou Safari, para o change do checkbox é inverso do firefox e chrome.
          if ($window.navigator.userAgent.match(/(.NET)|(MSIE)/) ||
            propriedadesBrowser.navegador.match(/(SAFA)/)) {
            scope_.$parent.$modelValue[scope_.sfUiTreeSelecionarParentsCheck] = !scope_.$parent.$modelValue[scope_.sfUiTreeSelecionarParentsCheck];
          }

          alterarFilhos(scope_.$parent.$modelValue[scope_.sfUiTreeSelecionarParentsCheck], scope_.$parent.$modelValue[scope_.sfUiTreeSelecionarParentsSubItens]);

          if (angular.isDefined(scope_.$parent.$parent.$parent.$parent.$modelValue)) {
            alterarPais(scope_.$parent.$parent.$parent.$parent);
          }
        });
      }

      /**
       ngdoc method
       * @name alterarFilhos
       * 
       * @methodOf arq-spa-base.navegacao.directives:alterarFilhos
       * 
       * @description
       * Método responsável por alterar o "checkbox" dos filhos a partir da mudança do pai
       */
      function alterarFilhos(valor_, filhos_) {
        if (angular.isDefined(filhos_) && angular.isArray(filhos_)) {
          filhos_.forEach(function (filho) {
            filho[scope_.sfUiTreeSelecionarParentsCheck] = valor_;

            var filhos = filho[scope_.sfUiTreeSelecionarParentsSubItens];

            if (angular.isDefined(filho[scope_.sfUiTreeSelecionarParentsSubItens])) {
              alterarFilhos(valor_, filhos);
            }
          });
        }
      }

      /**
      * ngdoc method
      * @name alterarPais
      * 
      * @methodOf arq-spa-base.navegacao.directives:alterarPais
      * 
      * @description
      * Método responsável por alterar o "checkbox" dos pais a partir de uma mudança de um filho
      */
      function alterarPais(pai_) {
        if (angular.isDefined(pai_.$modelValue)) {
          var filhos = pai_.$modelValue[scope_.sfUiTreeSelecionarParentsSubItens];

          if (angular.isDefined(filhos) && angular.isArray(filhos)) {
            var resultado;

            filhos.some(function (filho) {
              return resultado = !filho[scope_.sfUiTreeSelecionarParentsCheck];
            });

            pai_.$modelValue[scope_.sfUiTreeSelecionarParentsCheck] = !resultado;
          }

        }

        if (!angular.isDefined(pai_.$parent.$type) || pai_.$parent.$type !== "uiTree") {
          alterarPais(pai_.$parent);
        }
      }
    }
  }
})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.controles-visuais
     * 
     * @requires spinjs
     * 
     * @description
     * Módulo que disponibiliza a criptografia disponibilizada pela arquitetura
     */
    angular.module("arq-spa-base.criptografia", []);
})();
(function () {
    "use strict";

    /**
     * 
     * @ngdoc constant
     * @name arq-spa-base.criptografia.constants
     * @module arq-spa-base.criptografia
     * 
     * @description
     * Constantes que armazenam as configurações da criptografia.
     */
    angular.module("arq-spa-base.criptografia").constant("sfChaves", {
        cpvt: "LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQ0KTUlJQ1hRSUJBQUtCZ1FDY3pWcmtaNEV2eGkxellvVkIvS2FkYjBlU28ycEd4Uk1vV0puVDJFRktlTUYzTHQwZQ0Kd01PNnVBM0xWSnhoc3cvelE1MGczL2xvaHRkMHc4WUIzMVYybHVQQnZYbk9tRTljaVhmaVdBSzNOb0dyWFlJNw0KbEdSeVVZRUlJQXFqdXJxaW0vVnBxQWRJbm9HaUVBTFMzVXlYMVp0Nk5vZ2dnT1JZWGlka21VQ1RhUUlEQVFBQg0KQW9HQWZvbmFoK2hmZ01aVmQ0QlNPZVpDTDFyV1Q2aEE0OHUyb2lDZVF5K0p3U2VpT1NSQW5jakNLN1RNclFJag0KRVZVSDBqRUdaTGxhOU5lY21FWkZUTTJHa1dEL21ZM1pxTktlRDFsV0VKcEdLblBXUmczeW15SE1RejROa1ljUg0KTHc3WHVUVUhqZ3VaYy9EQks0aEo1WFVUajlrcnBYOWdwSkRrTHhNK3NJcTA1QUVDUVFEWHpXNUpyRVBjVHl2VQ0KcUJBcVhId1kxeTJNb3ZXdmp0dldKUlZsZzY5ZFp2cWgweFl6SDgyVzlTdjJ5ZXB0YlQ0VHBmc0lHYmdaWjk5Yg0KUExrS2x3aVJBa0VBdWdKOHZtZy9nMUN2d3EveE81aC8vcmoyLytFTWorRFUrRnFzSFJDZ0JtWVdsaTk2SUVIbQ0KM1FGMlpyaGJmVEE0Unh5VE9iVnlNWjVSS3ZlcHNSbUpXUUpCQUlnVVpJMVVjVjVGRmxCOHdlVFVlUFI1QzZINQ0KU0kreHQvSnJZL2lsZHptZ3JEN0xDdDZtR1ZBdHZkRmJOZFpXNHFRbE1BekZtdzk2THFBcnhFdG5QZUVDUUhodg0KWGRkbTVpQ2U0SDRjcndPWU5OOTNZUzNCeUFGc1lGaEJWUWtvbDRRdEcxaTRlc2xpQWhsOGRlNENWZkpUZzB5Lw0KdXE5MXhPOU5nMTVmcHJadFExa0NRUUN4RFBJejc0ZzIxUW9sNTJoUHA4MEpTVE1TY3cybUdkZnd6dC9Zb1NtKw0KUVc0M1BJaUdJemVWWUZVWXN1bWx2Qm00aldRdHc4djZFeEhXVHNIcHUxSFUNCi0tLS0tRU5EIFJTQSBQUklWQVRFIEtFWS0tLS0t",
        cpbc: "LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0NCk1JR2ZNQTBHQ1NxR1NJYjNEUUVCQVFVQUE0R05BRENCaVFLQmdRQ2N6VnJrWjRFdnhpMXpZb1ZCL0thZGIwZVMNCm8ycEd4Uk1vV0puVDJFRktlTUYzTHQwZXdNTzZ1QTNMVkp4aHN3L3pRNTBnMy9sb2h0ZDB3OFlCMzFWMmx1UEINCnZYbk9tRTljaVhmaVdBSzNOb0dyWFlJN2xHUnlVWUVJSUFxanVycWltL1ZwcUFkSW5vR2lFQUxTM1V5WDFadDYNCk5vZ2dnT1JZWGlka21VQ1RhUUlEQVFBQg0KLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0t"
    });
})();
(function () {
    "use strict"; angular.module("arq-spa-base.criptografia").factory("sfCriptografia", sfCriptografia);

    sfCriptografia.$inject = ["$window", "sfContexto", "$injector"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.criptografia.factories:sfCriptografia
     * @module arq-spa-base.criptografia
     * 
     * @requires $window
     * 
     * @description
     * Método responsável por definir as funções responsáveis pelo payload.
     */
    function sfCriptografia($window, sfContexto, $injector) {
        var algoritmo = "AES-CTR";

        return {
            criptografarPayloadJWE: criptografarPayloadJWE,
            descriptografarPayloadJWE: descriptografarPayloadJWE,
            criptografarComChaveAssimetrica: criptografarComChaveAssimetrica,
            descriptografarComChaveAssimetrica: descriptografarComChaveAssimetrica
        };

        /**
         * @ngdoc object
         * @name criptografarPayloadJWE
         *
         * @methodOf arq-spa-base.criptografia.factories:criptografarPayloadJWE
         *  
         * @description
         * Método responsável por criptografar as informações para um JWE criptografado 
         * 
         * @param {STRING} texto 
         * 
         * @returns JWE em base 64
         */
        function criptografarPayloadJWE(data) {
            var sfLogger = $injector.get("sfLogger");
            sfLogger.escreverLogExecucao("Início de execução.", "sfCriptografia.criptografarPayloadJWE", "", "", "Info",
                { classe: "sfCriptografia", metodo: "criptografarPayloadJWE" });

            var chaveSimetrica = sfContexto.obterValorContextoSessao("chaveSimetrica");

            if (chaveSimetrica !== "") {
                var header = { alg: "RSA-AEP", enc: "A256CTR" };
                var iv = $window.forge.random.getBytes(16);
                var mensagem = $window.forge.util.createBuffer(JSON.stringify(data), "utf8");
                var cipher = $window.forge.cipher.createCipher(algoritmo, chaveSimetrica);
                cipher.start({ iv: iv });
                cipher.update(mensagem);
                cipher.finish();

                var mensagemCifrada = cipher.output;

                var headerBase64 = codificarBase64(JSON.stringify(header));
                var ivBase64 = $window.forge.util.encode64(iv);
                var mensagemCifradaBase64 = mensagemCifrada.getBytes();
                mensagemCifradaBase64 = $window.forge.util.encode64(mensagemCifradaBase64);

                var jwe = headerBase64 + "." + "." + ivBase64 + "." + mensagemCifradaBase64 + ". ";

                sfLogger.escreverLogExecucao("Término de execução.", "sfCriptografia.criptografarPayloadJWE", "", "", "Info",
                    { classe: "sfCriptografia", metodo: "criptografarPayloadJWE" });
                return {
                    data: jwe
                };
            } else {
                throw new Error("A chave simétrica não está definida");
            }
        }

        /**
         * @ngdoc object
         * @name descriptografarPayloadJWE
         *
         * @methodOf arq-spa-base.criptografia.factories:descriptografarPayloadJWE
         *  
         * @description
         * Método responsável por descriptografar as informações contidas no JWE do payload
         * 
         * @param {object} JWE
         * 
         * @returns string
         */
        function descriptografarPayloadJWE(corpo) {
            var sfLogger = $injector.get("sfLogger");
            sfLogger.escreverLogExecucao("Início de execução.", "sfCriptografia.descriptografarPayloadJWE", "", "", "Info",
                { classe: "sfCriptografia", metodo: "descriptografarPayloadJWE" });

            var chaveSimetrica = sfContexto.obterValorContextoSessao("chaveSimetrica");

            if (chaveSimetrica !== "") {
                var dataArray = corpo.split(".");
                if (angular.isDefined(dataArray) && dataArray.length == 5 &&
                    dataArray[2] !== "" && dataArray[3] !== "") {

                    var iv = $window.forge.util.decode64(dataArray[2]);
                    var textoCifrado = $window.forge.util.decode64(dataArray[3]);
                    textoCifrado = $window.forge.util.createBuffer(textoCifrado);
                    var tag = $window.forge.util.decode64(dataArray[4]);

                    var cipher = $window.forge.cipher.createDecipher(algoritmo, chaveSimetrica);
                    cipher.start({ iv: iv, tag: tag });
                    cipher.update(textoCifrado);
                    if (!cipher.finish()) {
                        throw new Error("Erro ao descriptografar");
                    }

                    var mensagemDecifrada = JSON.parse(cipher.output);

                    sfLogger.escreverLogExecucao("Término de execução.", "sfCriptografia.descriptografarPayloadJWE", "", "", "Info",
                        { classe: "sfCriptografia", metodo: "descriptografarPayloadJWE" });
                    return mensagemDecifrada;
                } else {
                    throw new Error("Os dados retornados não estão na estrutura JWE");
                }
            } else {
                throw new Error("A chave simétrica não está definida");
            }
        }

        /**
         * @ngdoc object
         * @name criptografarComChaveAssimetrica
         *
         * @methodOf arq-spa-base.criptografia.factories:criptografarComChaveAssimetrica
         *  
         * @description
         * Método responsável por criptografar
         * 
         * @param {object} data informação que será criptografada
         * 
         * @returns string
         */
        function criptografarComChaveAssimetrica(data) {
            var sfLogger = $injector.get("sfLogger");
            sfLogger.escreverLogExecucao("Início de execução.", "sfCriptografia.criptografarComChaveAssimetrica", "", "", "Info",
                { classe: "sfCriptografia", metodo: "criptografarComChaveAssimetrica" });
            var sfChaves = $injector.get("sfChaves");
            if ("cpvt" in sfChaves &&
                "cpbc" in sfChaves) {
                var chavePublica = atob(sfChaves.cpbc);

                var crypt = new $window.JSEncrypt();
                crypt.setPrivateKey(chavePublica);
                var dadosCifrados = crypt.encrypt(data);

                sfLogger.escreverLogExecucao("Término de execução.", "sfCriptografia.criptografarComChaveAssimetrica", "", "", "Info",
                    { classe: "sfCriptografia", metodo: "criptografarComChaveAssimetrica" });
                return dadosCifrados;
            } else {
                sfLogger.escreverLogExecucao("Término de execução.", "sfCriptografia.criptografarComChaveAssimetrica", "", "", "Info",
                    { classe: "sfCriptografia", metodo: "criptografarComChaveAssimetrica" });
                return data;
            }
        }

        /**
         * @ngdoc object
         * @name descriptografarComChaveAssimetrica
         *
         * @methodOf arq-spa-base.criptografia.factories:descriptografarComChaveAssimetrica
         *  
         * @description
         * Método responsável por criptografar
         * 
         * @param {object} corpo informação que será descriptografada
         * 
         * @returns string
         */
        function descriptografarComChaveAssimetrica(data) {
            var sfLogger = $injector.get("sfLogger");
            sfLogger.escreverLogExecucao("Início de execução.", "sfCriptografia.descriptografarComChaveAssimetrica", "", "", "Info",
                { classe: "sfCriptografia", metodo: "descriptografarComChaveAssimetrica" });
            var sfChaves = $injector.get("sfChaves");

            if ("cpvt" in sfChaves &&
                "cpbc" in sfChaves) {
                var chavePrivada = atob(sfChaves.cpvt);

                var crypt = new $window.JSEncrypt();
                crypt.setPrivateKey(chavePrivada);
                var dadosDecifrados = crypt.decrypt(data);

                sfLogger.escreverLogExecucao("Término de execução.", "sfCriptografia.descriptografarComChaveAssimetrica", "", "", "Info",
                    { classe: "sfCriptografia", metodo: "descriptografarComChaveAssimetrica" });

                return dadosDecifrados;
            } else {
                sfLogger.escreverLogExecucao("Término de execução.", "sfCriptografia.descriptografarComChaveAssimetrica", "", "", "Info",
                    { classe: "sfCriptografia", metodo: "descriptografarComChaveAssimetrica" });

                return data;
            }
        }

        /**
         * @ngdoc object
         * @name codificarBase64
         *
         * @methodOf arq-spa-base.criptografia.factories:sfCriptografia
         *  
         * @description
         * Método responsável por converter o texto (cifrado) para base64
         * 
         * @param {object} texto (cifrado)
         * 
         * @returns texto em formato base64
         */
        function codificarBase64(texto) {
            var buffer = $window.forge.util.createBuffer(texto, "utf8");
            var binaryString = buffer.getBytes();
            return $window.forge.util.encode64(binaryString);
        }
    }
})();
(function () {
    "use strict";

    angular
        .module("arq-spa-base.criptografia")
        .factory("sfHandshake", sfHandshake);

    sfHandshake.$inject = ["$window", "appSettings", "sfUtilitarios", "sfConectorAPI", "sfContexto", "$q", "sfLogger", "sfChaves", "$rootScope", "$timeout"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.criptografia.factories:sfHandShake
     * @module arq-spa-base.criptografia
     * 
     * @requires $window
     * 
     * @description
     * Método responsável por definir as funções responsáveis pelo handshake.
     */
    function sfHandshake($window, appSettings, sfUtilitarios, sfConectorAPI, sfContexto, $q, sfLogger, sfChaves, $rootScope, $timeout) {
        var cliente = {
            chavePublica: "",
            chavePrivada: ""
        };
        var servidor = {
            chavePublica: "",
            chavePrivada: ""
        };
        var handshakeFinalizado = false;
        var renovacaoTimeoutPromise;

        return {
            iniciar: iniciar,
            statusHandshake: statusHandshake,
            tratarRenovacaoHandshake: tratarRenovacaoHandshake
        };

        /**
         * @ngdoc method
         * @name iniciar
         *
         * @methodOf arq-spa-base.criptografia.factories:sfHandShake
         *  
         * @description
         * Método responsável por iniciar o handshake da criptografia
         * 
         */
        function iniciar(chavesCliente) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfHandshake.iniciar", "", "", "Info",
                { classe: "sfHandshake", metodo: "iniciar" });

            if (angular.isDefined(renovacaoTimeoutPromise)) {
                $timeout.cancel(renovacaoTimeoutPromise);
            }

            var keysize = 1024;
            var deferred = $q.defer();

            if (!angular.isDefined(chavesCliente)) {
                if ("cpvt" in sfChaves &&
                    "cpbc" in sfChaves) {
                    cliente.chavePrivada = atob(sfChaves.cpvt);
                    cliente.chavePublica = atob(sfChaves.cpbc);

                    enviarChaves();
                } else {
                    sfLogger.escreverLogExecucao("Geração de chaves", "sfHandshake.iniciar", "", "", "Info",
                        { classe: "sfHandshake", metodo: "iniciar" });

                    var infoNavigator = sfUtilitarios.verificarBrowser($window.navigator);

                    if ((infoNavigator.navegador === "MSIE" && infoNavigator.versao >= 11) ||
                        infoNavigator.navegador === "CHRO" ||
                        infoNavigator.navegador === "FIRE") {
                        sfLogger.escreverLogExecucao("Utilizando biblioteca node forge - com workers.", "sfHandshake.iniciar", "", "", "Info",
                            { classe: "sfHandshake", metodo: "iniciar" });

                        var pki = $window.forge.pki;

                        try {
                            var pkiConfigs = { bits: keysize, workers: -1 };
                            pki.rsa.generateKeyPair(pkiConfigs, gerarChavesAssimetricasAsyncComWorker);
                        } catch (error) {
                            sfLogger.escreverLogExecucao("Erro de execução na biblioteca node forge.", "sfHandshake.iniciar", "", "", "Warn",
                                { classe: "sfHandshake", metodo: "iniciar" });
                            throw error;
                        }
                    } else {
                        sfLogger.escreverLogExecucao("Utilizando biblioteca jsencrypt - sem workers.", "sfHandshake.iniciar", "", "", "Info",
                            { classe: "sfHandshake", metodo: "iniciar" });

                        try {
                            var crypt = new $window.JSEncrypt({ default_key_size: keysize });
                            crypt.getKey(gerarChavesAssimetricasAsyncSemWorker);
                        } catch (error) {
                            sfLogger.escreverLogExecucao("Erro de execução na biblioteca jsencrypt.", "sfHandshake.iniciar", "", "", "Warn",
                                { classe: "sfHandshake", metodo: "iniciar" });
                            throw error;
                        }
                    }
                }
            } else {
                sfLogger.escreverLogExecucao("Reaproveitamento de chaves", "sfHandshake.iniciar", "", "", "Info",
                    { classe: "sfHandshake", metodo: "iniciar" });
                cliente.chavePrivada = chavesCliente.chavePrivada;
                cliente.chavePublica = chavesCliente.chavePublica;

                enviarChaves();
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfHandshake.iniciar", "", "", "Info",
                { classe: "sfHandshake", metodo: "iniciar" });
            return deferred.promise;

            /**
             * @ngdoc method
             * @name enviarChavePublica
             *
             * @methodOf arq-spa-base.criptografia.factories:enviarChavePublica
             *  
             * @description
             * Método responsável por enviar a chave pública do cliente
             * 
             */
            function enviarChavePublica() {
                sfLogger.escreverLogExecucao("Início de execução.", "sfHandshake.enviarChavePublica", "", "", "Info",
                    { classe: "sfHandshake", metodo: "enviarChavePublica" });

                /**
                 * @ngdoc method
                 * @name sucessoEnvio
                 *
                 * @methodOf arq-spa-base.criptografia.factories:sfHandShake
                 *  
                 * @description
                 * Método responsável por receber a chave pública do servidor, e preparar a session Id para envio
                 * 
                 */
                function sucessoEnvio(response) {
                    sfLogger.escreverLogExecucao("Término de execução.", "sfHandshake.enviarChavePublica", "", "", "Info",
                        { classe: "sfHandshake", metodo: "enviarChavePublica.sucessoEnvio" });
                    if (angular.isDefined(response.data) && angular.isObject(response.data)) {
                        if (angular.isDefined(response.data.jwk)) {
                            var jwkArray = response.data.jwk.split(".");

                            if (angular.isDefined(jwkArray) && jwkArray.length == 4) {
                                servidor.chavePublica = $window.forge.util.decode64(jwkArray[3]);

                                var sessionId = sfContexto.obterValorContextoSessao("IdSessao");
                                var hashAssinatura = gerarAssinatura(sessionId);

                                var crypt = new $window.JSEncrypt();
                                crypt.setPrivateKey(servidor.chavePublica);
                                var textoCifrado = crypt.encrypt(sessionId);

                                enviarTextoAssinado(textoCifrado, hashAssinatura);
                            } else {
                                throw new Error("Não foi possível identificar o conteúdo do objeto de mensagem.");
                            }
                        } else {
                            throw new Error("Não foi possível identificar o objeto de mensagem.");
                        }
                    } else {
                        throw new Error("Não foi possível identificar a mensagem de retorno.");
                    }
                }

                /**
                 * @ngdoc method
                 * @name erroEnvio
                 *
                 * @methodOf arq-spa-base.criptografia.factories:sfHandShake
                 *  
                 * @description
                 * Método responsável por informar o erro durante a obtenção da chave pública do servidor
                 * 
                 */
                function erroEnvio(msg) {
                    sfLogger.escreverLogExecucao("Término de execução.", "sfHandshake.enviarChavePublica", "", "", "Warn",
                        { classe: "sfHandshake", metodo: "enviarChavePublica.erroEnvio" });

                    if (!angular.isDefined(msg)) {
                        msg = {};
                        msg.chavesCliente = cliente;
                    } else {
                        msg.chavesCliente = cliente;
                    }

                    deferred.reject(msg);
                }

                var jwk = gerarAssinatura(sfContexto.obterValorContextoSessao("IdSessao")) + "." +
                    codificarBase64("RSA") + "." +
                    codificarBase64("enc") + "." +
                    codificarBase64("P-256") + "." +
                    codificarBase64(cliente.chavePublica);

                var configHttp = {
                    method: "POST",
                    url: sfUtilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "init"]),
                    data: { jwk: jwk },
                    handshake: true
                };

                sfConectorAPI.executar(configHttp, false).then(sucessoEnvio).catch(erroEnvio);
            }

            /**
             * @ngdoc method
             * @name enviarTextoAssinado
             *
             * @methodOf arq-spa-base.criptografia.factories:sfHandShake
             *  
             * @description
             * Método responsável por enviar o texto assinado para o servidor
             * 
             */
            function enviarTextoAssinado(textoCifrado, hashAssinatura) {

                /**
                 * @ngdoc method
                 * @name sucessoEnvio
                 *
                 * @methodOf arq-spa-base.criptografia.factories:sfHandShake
                 *  
                 * @description
                 * Método responsável por verificar se as sessions Id são iguais garantindo autenticidade
                 * 
                 */
                function sucessoEnvio(response) {
                    sfLogger.escreverLogExecucao("Início de execução.", "sfHandshake.enviarTextoAssinado", "", "", "Info",
                        { classe: "sfHandshake", metodo: "enviarTextoAssinado.sucessoEnvio" });
                    if (angular.isDefined(response.data) && response.data !== "" && angular.isString(response.data)) {
                        var parametros = response.data.split(".");
                        if (angular.isDefined(parametros) && parametros.length == 2) {
                            var textoCifrado = parametros[0];
                            var assinatura = parametros[1];

                            var crypt = new $window.JSEncrypt();
                            crypt.setPrivateKey(cliente.chavePrivada);
                            var jwkStringfied = crypt.decrypt(textoCifrado);

                            try {
                                jwkStringfied = JSON.parse(jwkStringfied);
                                var jwk = jwkStringfied.jwk;
                                var tempoExpiracao = jwkStringfied.exp;
                            } catch (err) {
                                throw err;
                            }

                            if (angular.isDefined(jwk) && angular.isDefined(jwk.kid) && jwk.kid !== "") {
                                var chaveSimetrica = $window.forge.util.decode64(jwk.kid);

                                var validacaoAssinatura = verificarAssinatura(chaveSimetrica, assinatura);
                                if (validacaoAssinatura) {
                                    sfContexto.definirValorContextoSessao("chaveSimetrica", chaveSimetrica);
                                    $rootScope.$broadcast("eventoHandshakeFinalizado");
                                    handshakeFinalizado = true;

                                    if (tempoExpiracao) {
                                        renovacaoTimeoutPromise = $timeout(tratarRenovacaoHandshake, tempoExpiracao * 1000);
                                    }

                                } else {
                                    throw new Error("Assinatura não é válida");
                                }
                            } else {
                                sfContexto.definirValorContextoSessao("chaveSimetrica", "");
                                handshakeFinalizado = false;
                                throw new Error("Chave não é válida.");
                            }
                        }

                        sfLogger.escreverLogExecucao("Término de execução.", "sfHandshake.enviarTextoAssinado", "", "", "Info",
                            { classe: "sfHandshake", metodo: "enviarTextoAssinado.sucessoEnvio" });
                        deferred.resolve(response);
                    } else {
                        throw new Error("Não foi possível identificar a mensagem de resposta.");
                    }
                }

                /**
                 * @ngdoc method
                 * @name erroEnvio
                 *
                 * @methodOf arq-spa-base.criptografia.factories:sfHandShake
                 *  
                 * @description
                 * Método responsável por informar o erro durante a obtenção da chave pública do servidor
                 * 
                 */
                function erroEnvio(msg) {
                    sfLogger.escreverLogExecucao("Término de execução.", "sfHandshake.iniciar.enviarTextoAssinado", "", "", "Info",
                        { classe: "sfHandshake", metodo: "enviarTextoAssinado.erroEnvio" });

                    if (!angular.isDefined(msg)) {
                        msg = {};
                        msg.chavesCliente = cliente;
                    } else {
                        msg.chavesCliente = cliente;
                    }

                    deferred.reject(msg);
                }

                var parametros = textoCifrado + "." + hashAssinatura;

                var configHttp = {
                    method: "POST",
                    url: sfUtilitarios.combinarCaminhos([appSettings.comunicacao.urlBackend, "init"]),
                    data: { parametros: parametros },
                    handshake: true
                };

                sfConectorAPI.executar(configHttp, false).then(sucessoEnvio).catch(erroEnvio);
            }

            /**
             * @ngdoc method
             * @name gerarChavesAssimetricasAsync
             *
             * @methodOf arq-spa-base.criptografia.factories:sfHandShake
             *  
             * @description
             * Método responsável por gerar as chaves assimétricas de forma assíncrona
             * 
             */
            function gerarChavesAssimetricasAsyncComWorker(err, keypair) {
                sfLogger.escreverLogExecucao("Início de execução.", "sfHandshake.gerarChavesAssimetricasAsyncComWorker", "", "", "Info",
                    { classe: "sfHandshake", metodo: "gerarChavesAssimetricasAsyncComWorker" });

                cliente.chavePrivada = pki.privateKeyToPem(keypair.privateKey);
                cliente.chavePublica = pki.publicKeyToPem(keypair.publicKey);

                enviarChaves();

                sfLogger.escreverLogExecucao("Término de execução.", "sfHandshake.gerarChavesAssimetricasAsyncComWorker", "", "", "Info",
                    { classe: "sfHandshake", metodo: "gerarChavesAssimetricasAsyncComWorker" });
            }

            /**
             * @ngdoc method
             * @name gerarChavesAssimetricasAsync
             *
             * @methodOf arq-spa-base.criptografia.factories:sfHandShake
             *  
             * @description
             * Método responsável por gerar as chaves assimétricas de forma assíncrona
             * 
             */
            function gerarChavesAssimetricasAsyncSemWorker() {
                sfLogger.escreverLogExecucao("Início de execução.", "sfHandshake.gerarChavesAssimetricasAsyncSemWorker", "", "", "Info",
                    { classe: "sfHandshake", metodo: "gerarChavesAssimetricasAsyncSemWorker" });

                cliente.chavePrivada = crypt.getPrivateKey();
                cliente.chavePublica = crypt.getPublicKey();

                enviarChaves();

                sfLogger.escreverLogExecucao("Término de execução.", "sfHandshake.gerarChavesAssimetricasAsyncSemWorker", "", "", "Info",
                    { classe: "sfHandshake", metodo: "gerarChavesAssimetricasAsyncSemWorker" });
            }

            /**
             * @ngdoc method
             * @name gerarChavesAssimetricasAsync
             *
             * @methodOf arq-spa-base.criptografia.factories:sfHandShake
             *  
             * @description
             * Método responsável por gerar as chaves assimétricas de forma assíncrona
             * 
             */
            function enviarChaves() {
                sfLogger.escreverLogExecucao("Início de execução.", "sfHandshake.enviarChaves", "", "", "Info",
                    { classe: "sfHandshake", metodo: "enviarChaves" });

                if (!sfContexto.verificarExistenciaContextoSessao("chaveSimetrica")
                    || sfContexto.obterValorContextoSessao("chaveSimetrica") === "") {
                    enviarChavePublica();
                }

                sfLogger.escreverLogExecucao("Término de execução.", "sfHandshake.enviarChaves", "", "", "Info",
                    { classe: "sfHandshake", metodo: "enviarChaves" });
            }
        }

        /**
         * @ngdoc object
         * @name tratarRenovacaoHandshake
         * 
         * @methodOf arq-spa-base.criptografia.services:tratarRenovacaoHandshake
         * 
         * @description
         * Método responsável por tratar a renovação do handshake
         * 
         */
        function tratarRenovacaoHandshake() {
            var numeroMaximoTentativas = appSettings.configuracao.criptografia.numeroMaximoTentativas || 1;
            var quantidadeTentativas = 0;

            sfContexto.definirValorContextoSessao("handshakeFinalizado", "");
            sfContexto.definirValorContextoSessao("chaveSimetrica", "");
            $rootScope.$broadcast("eventoExpiracaoHandshake");

            iniciar()
                .then(handshakeReiniciado)
                .catch(falhaReiniciarHandshake);

            /**
             * @ngdoc object
             * @name handshakeReiniciado
             *
             * @methodOf arq - spa - base.comunicacao.factories:gerenciadorComunicacao
             *  
             * @description
             * Método responsável por retornar uma exception informando que o handshake foi reiniciado
             * 
             */
            function handshakeReiniciado() {
                sfLogger.escreverLogExecucao("Handshake foi reiniciado após " + quantidadeTentativas + " tentativa(s).", "sfHandshake.tratarRenovacaoHandshake", "", "", "Info",
                    { classe: "sfHandshake", metodo: "handshakeReiniciado" });
                sfContexto.definirValorContextoSessao("handshakeFinalizado", "true");
            }

            /**
             * @ngdoc object
             * @name falhaReiniciarHandshake
             *
             * @methodOf arq-spa-base.comunicacao.factories:gerenciadorComunicacao
             *  
             * @description
             * Método responsável por retornar uma exception informando que ocorreu uma falha ao reiniciar handshake
             * 
             */
            function falhaReiniciarHandshake(err) {
                var delayTentativaHandshake = appSettings.configuracao.criptografia.delayTentativaHandshake || 500;

                $timeout(tentativaHandhsake, delayTentativaHandshake);

                /**
                 * @ngdoc object
                 * @name tentativaHandhsake
                 *
                 * @methodOf arq-spa-base.comunicacao.factories:gerenciadorComunicacao
                 *  
                 * @description
                 * Método responsável por tratar a tentativa de realizar o handshake
                 * 
                 */
                function tentativaHandhsake() {
                    quantidadeTentativas++;
                    if (quantidadeTentativas < numeroMaximoTentativas) {
                        iniciar(err.chavesCliente)
                            .then(handshakeReiniciado)
                            .catch(falhaReiniciarHandshake);
                    } else {
                        sfLogger.escreverLogExecucao("Handshake não foi reiniciado após " + quantidadeTentativas + " tentativas.", "sfHandshake.tratarRenovacaoHandshake", "", "", "Warn",
                            { classe: "sfHandshake", metodo: "falhaReiniciarHandshake" });
                        sfContexto.definirValorContextoSessao("handshakeFinalizado", "false");
                        $rootScope.$broadcast("eventoErroHandshake", quantidadeTentativas);
                    }
                }
            }
        }

        /**
         * @ngdoc object
         * @name statusHandshake
         * 
         * @methodOf arq-spa-base.criptografia.services:statusHandshake
         * 
         * @description
         * Método responsável por indicar se o sfHandShake já foi incializado ou não.
         * 
         * @returns {boolean} True caso o sfHandShake já tenha sido inciado ou false caso contrário. 
         */
        function statusHandshake() {
            return handshakeFinalizado;
        }

        /**
         * @ngdoc object
         * @name gerarAssinatura
         * 
         * @methodOf arq-spa-base.criptografia.services:gerarAssinatura
         * 
         * @description
         * Método responsável por gerar a assinatura para o servidor verificar a autenticidade e a integridade
         * 
         * @returns {string} Assinatura da sessionId em hash 256 em Base64  
         */
        function gerarAssinatura(sessionId) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfHandshake.gerarAssinatura", "", "", "Info",
                { classe: "sfHandshake", metodo: "gerarAssinatura" });

            var privateKey = $window.forge.pki.privateKeyFromPem(cliente.chavePrivada);
            var md = $window.forge.md.sha256.create();
            md.update(sessionId);

            sfLogger.escreverLogExecucao("Término de execução.", "sfHandshake.gerarAssinatura", "", "", "Info",
                { classe: "sfHandshake", metodo: "gerarAssinatura" });
            return $window.forge.util.encode64(privateKey.sign(md));
        }

        /**
         * @ngdoc object
         * @name verificarAssinatura
         * 
         * @methodOf arq-spa-base.criptografia.services:verificarAssinatura
         * 
         * @description
         * Método responsável por verificar a assinatura do servidor
         * 
         * @returns {boolean} True caso a autenticidade e a integradade foi validada com sucesso. 
         */
        function verificarAssinatura(conteudo, assinatura) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfHandshake.verificarAssinatura", "", "", "Info",
                { classe: "sfHandshake", metodo: "verificarAssinatura" });

            var publicKey = $window.forge.pki.publicKeyFromPem(servidor.chavePublica);
            var md = $window.forge.md.sha256.create();
            md.update(conteudo);

            assinatura = $window.forge.util.decode64(assinatura);

            sfLogger.escreverLogExecucao("Término de execução.", "sfHandshake.verificarAssinatura", "", "", "Info",
                { classe: "sfHandshake", metodo: "verificarAssinatura" });
            return publicKey.verify(md.digest().getBytes(), assinatura);
        }

        /**
         * @ngdoc object
         * @name codificarBase64
         *
         * @methodOf arq-spa-base.criptografia.factories:sfHandshake
         *  
         * @description
         * Método responsável por converter o texto (cifrado) para base64
         * 
         * @param {object} texto (cifrado)
         * 
         * @returns texto em formato base64
         */
        function codificarBase64(texto) {
            var buffer = $window.forge.util.createBuffer(texto, "utf8");
            var binaryString = buffer.getBytes();
            return $window.forge.util.encode64(binaryString);
        }
    }

})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.excecao
     * 
     * @description
     * Módulo  que provê os recursos necessários para o tratamento de exceção .
     */
    angular.module("arq-spa-base.excecao", []);
})();
(function () {
    "use strict";

    /**
    * @ngdoc overview
    * @name arq-spa-base.excecao.factories:tratarExcecao
    * @module arq-spa-base.excecao
    * 
    * @requires $injector
    * @requires appSettings
    * 
    * @description
    * Factory responsável por substituir o padrão de exception handler a fim de logar o erros não detectados.
    */

    angular.module("arq-spa-base.excecao").factory("$exceptionHandler", exceptionHandler);


    exceptionHandler.$inject = ["appSettings", "$injector", "$log"];

    /**
    * @ngdoc object
    * @name exceptionHandler
    *
    * @methodOf arq-spa-base.excecao.factories:excecao
    *  
    * @param {object} appSettings Instância do arquivo de configuração 
    * @param {object} log  Instância do provider do módulo de logging
    * @param {object} tipoLog_ Instância da constant do módulo de logging
    * @param {object} criticidadeLog  Instância da constant do módulo de logging
    * @param {object} $injector - Servico utilizado para retornar a instância do service configurado no appSettings
    * @param {object} excecao - Objeto retornado do tratamento de excecao
    * 
    * @description
    * Função responsável por substituir o padrão de exception handler a fim de logar o erros não detectados.
    */
    function exceptionHandler(appSettings, $injector, $log) {
        return function tratarExcecao(excecao) {
            var sfLogger = $injector.get("sfLogger");
            sfLogger.escreverLogExecucao("Início de execução.", "exceptionHandler.tratarExcecao", "", "", "Info",
                { classe: "exceptionHandler", metodo: "tratarExcecao" });

            var mensagemExcecao = JSON.stringify(excecao.message);
            
            sfLogger.escreverLogErro(mensagemExcecao, excecao.stack, "Alta");

            if (angular.isDefined(appSettings.configuracao) && angular.isDefined(appSettings.configuracao.tratamentoExcecao) &&
                angular.isObject(appSettings.configuracao.tratamentoExcecao) &&
                angular.isDefined(appSettings.configuracao.tratamentoExcecao.servico) &&
                angular.isString(appSettings.configuracao.tratamentoExcecao.servico) &&
                appSettings.configuracao.tratamentoExcecao.servico !== "" &&
                angular.isDefined(appSettings.configuracao.tratamentoExcecao.funcao) &&
                angular.isString(appSettings.configuracao.tratamentoExcecao.funcao) &&
                appSettings.configuracao.tratamentoExcecao.funcao !== ""

            ) {
                try {
                    if ($injector.has(appSettings.configuracao.tratamentoExcecao.servico)) {
                        var servicoRecuperado = $injector.get(appSettings.configuracao.tratamentoExcecao.servico);

                        servicoRecuperado[appSettings.configuracao.tratamentoExcecao.funcao](excecao);
                    }
                    else {
                        $log.warn("Serviço de tratamento de exceção não configurado.");
                        $log.error(excecao);
                    }
                }
                catch (error) {
                    $log.warn("Erro durante o direcionamento da exceção para o handler da aplicação.");
                    $log.error(error);
                }
            } else {
                $log.warn("Parâmetros de tratamento de exceção não configurados.");
                $log.error(excecao);
            }
            sfLogger.escreverLogExecucao("Término de execução.", "exceptionHandler.tratarExcecao", "", "", "Info",
                { classe: "exceptionHandler", metodo: "tratarExcecao" });
        };
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.filtros
     * 
     * @requires arq-spa-base.recursos
     * 
     * @description
     * Módulo Módulo de filtros da arquitetura base que provê os recursos necessários para avaliação de filtros para a aplicação.
     */
    angular.module("arq-spa-base.filtros", [
        "arq-spa-base.recursos"
    ]);
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.filtros.factories:sfFiltro
     * @module arq-spa-base.filtros
     *
     * @description
     * Dactory responsável por prover os recursos de inicialização e retorno dos filtros.
     */
    angular.module("arq-spa-base.filtros").factory("sfFiltro", sfFiltro);

    sfFiltro.$inject = ["$http", "appSettings", "sfLogger"];

    /**
     * @ngdoc overview
     * @name sfFiltro
     *
     * @methodOf arq-spa-base.filtros.factories:sfFiltro
     *
     * @description
     * Função responsável por definiri a factory.
     */
    function sfFiltro($http, appSettings, sfLogger) {
        var _filtroIniciado = false;

        var _filtros = [];

        return {
            iniciar: iniciar,
            obterRegraFiltro: obterRegraFiltro
        };

        /**
         * @ngdoc overview
         * @name iniciar
         *
         * @methodOf arq-spa-base.filtros.factories:sfFiltro
         *
         * @description
         * Função responsável por obter as configurações dos filtros à partir das configurações da aplicação.
         */
        function iniciar() {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.iniciar", "", "", "Info",
                { classe: "sfFiltro", metodo: "iniciar" });
            if (!_filtroIniciado) {
                if (validarDependenciasInicializacao()) {
                    $http.get(appSettings.configuracao.caminhoDefinicoesFiltros).then(sucessoRecuperacaoDefinicoesFiltros).catch(erroRecuperacaoDefinicoesFiltros);
                }
                else {
                    throw new Error("As configurações necessárias para inicialização do filtro não foram definidas.");
                }
            } else {
                throw new Error("O filtro já foi iniciado e, por tanto, não pode ser iniciado novamente.");
            }

            /**
             * @ngdoc method
             * @name sucessoRecuperacaoDefinicoesFiltros
             * 
             * @methodOf arq-spa-base.filtros.factories:sfFiltro
             * 
             * @params {array} configuracaoFiltros_ Array que contém as configurações do filtros.
             * 
             * @description
             * Método responsável por realizar o callback de sucesso inicializando os filtros.
             */
            function sucessoRecuperacaoDefinicoesFiltros(configuracaoFiltros_) {
                _filtros = configuracaoFiltros_.data;

                _filtroIniciado = true;
            }

            /**
             * @ngdoc method
             * @name erroRecuperacaoDefinicoesFiltros
             * 
             * @methodOf arq-spa-base.filtros.factories:sfFiltro
             * 
             * @params {object} dadosErro_ Objeto que contém o erro retornado na recuperação da configuração.
             * 
             * @description
             * Método responsável por realizar o callback de erro emitindo o erro ocorrido.
             */
            function erroRecuperacaoDefinicoesFiltros(dadosErro_) {
                throw new Error("Não foi possível obter as informações para inicialização dos filtros à partir do arquivo '" + appSettings.configuracao.caminhoDefinicoesFiltros + "'. Erro: " + dadosErro_);
            }
            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.iniciar", "", "", "Info",
                { classe: "sfFiltro", metodo: "erroRecuperacaoDefinicoesFiltros" });
        }

        /**
         * @ngdoc method
         * @name obterDefinicaoFiltro
         * 
         * @methodOf arq-spa-base.nfiltros.factories:sfFiltro
         * 
         * @param {string} IdFiltro_ Identificador do filtro cujas regras serão obtidas.
         * 
         * @description
         * Método responsável por recuperar as definições de um fluxo específico.
         * 
         * @returns {string} Regra associada ao identificador definido ou undefined caso o identificador não seja encontrado.
         */
        function obterRegraFiltro(idFiltro_) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.obterRegraFiltro", "", "", "Info",
                { classe: "sfFiltro", metodo: "obterRegraFiltro" });
            var regra;

            if (_filtroIniciado) {
                _filtros.some(function (filtro) {
                    return regra = ((filtro.id === idFiltro_) ? filtro.regra : undefined);
                });
            }
            else {
                throw new Error("O filtro ainda não foi iniciado.");
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.obterRegraFiltro", "", "", "Info",
                { classe: "sfFiltro", metodo: "obterRegraFiltro" });
            return regra;
        }

        /**
         * @ngdoc method
         * @name validarDependenciasInicializacao
         * 
         * @methodOf arq-spa-base.nfiltros.factories:sfFiltro
         * 
         * @description
         * Método responsável por efetuar a validação das configurações necessárias para inicialização do filtro.
         * 
         * @returns {boolean} True caso as configurações necessárias tenham sido configuradas ou false caso contrário.
         */
        function validarDependenciasInicializacao() {
            return (angular.isDefined(appSettings.configuracao) &&
                angular.isDefined(appSettings.configuracao.caminhoDefinicoesFiltros) &&
                angular.isString(appSettings.configuracao.caminhoDefinicoesFiltros) &&
                appSettings.configuracao.caminhoDefinicoesFiltros !== "");
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.filtros.filters:sfFiltro
     * @module arq-spa-base.filtros
     *
     * @description
     * Filtro que proporciona à aplicação a avaliação de expressões booleanas pré-definidas associadas à chave definida.
     */
    angular.module("arq-spa-base.filtros").filter("sfFiltro", sfFiltro);

    var regexExpressoesPrioritarias = new RegExp(/([a-z0-9]*)\(([^\(\)]+)\)(\^|!?)/);
    var regexIguais = new RegExp(/(\w*) == (\w*)/);
    var regexDiferentes = new RegExp(/(\w*) != (\w*)/);
    var regexConcatenar = new RegExp(/([\s\w]+);([\s\w]+)/);
    var regexCompararOu = new RegExp(/([\s\w]+):([\s\w]+)/);
    var regexContem = new RegExp(/[^;:]?([\w\s]*) in ([\w\s,]*)/);
    var regexNaoContem = new RegExp(/[^;:]?([\w\s]*) not in ([\w\s,]*)/);
    var regexParecidos = new RegExp(/([^;:]?[\w\s]*)%? like %?([\w\s]*)/);
    var regexNaoParecidos = new RegExp(/([^;:]?[\w\s]*)%? not like %?([\w\s]*)/);
    var regexContexto = new RegExp(/\$sfContexto.([a-z0-9]+).([a-zA-Z0-9]+)/);

    sfFiltro.$inject = ["sfUtilitarios", "sfFiltro", "sfContexto", "sfLogger"];

    /**
     * @ngdoc overview
     * @name sfFiltro
     *
     * @methodOf arq-spa-base.filtros.filters:sfFiltro
     *
     * @requires sfUtilitarios
     *
     * @description
     * Definição da função de filtros da aplicação.
     */
    function sfFiltro(sfUtilitarios, sfFiltroFactory, sfContexto, sfLogger) {
        return executarFiltro;

        /**
         * @ngdoc method
         * @name executarFiltro
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {string} chave_ Chave que será utilizada para definir qual filtro será avaliado.
         *
         * @description
         * Método responsável por executar um filtro determinado.
         */
        function executarFiltro(chave_) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.executarFiltro", "", "", "Info",
                { classe: "sfFiltro", metodo: "executarFiltro" });
            var regra = sfFiltroFactory.obterRegraFiltro(chave_);

            if (angular.isDefined(regra)) {
                sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.executarFiltro", "", "", "Info",
                    { classe: "sfFiltro", metodo: "executarFiltro" });
                return avaliarExpressao(regra);
            }
            else {
                throw new Error("Não existe uma regra de filtro definida para a chave \"" + chave_ + "\".");
            }
        }

        /**
         * @ngdoc method
         * @name avaliarExpressao
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {string} expressao_ Expressao que será avaliada.
         *
         * @description
         * Método responsável por avaliar a expressão informada retornando seu resultado.
         * 
         * @returns Resultado da expressão avaliada.
         */
        function avaliarExpressao(expressao_) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.avaliarExpressao", "", "", "Info",
                { classe: "sfFiltro", metodo: "avaliarExpressao" });
            var expressaoFinal = expressao_;

            var resultadoRegex = regexExpressoesPrioritarias.exec(expressao_);

            while (resultadoRegex != null) {
                expressaoFinal = expressaoFinal.replace(resultadoRegex[0], resolverEpressao(resultadoRegex[2]));

                resultadoRegex = regexExpressoesPrioritarias.exec(expressaoFinal);
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.avaliarExpressao", "", "", "Info",
                { classe: "sfFiltro", metodo: "avaliarExpressao" });
            return resolverEpressao(expressaoFinal);
        }

        /**
         * @ngdoc method
         * @name resolverEpressao
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {string} expressao_ Expressao que será avaliada.
         *
         * @description
         * Método responsável por resolver uma expressão.
         * 
         * @returns Resultado da expressão resolvida.
         */
        function resolverEpressao(expressao_) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.resolverEpressao", "", "", "Info",
                { classe: "sfFiltro", metodo: "resolverEpressao" });
            var expressaoResolvida = expressao_;

            if (sfUtilitarios.contem(expressaoResolvida, "$sfContexto.")) {
                expressaoResolvida = executar(expressaoResolvida, regexContexto, resolverContexto);
            }

            if (sfUtilitarios.contem(expressaoResolvida, "==")) {
                expressaoResolvida = executar(expressaoResolvida, regexIguais, compararIguais);
            }

            if (sfUtilitarios.contem(expressaoResolvida, "!=")) {
                expressaoResolvida = executar(expressaoResolvida, regexDiferentes, compararDiferentes);
            }

            if (sfUtilitarios.contem(expressaoResolvida, "not in")) {
                expressaoResolvida = executar(expressaoResolvida, regexNaoContem, compararNaoContem);
            }

            if (sfUtilitarios.contem(expressaoResolvida, "in")) {
                expressaoResolvida = executar(expressaoResolvida, regexContem, compararContem);
            }

            if (sfUtilitarios.contem(expressaoResolvida, "not like")) {
                expressaoResolvida = executar(expressaoResolvida, regexNaoParecidos, compararNaoParecido);
            }

            if (sfUtilitarios.contem(expressaoResolvida, "like")) {
                expressaoResolvida = executar(expressaoResolvida, regexParecidos, compararParecido);
            }

            if (sfUtilitarios.contem(expressaoResolvida, ";")) {
                expressaoResolvida = executar(expressaoResolvida, regexConcatenar, concatenar);
            }

            if (sfUtilitarios.contem(expressaoResolvida, ":")) {
                expressaoResolvida = executar(expressaoResolvida, regexCompararOu, compararOu);
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.resolverEpressao", "", "", "Info",
                { classe: "sfFiltro", metodo: "resolverEpressao" });
            return expressaoResolvida;
        }

        /**
         * @ngdoc method
         * @name executar
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {string} expressao_ Expressao que será executada.
         * @param {RegExp} regex_ Expressao regular que será utilizada para a separação das partes da expressão.
         * @param {function} funcao_ Função que será responsável pela execução da expressão.
         *
         * @description
         * Método responsável por executar uma expressão.
         * 
         * @returns Expressão com o resultado da exeução.
         */
        function executar(expressao_, regex_, funcao_) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.executar", "", "", "Info",
                { classe: "sfFiltro", metodo: "executar" });
            var expressaoFinal = expressao_;

            var resultadoRegex = regex_.exec(expressao_);

            while (resultadoRegex != null) {
                expressaoFinal = expressaoFinal.replace(resultadoRegex[0], funcao_(resultadoRegex));

                resultadoRegex = regex_.exec(expressaoFinal);
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.executar", "", "", "Info",
                { classe: "sfFiltro", metodo: "executar" });
            return expressaoFinal;
        }

        /**
         * @ngdoc method
         * @name resolverContexto
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {array} itensFormula_ Itens que serão avaliados na resolução do sfContexto.
         *
         * @description
         * Método responsável por executar resolução das variáveis de sfContexto.
         * 
         * @returns Resultado da execução da expressão.
         */
        function resolverContexto(itensFormula_) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.resolverContexto", "", "", "Info",
                { classe: "sfFiltro", metodo: "resolverContexto" });
            var resultado;

            if (itensFormula_[1] === "sessao") {
                resultado = sfContexto.obterValorContextoSessao(itensFormula_[2]);
            }
            else if (itensFormula_[1] === "trabalho") {
                resultado = sfContexto.obterValorContextoTrabalho(itensFormula_[2]);
            }
            else {
                throw new Error("Tipo de sfContexto inválido: \"" + itensFormula_[1] + "\"");
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.resolverContexto", "", "", "Info",
                { classe: "sfFiltro", metodo: "resolverContexto" });
            return resultado;
        }

        /**
         * @ngdoc method
         * @name compararIguais
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {array} itensFormula_ Itens que serão avaliados na comparação dos itens obtidos do resultado da execução da expressão regular de igualdade de itens.
         *
         * @description
         * Método responsável por executar a comparação de igualdade do resultado da execução da expressão regular correspondente.
         * 
         * @returns Resultado da execução da expressão.
         */
        function compararIguais(itensFormula_) {
            return itensFormula_[1] === itensFormula_[2];
        }

        /**
         * @ngdoc method
         * @name compararIguais
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {array} itensFormula_ Itens que serão avaliados na comparação dos itens obtidos do resultado da execução da expressão regular de desigualdade de itens.
         *
         * @description
         * Método responsável por executar a comparação de desigualdade do resultado da execução da expressão regular correspondente.
         * 
         * @returns Resultado da execução da expressão.
         */
        function compararDiferentes(itensFormula_) {
            return itensFormula_[1] !== itensFormula_[2];
        }

        /**
         * @ngdoc method
         * @name concatenar
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {array} itensFormula_ Itens que serão avaliados na comparação dos itens obtidos do resultado da execução da expressão regular de concatenação de itens.
         *
         * @description
         * Método responsável por executar a concatenação do resultado da execução da expressão regular correspondente.
         * 
         * @returns Resultado da execução da expressão.
         */
        function concatenar(itensFormula_) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.concatenar", "", "", "Info",
                { classe: "sfFiltro", metodo: "concatenar" });
            var valorPrimeiroItem = itensFormula_[1].trim() === "true";
            var valorSegundoItem = itensFormula_[2].trim() === "true";

            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.concatenar", "", "", "Info",
                { classe: "sfFiltro", metodo: "concatenar" });
            return valorPrimeiroItem && valorSegundoItem;
        }

        /**
         * @ngdoc method
         * @name compararOu
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {array} itensFormula_ Itens que serão avaliados na comparação dos itens obtidos do resultado da execução da expressão regular comparacao ou.
         *
         * @description
         * Método responsável por executar a comparação do resultado da execução da expressão regular correspondente.
         * 
         * @returns Resultado da execução da expressão.
         */
        function compararOu(itensFormula_) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.compararOu", "", "", "Info",
                { classe: "sfFiltro", metodo: "compararOu" });
            var valorPrimeiroItem = itensFormula_[1].trim() === "true";
            var valorSegundoItem = itensFormula_[2].trim() === "true";

            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.compararOu", "", "", "Info",
                { classe: "sfFiltro", metodo: "compararOu" });
            return valorPrimeiroItem || valorSegundoItem;
        }

        /**
         * @ngdoc method
         * @name compararContem
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {array} itensFormula_ Itens que serão avaliados na comparação dos itens obtidos do resultado da execução da expressão regular contem.
         *
         * @description
         * Método responsável por executar a comparação do resultado da execução da expressão regular correspondente.
         * 
         * @returns Resultado da execução da expressão.
         */
        function compararContem(itensFormula_) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.compararContem", "", "", "Info",
                { classe: "sfFiltro", metodo: "compararContem" });
            var resultado = false;

            var opcoes = itensFormula_[2].split(",");

            opcoes.some(function (opcao) {
                return resultado = opcao === itensFormula_[1];
            });

            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.compararContem", "", "", "Info",
                { classe: "sfFiltro", metodo: "compararContem" });
            return resultado;
        }

        /**
         * @ngdoc method
         * @name compararNaoContem
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {array} itensFormula_ Itens que serão avaliados na comparação dos itens obtidos do resultado da execução da expressão regular não contem.
         *
         * @description
         * Método responsável por executar a comparação do resultado da execução da expressão regular correspondente.
         * 
         * @returns Resultado da execução da expressão.
         */
        function compararNaoContem(itensFormula_) {
            return !compararContem(itensFormula_);
        }

        /**
         * @ngdoc method
         * @name compararParecido
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {array} itensFormula_ Itens que serão avaliados na comparação dos itens obtidos do resultado da execução da expressão regular parecidos.
         *
         * @description
         * Método responsável por executar a comparação do resultado da execução da expressão regular correspondente.
         * 
         * @returns Resultado da execução da expressão.
         */
        function compararParecido(itensFormula_) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.compararParecido", "", "", "Info",
                { classe: "sfFiltro", metodo: "compararParecido" });
            var resultado;

            if (sfUtilitarios.contem(itensFormula_[0], "% like %")) {
                resultado = sfUtilitarios.contem(itensFormula_[2].trim(), itensFormula_[1].trim());
            }
            else if (sfUtilitarios.contem(itensFormula_[0], "% like")) {
                resultado = sfUtilitarios.comecaCom(itensFormula_[2].trim(), itensFormula_[1].trim());
            }
            else if (sfUtilitarios.contem(itensFormula_[0], "like %")) {
                resultado = sfUtilitarios.terminaCom(itensFormula_[2].trim(), itensFormula_[1].trim());
            }
            else {
                resultado = false;
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.compararParecido", "", "", "Info",
                { classe: "sfFiltro", metodo: "compararParecido" });
            return resultado;
        }

        /**
         * @ngdoc method
         * @name compararNaoParecido
         *
         * @methodOf arq-spa-base.filtros.filters:sfFiltro
         *
         * @param {array} itensFormula_ Itens que serão avaliados na comparação dos itens obtidos do resultado da execução da expressão regular não parecidos.
         *
         * @description
         * Método responsável por executar a comparação do resultado da execução da expressão regular correspondente.
         * 
         * @returns Resultado da execução da expressão.
         */
        function compararNaoParecido(itensFormula_) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltro.compararNaoParecido", "", "", "Info",
                { classe: "sfFiltro", metodo: "compararNaoParecido" });
            var resultado;

            if (sfUtilitarios.contem(itensFormula_[0], "% not like %")) {
                resultado = !sfUtilitarios.contem(itensFormula_[2].trim(), itensFormula_[1].trim());
            }
            else if (sfUtilitarios.contem(itensFormula_[0], "% not like")) {
                resultado = !sfUtilitarios.comecaCom(itensFormula_[2].trim(), itensFormula_[1].trim());
            }
            else if (sfUtilitarios.contem(itensFormula_[0], "not like %")) {
                resultado = !sfUtilitarios.terminaCom(itensFormula_[2].trim(), itensFormula_[1].trim());
            }
            else {
                resultado = false;
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltro.compararNaoParecido", "", "", "Info",
                { classe: "sfFiltro", metodo: "compararNaoParecido" });
            return resultado;
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.filtros.filters:sfFiltroContexto
     * @module arq-spa-base.filtros
     *
     * @description
     * 
     */
    angular.module("arq-spa-base.filtros").filter("sfFiltroContexto", sfFiltroContexto);

    sfFiltroContexto.$inject = ["sfContexto", "sfLogger"];


    /**
     * @ngdoc overview
     * @name sfFiltroContexto
     *
     * @methodOf arq-spa-base.filtros.filters:sfFiltroContexto
     *
     *
     * @description
     * 
     */
    function sfFiltroContexto(sfContexto, sfLogger) {
        return obterValor;

        /**
         * @ngdoc overview
         * @name sfFiltroContexto
         *
         * @methodOf arq-spa-base.filtros.filters:obterValor
         *
         * @param {string} chaveContexto Chave a ser buscada no contexto
         * @param {string} tipoContexto Tipo do contexto (sessao/trabalho)
         * 
         * @description
         *  Obtém o valor do contexto baseado na chave e no tipo de contexto
         * 
         */
        function obterValor(chaveContexto, tipoContexto) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfFiltroContexto.obterValor", "", "", "Info",
                { classe: "sfFiltroContexto", metodo: "obterValor" });

            var valor = "";

            switch (tipoContexto) {
                case "trabalho": {
                    valor = sfContexto.obterValorContextoTrabalho(chaveContexto);
                    break;
                }
                case "sessao": {
                    valor = sfContexto.obterValorContextoSessao(chaveContexto);
                    break;
                }
                default: {
                    throw new Error("Contexto para realizar o filtro deve ser 'sessao' ou 'trabalho'");
                }
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfFiltroContexto.obterValor", "", "", "Info",
                { classe: "sfFiltroContexto", metodo: "obterValor" });
            return valor;
        }
    }
})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.gerenciadorArquivos
     * @description
     * Módulo de gerenciador de arquivos da arquitetura base que provê as funcionalidades.
     */
    angular.module("arq-spa-base.gerenciadorArquivos", ["ngFileUpload"]);
})();
(function () {
    "use strict";

    angular.module("arq-spa-base.gerenciadorArquivos").factory("sfDownload", sfDownload);

    sfDownload.$inject = ["sfLogger", "sfConectorAPI", "$window", "sfUtilitarios"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.gerenciadorArquivos.factories:sfDownload
     * @module arq-spa-base.gerenciadorArquivos
     *
     * @description
     * Factory resposável pelo download de arquivos
     */
    function sfDownload(sfLogger, sfConectorAPI, $window, sfUtilitarios) {

        return {
            downloadArquivo: downloadArquivo
        };


        /**
        * @ngdoc method
        * @name downloadArquivo
        *
        * @methodOf arq-spa-base.gerenciadorArquivos.factories:sfDownload
        *  
        * @description
        * Método responsável por enviar a URL para o browser realizar o download.
        * Esse componente não cifra as informações de envio
        * 
        * @param {string} url URL recebida para realizar o download.
        * @param {object} data Parâmetros referente ao download.
        */
        function downloadArquivo(url, data, deveOrquestrar, parametros) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfDownload.downloadArquivo", "", "", "Info",
                { classe: "sfDownload", metodo: "downloadArquivo" });
            deveOrquestrar = deveOrquestrar || false;

            if (deveOrquestrar) {
                var config = {
                    url: url,
                    data: data,
                    method: "POST",
                    arquivo: true
                };

                sfConectorAPI.executar(config)
                    .then(sucessoObtencaoTokenDownload)
                    .catch(erroObtencaoTokenDownload);
            } else {
                sfLogger.escreverLogExecucao("Término de execução.", "sfDownload.downloadArquivo", "", "", "Info",
                    { classe: "sfDownload", metodo: "downloadArquivo" });
                $window.open(url);
            }

            /**
             * @ngdoc method
             * @name sucessoObtencaoTokenDownload
             *
             * @methodOf arq-spa-base.gerenciadorArquivos.factories:sfDownload
             *  
             * @description
             * Método responsável orquestrar a chamada para o download do arquivo.
             * 
             * @param {object} response Objeto de resposta.
             */
            function sucessoObtencaoTokenDownload(response) {
                if (angular.isDefined(response) &&
                    angular.isDefined(response.data) &&
                    angular.isDefined(response.data.downloadToken)) {

                    if (!sfUtilitarios.contem(url, "?")) {
                        url = url + "?";
                    } else {
                        url = url + "&";
                    }

                    parametros = parametros || "";

                    if (parametros !== "" && parametros[0] !== "&") {
                        parametros = parametros.replace(/^/, "&");
                    }
                    
                    
                    url = url + "downloadToken=" + response.data.downloadToken + parametros;
                    $window.open(url);
                    sfLogger.escreverLogExecucao("Término de execução.", "sfDownload.downloadArquivo", "", "", "Info",
                        { classe: "sfDownload", metodo: "downloadArquivo.sucessoObtencaoTokenDownload" });
                } else {
                    sfLogger.escreverLogExecucao("Término de execução.", "sfDownload.downloadArquivo", "", "", "Info",
                        { classe: "sfDownload", metodo: "downloadArquivo.sucessoObtencaoTokenDownload" });
                    throw new Error("Token de download não está definido.");
                }

            }

            /**
             * @ngdoc method
             * @name erroObtencaoTokenDownload
             *
             * @methodOf arq-spa-base.gerenciadorArquivos.factories:sfDownload
             *  
             * @description
             * Método responsável por tratar o erro da obtenção do token de download.
             * 
             * @param {object} response Objeto de resposta de erro.
             */
            function erroObtencaoTokenDownload() {
                sfLogger.escreverLogExecucao("Término de execução.", "sfDownload.downloadArquivo", "", "", "Info",
                    { classe: "sfDownload", metodo: "downloadArquivo.erroObtencaoTokenDownload" });
                throw new Error("Erro ao obter o token de download.");
            }
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.gerenciadorArquivos.factories:sfPlanilha
     * @module arq-spa-base.gerenciadorArquivos
     *
     * @description
     * 
     */
    angular.module("arq-spa-base.gerenciadorArquivos").factory("sfPlanilha", sfPlanilha);

    sfPlanilha.$inject = ["$window", "sfUtilitarios", "$timeout", "sfLogger", "FileSaver", "$log"];

    /**
     * @ngdoc overview
     * @name sfPlanilha
     *
     * @methodOf arq-spa-base.gerenciadorArquivos.factories:sfPlanilha
     *
     * @description
     *  Factory que gera o arquivo de planilha e executa o download.
     */
    function sfPlanilha($window, sfUtilitarios, $timeout, sfLogger, FileSaver, $log) {

        return {
            gerarPlanilha: gerarPlanilha
        };

        /**
         * @ngdoc overview
         * @name gerarPlanilha
         *
         * @methodOf arq-spa-base.gerenciadorArquivos.factories:sfPlanilha
         *
         * @description
         * Função que gera o arquivo de planilha e executa o download.
         * 
         * @param {string} tabela Template do arquivo
         * @param {string} nomeArquivo Nome do arquivo de download (sem extensão)
         * @param {function} callbackBrowserNaoSuportado Funcao a ser disparada o browser for Safari com versão menor que 10.1.0
         */
        function gerarPlanilha(tabela, nomeArquivo, callbackBrowserNaoSuportado) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfPlanilha.gerarPlanilha", "", "", "Info",
                { classe: "sfPlanilha", metodo: "gerarPlanilha" });

            var indicadorBrowserSuportado = verificarSuporteBrowser();
            if (indicadorBrowserSuportado) {
                var blob = new Blob([tabela], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8" });
                FileSaver.saveAs(blob, nomeArquivo + ".xls");
            }

            sfLogger.escreverLogExecucao("Fim de execução.", "sfPlanilha.gerarPlanilha", "", "", "Info",
                { classe: "sfPlanilha", metodo: "gerarPlanilha" });

            /**
             * @ngdoc overview
             * @name ValidarSuporteBrowser
             *
             * @methodOf arq-spa-base.gerenciadorArquivos.factories:sfPlanilha
             *
             * @description
             * Função que verifica se o browser é Safari
             *
             */
            function verificarSuporteBrowser() {
                var infoNavegador = sfUtilitarios.verificarBrowser($window.navigator);

                if (infoNavegador.navegador.match(/(SAFA)/)) {

                    var versoes = infoNavegador.versaoNavegador.split(" ");
                    if (angular.isArray(versoes) && versoes.length > 0 && verificarVersaoPermitidaSafari()) {
                        if (angular.isFunction(callbackBrowserNaoSuportado)) {
                            callbackBrowserNaoSuportado();
                        } else {
                            $log.warn("O browser não suporta a geração de planilha por meio deste componente.\n Parametrize um callback para tratar o erro devidamente.");
                        }
                        return false;
                    }
                }

                return true;

                /**
                 * @ngdoc overview
                 * @name verificarVersaoPermitidaSafari
                 *
                 * @methodOf arq-spa-base.gerenciadorArquivos.factories:sfPlanilha
                 *
                 * @description
                 * Função que verifica se a versão do Safari suporta esse componente
                 */
                function verificarVersaoPermitidaSafari() {
                    var vesoesSeparadas = versoes[0].split(".");
                    return !(Number(vesoesSeparadas[0]) >= 10 && Number(vesoesSeparadas[1] >= 1));
                }
            }
        }
    }
})();
(function () {
    "use strict";

    angular.module("arq-spa-base.gerenciadorArquivos").factory("sfUpload", sfUpload);

    sfUpload.$inject = ["appSettings", "sfContexto", "sfUtilitarios", "sfConectorAPI", "Upload",
        "$timeout", "sfLogger", "sfHeadersArquitetura", "sfLoader"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.gerenciadorArquivos.factories:sfUpload
     * @module arq-spa-base.gerenciadorArquivos
     * 
     * @requires appSettings
     * @requires sfUtilitarios
     * @requires sfContexto
     * @requires sfConectorAPI
     * @requires Upload
     * @requires $timeout
     * @requires sfLogger
     * @requires sfHeadersArquitetura
     * 
     * @description
     * Factory resposável pelo upload de arquivos
     */
    function sfUpload(appSettings, sfContexto, sfUtilitarios, sfConectorAPI, Upload,
        $timeout, sfLogger, sfHeadersArquitetura, sfLoader) {
        var r;

        return {
            uploadArquivo: uploadArquivo,
            uploadArquivoResumivel: uploadArquivoResumivel
        };

        /**
         * @ngdoc overview
         * @name arq-spa-base.gerenciadorArquivos.factories:sfUpload
         * @module arq-spa-base.gerenciadorArquivos
         * 
         * @description
         * Função resposável pelo upload de arquivos
         *
         * @param {object} files Lista de arquivos
         * @param {object} aplicacaoSucesso Callback de sucesso
         * @param {object} aplicacaoErro Callback de erro
         * @param {object} aplicacaoProgresso Callback de progresso
         * @param {object} endpointUpload Endpoint que o upload será feito
         * @param {object} parametros Parâmetros opcionais para o upload
         * @param {boolean} exibirLoader Indicador de exibição do loader
         * @param {object} parametrosFormData Valor que será adicionado no parametro enviado para o backend (Caso seja necessário enviar parâmetros fora do objeto Data)
         */
        function uploadArquivo(files, aplicacaoSucesso, aplicacaoErro, aplicacaoProgresso, endpointUpload, parametros, exibirLoader, parametrosFormData) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfUpload.uploadArquivo", "", "", "Info",
                { classe: "sfUpload", metodo: "uploadArquivo" });

            var chaveLoader = "chaveUpload";

            if (angular.isUndefined(exibirLoader) || exibirLoader) {
                sfLoader.mostrarLoader(chaveLoader);
            }

            angular.forEach(files, arquivos);

            /**
             * @ngdoc overview
             * @name arq-spa-base.gerenciadorArquivos.factories:sfUpload
             * @module arq-spa-base.gerenciadorArquivos
             * 
             * @description
             * Função resposável por armazenar os arquivos
             */
            function arquivos(file) {
                sfLogger.escreverLogExecucao("Início de execução.", "sfUpload.arquivos", "", "", "Info",
                    { classe: "sfUpload", metodo: "arquivos" });

                if (angular.isDefined(file)) {

                    var parametroComposto = angular.merge({ file: file, dados: parametros }, parametrosFormData);

                    file.upload = Upload.upload({
                        url: endpointUpload,
                        data: parametroComposto,
                        headers: sfHeadersArquitetura.obterHeaders(),
                        arquivo: true
                    });

                    file.upload.then(sucesso, erro, progresso);
                }
                else {
                    file = {};
                    file.mensagemErro = "Arquivo não está definido";
                    aplicacaoErro(file);
                }

                /**
                 * @ngdoc overview
                 * @name arq-spa-base.gerenciadorArquivos.factories:sfUpload
                 * @module arq-spa-base.gerenciadorArquivos
                 * 
                 * @description
                 * Função resposável pelo callbadk de sucesso
                 */
                function sucesso(response) {
                    sfLogger.escreverLogExecucao("Início de execução.", "sfUpload.sucesso", "", "", "Info",
                        { classe: "sfUpload", metodo: "arquivos.sucesso" });
                    $timeout(executorSucesso);

                    /**
                     * @ngdoc overview
                     * @name arq-spa-base.gerenciadorArquivos.factories:sfUpload
                     * @module arq-spa-base.gerenciadorArquivos
                     * 
                     * @description
                     * Função resposável pelo tempo de sucesso
                     */
                    function executorSucesso() {
                        sfLogger.escreverLogExecucao("Início de execução.", "sfUpload.executorSucesso", "", "", "Info",
                            { classe: "sfUpload", metodo: "arquivos.sucesso.executorSucesso" });

                        sfLoader.esconderLoader(chaveLoader);

                        file.result = response.data;
                        aplicacaoSucesso(file);
                        sfLogger.escreverLogExecucao("Término de execução.", "sfUpload.executorSucesso", "", "", "Info",
                            { classe: "sfUpload", metodo: "arquivos.sucesso.executorSucesso" });
                    }
                    sfLogger.escreverLogExecucao("Término de execução.", "sfUpload.executorSucesso", "", "", "Info",
                        { classe: "sfUpload", metodo: "arquivos.sucesso" });
                }

                /**
                 * @ngdoc overview
                 * @name arq-spa-base.gerenciadorArquivos.factories:sfUpload
                 * @module arq-spa-base.gerenciadorArquivos
                 * 
                 * @description
                 * Função resposável por retornar erro
                 */
                function erro(response) {
                    sfLogger.escreverLogExecucao("Início de execução.", "sfUpload.erro", "", "", "Info",
                        { classe: "sfUpload", metodo: "arquivos.erro" });

                    sfLoader.esconderLoader(chaveLoader);

                    file.mensagemErro = response.data;
                    aplicacaoErro(file);
                    sfLogger.escreverLogExecucao("Término de execução.", "sfUpload.erro", "", "", "Info",
                        { classe: "sfUpload", metodo: "arquivos.erro" });
                }

                /**
                 * @ngdoc overview
                 * @name arq-spa-base.gerenciadorArquivos.factories:sfUpload
                 * @module arq-spa-base.gerenciadorArquivos
                 * 
                 * @description
                 * Função resposável pelo progresso do upload
                 */
                function progresso(evt) {
                    sfLogger.escreverLogExecucao("Início de execução.", "sfUpload.progresso", "", "", "Info",
                        { classe: "sfUpload", metodo: "arquivos.progresso" });
                    file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
                    aplicacaoProgresso(file);
                    sfLogger.escreverLogExecucao("Término de execução.", "sfUpload.progresso", "", "", "Info",
                        { classe: "sfUpload", metodo: "arquivos.progresso" });
                }
                sfLogger.escreverLogExecucao("Término de execução.", "sfUpload.arquivos", "", "", "Info",
                    { classe: "sfUpload", metodo: "arquivos" });
            }
            sfLogger.escreverLogExecucao("Término de execução.", "sfUpload.uploadArquivo", "", "", "Info",
                { classe: "sfUpload", metodo: "uploadArquivo" });
        }

        /**
         * @ngdoc overview
         * @name arq-spa-base.gerenciadorArquivos.factories:sfUpload
         * @module arq-spa-base.gerenciadorArquivos
         * 
         * @description
         * Função resposável pelo upload de arquivos
         *
         * @param {object} files Lista de arquivos
         * @param {object} endpointUpload Endpoint que o upload será feito
         * @param {object} callbacks Lista de callbacks para o resumable
         * @param {object} parametros Parâmetros opcionais para o upload
         * @param {boolean} exibirLoader indicador de exibição de loader
         */
        function uploadArquivoResumivel(files, endpointUpload, callbacks, parametro, exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfUpload.uploadArquivoResumivel", "", "", "Info",
                { classe: "sfUpload", metodo: "uploadArquivoResumivel" });

            var configUpload = appSettings.upload || {};
            callbacks = callbacks || {};

            var fileInfo = function () {
                return parametro;
            };

            if (angular.isFunction(parametro)) {
                fileInfo = parametro;
            }

            r = new Resumable({
                target: endpointUpload,
                simultaneousUpload: 1,
                testChunks: true,
                throttleProgressCallbacks: 1,
                headers: sfHeadersArquitetura.obterHeaders(),
                query: fileInfo,
                chunkNumberParameterName: "amcNumeroChunk",
                totalChunksParameterName: "amcTotalChunks",
                chunkSizeParameterName: "amcTamanhoChunk",
                totalSizeParameterName: "amcTamanhoTotal",
                identifierParameterName: "amcIdentificador",
                fileNameParameterName: "amcFilename",
                relativePathParameterName: "amcCaminhoRelativo",
                currentChunkSizeParameterName: "amcTamanhoChunkAtual",
                chunkHashParameterName: "amcChunkHash",
                typeParameterName: "amcTipo",
                maxChunkRetries: configUpload.numeroMaximoRetentativas || 5
            });

            if (!r.support) {
                throw new Error("Upload resumível não é suportado.");
            }

            var chaveLoader = "chaveUpload";

            if (angular.isUndefined(exibirLoader) || exibirLoader) {
                sfLoader.mostrarLoader(chaveLoader);
            }

            r.on("fileSuccess", callbacks.onSucessoArquivo);
            r.on("fileError", callbacks.onErroArquivo);
            r.on("fileProgress", callbacks.onProgressoArquivo);
            r.on("filesAdded", arquivosAdicionado);
            r.on("cancel", uploadCancelado);
            r.on("uploadStart", callbacks.onInicioUpload);
            r.on("complete", uploadCompleto);
            r.on("pause", callbacks.onPause);

            r.addFiles(files);

            sfLogger.escreverLogExecucao("Término de execução.", "sfUpload.uploadArquivoResumivel", "", "", "Info",
                { classe: "sfUpload", metodo: "uploadArquivoResumivel" });

            return {
                pausar: r.pause,
                retomar: r.upload,
                cancelar: r.cancel
            };

            /**
             * @ngdoc overview
             * @name arq-spa-base.gerenciadorArquivos.factories:sfUpload
             * @module arq-spa-base.gerenciadorArquivos
             * 
             * @description
             * Função resposável por controlar os arquivos adicionados e começar o upload
             */
            function arquivosAdicionado(arquivos, arquivosIgnorados) {
                sfLogger.escreverLogExecucao("Início de execução.", "sfUpload.uploadArquivoResumivel.arquivoAdicionado", "", "", "Info",
                    { classe: "sfUpload", metodo: "arquivoAdicionado" });

                if (arquivos.length < files.length - arquivosIgnorados.length) {
                    sfLogger.escreverLogExecucao("Término de execução.", "sfUpload.uploadArquivoResumivel.arquivoAdicionado", "", "", "Info",
                        { classe: "sfUpload", metodo: "arquivoAdicionado" });
                    return;
                }

                r.upload();

                sfLogger.escreverLogExecucao("Término de execução.", "sfUpload.uploadArquivoResumivel.arquivoAdicionado", "", "", "Info",
                    { classe: "sfUpload", metodo: "arquivoAdicionado" });
            }

            /**
             * @ngdoc overview
             * @name arq-spa-base.gerenciadorArquivos.factories:sfUpload
             * @module arq-spa-base.gerenciadorArquivos
             * 
             * @description
             * Função resposável por completar o upload
             */
            function uploadCompleto() {
                sfLoader.esconderLoader(chaveLoader);
                if (angular.isFunction(callbacks.onCompleto)) {
                    callbacks.onCompleto();
                }
            }

            /**
             * @ngdoc overview
             * @name arq-spa-base.gerenciadorArquivos.factories:sfUpload
             * @module arq-spa-base.gerenciadorArquivos
             * 
             * @description
             * Função resposável por cancelar o upload
             */
            function uploadCancelado() {
                sfLoader.esconderLoader(chaveLoader);
                if (angular.isFunction(callbacks.onCancelado)) {
                    callbacks.onCancelado();
                }
            }
        }
    }
})();
(function () {
    "use strict";

    angular.module("arq-spa-base.gerenciadorArquivos")
        .factory("sfZip", sfZip);

    sfZip.$inject = ["appSettings", "sfUtilitarios", "sfLogger", "$q", "FileSaver", "$window"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.gerenciadorArquivos.factories:sfZip
     * @module arq-spa-base.gerenciadorArquivos
     * 
     * @requires appSettings
     * @requires utilitarios
     * @requires sfLogger
     * @requires $q
     * @requires FileSaver
     * @requires $window
     * 
     * @description
     * Factory responsável pela comunicação com o backend para geração de arquivos .zip 
     */
    function sfZip(appSettings, sfUtilitarios, sfLogger, $q, FileSaver, $window) {
        return {
            gerar: gerar
        };

        /**
         * @ngdoc method
         * @name gerar
         * 
         * @methodOf arq-base-spa.gerenciadorArquivos.factories:sfZip
         * 
         * @description
         * Método responsável realizar chamada ao backend para geração de arquivo .zip
         */
        function gerar(tituloArquivoEntrada, conteudo, nomeArquivoSaida) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfZip.gerar", "", "", "Info", { classe: "sfZip", metodo: "gerar" });

            var deferred = $q.defer();
            var zip = new $window.JSZip();
            zip.file(tituloArquivoEntrada && tituloArquivoEntrada != "" ? tituloArquivoEntrada : "ARQUIVO" , conteudo);
            zip.generateAsync({ type: "blob" })
                .then(function (conteudo) {
                    FileSaver.saveAs(conteudo, nomeArquivoSaida + ".zip");
                    return deferred.resolve(conteudo);
                })
                .catch(function (erro) {
                    return deferred.reject(erro);
                });

            sfLogger.escreverLogExecucao("Término de execução.", "sfZip.gerar", "", "", "Info", { classe: "sfZip", metodo: "gerar" });
            return deferred.promise;
        }
    }

})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.logging
     * 
     * @requires ui.router
     * @requires oc.lazyLoad
     * 
     * @description
     * Módulo de logging da arquitetura base que provê as funcionalidades de registro de log.
     */
    angular.module("arq-spa-base.logging", []);
})();

(function () {
    "use strict";

    var sfFila = {
        enfileirarLogErro: enfileirarLogErro,
        enfileirarLogExecucao: enfileirarLogExecucao,
        retornarFilaErro: retornarFilaErro,
        limparFilaErro: limparFilaErro,
        retornarFilaExecucao: retornarFilaExecucao,
        limparFilaExecucao: limparFilaExecucao,
        filaLogsErro: [],
        filaLogsExecucao: [],
        gerarTimestampUTC: gerarTimestampUTC
    };

    /**
     * @ngdoc object
     * @name enfileirarLogErro
     * 
     * @methodOf arq-spa-base.logging.constants
     * 
     * @description
     * Método responsável por enfileirar um log de erro para escrita posterior.
     * 
     * @param {string} mensagem_        Mensagem a ser logada pela aplicação
     * @param {string} criticidade_     Criticidade do erro (Alta, Média, Baixa)
     */
    function enfileirarLogErro(mensagem_, criticidade_) {
        var objTimestamp = sfFila.gerarTimestampUTC();

        var objetoLog = {
            timestamp: objTimestamp.timestamp,
            gmt: objTimestamp.gmt,
            mensagem: mensagem_,
            categoria: "Error",
            criticidade: criticidade_
        };

        sfFila.filaLogsErro.push(objetoLog);

        return this;
    }

    /**
     * @ngdoc object
     * @name enfileirarLogExecucao
     * 
     * @methodOf arq-spa-base.logging.constants
     * 
     * @description
     * Método responsável por enfileirar um log de execução para escrita posterior.
     * 
     * @param {string} mensagem_        Mensagem a ser logada pela aplicação
     * @param {string} funcao_          Função que está sendo executada
     * @param {string} categoria_       Categoria do log (Info ou Warn)
     */
    function enfileirarLogExecucao(mensagem_, funcao_, categoria_) {
        var objTimestamp = sfFila.gerarTimestampUTC();

        var objetoLog = {
            timestamp: objTimestamp.timestamp,
            gmt: objTimestamp.gmt,
            mensagem: mensagem_,
            funcao: funcao_,
            categoria: categoria_
        };

        sfFila.filaLogsExecucao.push(objetoLog);

        return this;
    }

    /**
     * @ngdoc object
     * @name retornarFilaErro
     * 
     * @methodOf arq-spa-base.logging.constants
     * 
     * @description
     * Método responsável por retornar a fila de logs de erro.
     * 
     * @returns
     * Retorna os logs de erro enfileirados 
     */
    function retornarFilaErro() {
        return sfFila.filaLogsErro;
    }

    /**
     * @ngdoc object
     * @name limparFilaErro
     * 
     * @methodOf arq-spa-base.logging.constants
     * 
     * @description
     * Método responsável por limpar a fila de logs de erro.
     */
    function limparFilaErro() {
        sfFila.filaLogsErro = [];
    }

    /**
     * @ngdoc object
     * @name retornarFilaExecucao
     * 
     * @methodOf arq-spa-base.logging.constants
     * 
     * @description
     * Método responsável por retornar e limpar a fila de logs de execução.
     * 
     * @returns
     * Retorna os logs de execução enfileirados
     */
    function retornarFilaExecucao() {
        return sfFila.filaLogsExecucao;
    }

    /**
     * @ngdoc object
     * @name limparFilaExecucao
     * 
     * @methodOf arq-spa-base.logging.constants
     * 
     * @description
     * Método responsável por limpar a fila de logs de Execução.
     */
    function limparFilaExecucao() {
        sfFila.filaLogsExecucao = [];
    }

    /**
     * @ngdoc object
     * @name gerarTimestampUTC
     * 
     * @methodOf arq-spa-base.logging.constants
     * 
     * @description
     * Método responsável retornar um objeto contendo as informações de Timestamp e UTC para serem utilizados no log.
     */
    function gerarTimestampUTC() {

        var localTimestampZulu = new Date().toJSON();

        var objTimestamp = {
            timestamp: localTimestampZulu,
            gmt: 0
        };

        return objTimestamp;
    }

    /**
     * @ngdoc overview
     * @name arq-spa-base.logging.constants:sfFila
     * @module arq-spa-base.logging
     * 
     * @description
     * Constantes que armazenam os logs enfileirados pela arquitetura nas etapas de configuração.
     */
    angular.module("arq-spa-base.logging").constant("sfFila", sfFila);
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.filtros.factories:sfConectorLog
     * @module arq-spa-base.logging
     *
     * @description
     * Factory responsável por realizar a comunicação dos logs.
     */
    angular.module("arq-spa-base.logging").factory("sfConectorLog", sfConectorLog);

    sfConectorLog.$inject = ["$http", "appSettings", "sfMemorizador", "sfUtilitarios"];

    /**
     * @ngdoc overview
     * @name sfConectorLog
     *
     * @methodOf arq-spa-base.logging.factories:sfConectorLog
     *
     * @description
     * Função responsável por definir a factory.
     */
    function sfConectorLog($http, appSettings, sfMemorizador, sfUtilitarios) {

        return {
            executar: executar
        };

        /**
         * @ngdoc object
         * @name executar
         * 
         * @methodOf arq.spa.base.logging.factories:sfConectorLog
         * 
         * @description
         * Método responsável por executar a requisição de log.
         */
        function executar(config) {

            var deveRepresar = false;
            deveRepresar = verificarRepresamento(config);

            if (deveRepresar) {
                gravarLogLocalStorage(config);
            } else {
                var logsRepresados = recuperarLogsRepresados();
                logsRepresados.push(config);

                despacharLogs(logsRepresados);
            }

            return;
        }

        /**
         * @ngdoc object
         * @name verificarRepresamento
         * 
         * @methodOf arq.spa.base.logging.factories:sfConectorLog
         * 
         * @description
         * Método responsável por verificar se deve ser feito o represamento do log.
         */
        function verificarRepresamento(config) {
            var deveRepresar = false;

            if (config.tipoLog !== "erro") {
                var quantidadeLogsRepresados = obterQuantidadeLogRepresado();
                var quantidadeLimiteRepresamento = appSettings.configuracao.quantidadeMaxRepresamentoLog || 0;
                
                if (quantidadeLogsRepresados < quantidadeLimiteRepresamento) {
                    deveRepresar = true;
                }
            }


            return deveRepresar;
        }

        /**
         * @ngdoc object
         * @name verificarRepresamento
         * 
         * @methodOf arq.spa.base.logging.factories:sfConectorLog
         * 
         * @description
         * Método responsável por verificar se deve ser feito o represamento do log.
         */
        function obterQuantidadeLogRepresado() {
            var logsRepresados = recuperarLogsRepresados();
            return logsRepresados.length;
        }

        /**
         * @ngdoc object
         * @name gravarLogLocalStorage
         * 
         * @methodOf arq.spa.base.logging.factories:sfConectorLog
         * 
         * @description
         * Método responsável por gravar o registro do log na local storage.
         */
        function gravarLogLocalStorage(config) {
            var logsRepresados = recuperarLogsRepresados();
            logsRepresados.push(config);
            sfMemorizador.definir("represaLog", JSON.stringify(logsRepresados));

        }

        /**
         * @ngdoc object
         * @name despacharLogs
         * 
         * @methodOf arq.spa.base.logging.factories:sfConectorLog
         * 
         * @description
         * Método responsável por despachar todos os logs represados.
         */
        function despacharLogs(logs) {
            var configHttp = {
                data: logs,
                method: "POST",
                url: sfUtilitarios.combinarCaminhos([appSettings.comunicacao.urlLog, "gravar"]),
                log: true
            };

            $http(configHttp);

            sfMemorizador.removerChave("represaLog");
        }

        /**
         * @ngdoc object
         * @name recuperarLogsRepresados
         * 
         * @methodOf arq.spa.base.logging.factories:sfConectorLog
         * 
         * @description
         * Método responsável por recuperar todos os logs do local storage.
         */
        function recuperarLogsRepresados() {
            var logsRepresados;
            logsRepresados = sfMemorizador.obter("represaLog") != null ? JSON.parse(sfMemorizador.obter("represaLog")) : [];


            return logsRepresados;
        }
    }

})();
(function () {
    "use strict";

    /** 
     * @ngdoc provider
     * @name arq-spa-base.logging.factories:sfLogger
     * 
     * @module arq-spa-base.logging
     * 
     * @description
     * Serviço responsável por prover os recursos de log para a aplicação 
    */
    angular.module("arq-spa-base.logging").provider("sfLogger", sfLogger);

    sfLogger.$inject = ["sfFila"];

    /**
     * @ngdoc overview
     * @name logging
     * 
     * @methodOf arq-spa-base.logging.providers:sfLogger
     * 
     * @description
     * Método responsável por definir a factory do logger
    */
    function sfLogger(sfFila) {
        this.$get = get;
        this.enfileirarLogErro = enfileirarLogErro;
        this.enfileirarLogExecucao = enfileirarLogExecucao;

        get.$inject = ["$http", "$window", "sfContexto", "appSettings", "sfUtilitarios", "sfConectorLog"];

        /**
         * @ngdoc object
         * @name $get
         * 
         * @methodOf arq-spa-base.logging.providers:sfLogger
         * 
         * @description
         * Método responsável por retornar a instância deste provider
         * 
         * @returns {object} Objeto que representa a instância deste provider
        */
        function get($http, $window, sfContexto, appSettings, sfUtilitarios, sfConectorLog) {
            return new Logger($http, sfFila, $window, sfContexto, appSettings, sfUtilitarios, sfConectorLog);
        }

        /**
         * @ngdoc object
         * @name arq-spa-base-logging.providers:sfLogger
         * @module arq-spa-base.logging
         * 
         * @param {string} mensagem_        Mensagem a ser logada pela aplicação
         * @param {string} criticidade_     Criticidade do erro (Alta, Média, Baixa)
         * 
         * @description
         * Método responsável por enfileirar os logs de erro durante a etapa de configuração 
        */
        function enfileirarLogErro(mensagem_, criticidade_) {
            sfFila.enfileirarLogErro(mensagem_, criticidade_);

            return this;
        }

        /**
         * @ngdoc object
         * @name arq-spa-base-logging.providers:sfLogger
         * @module arq-spa-base.logging
         * 
         * @param {string} mensagem_        Mensagem a ser logada pela aplicação
         * @param {string} funcao_          Função que está sendo executada
         * @param {string} categoria_       Categoria do log (Info ou Warn)
         * 
         * @description
         * Método responsável por enfileirar os logs de execução durante a etapa de configuração 
        */
        function enfileirarLogExecucao(mensagem_, funcao_, categoria_) {
            sfFila.enfileirarLogExecucao(mensagem_, funcao_, categoria_);

            return this;
        }
    }

    /**
     * @ngdoc service
     * @name arq-spa-base.logging.services:sfLogger
     * @module arq-spa-base.logging
     * 
     * @requires sfFila
     * @requires $window
     * @requires sfContexto
     * @requires appSettings
     * @requires sfConectorAPI
     * 
     * @description
     * Definição do serviço responsável por prover os recursos de log da aplicação 
    */
    function Logger($http, sfFila, $window, sfContexto, appSettings, sfUtilitarios, sfConectorLog) {
        this.escreverLogErro = escreverLogErro;
        this.escreverLogNavegacao = escreverLogNavegacao;
        this.escreverLogExecucao = escreverLogExecucao;
        this.escreverLogComunicacao = escreverLogComunicacao;

        /**
         * @ngdoc object
         * @name escreverLogErro
         * 
         * @methodOf arq-spa-base.services.sfLogger
         * 
         * @description
         * Método responsável por escrever um log de erro e salvar os logs enfileirados, caso existam.
         * 
         * @param {string} mensagem_        Mensagem a ser logada pela aplicação
         * @param {string} criticidade_     Criticidade do erro (Alta, Média, Baixa)
        */
        function escreverLogErro(mensagem_, stacktrace_, criticidade_, origem_) {
            var sessionIdCtx = sfContexto.obterValorContextoSessao("IdSessao");
            var workIdCtx = ((sfContexto.contextoIniciado() && sfContexto.verificarExistenciaContextoTrabalho("IdTrabalho")) ? sfContexto.obterValorContextoTrabalho("IdTrabalho") : "");
            var aplicacao = appSettings.configuracao.aplicacao;
            var device = $window.navigator.userAgent;
            var objTimestamp = sfFila.gerarTimestampUTC();
            var filaErros = sfFila.retornarFilaErro();

            // Salva os erros armazenados na fila, caso existam
            if (filaErros && filaErros.length > 0) {
                filaErros.forEach(function (log) {
                    log.device = device;
                    log.aplicacao = aplicacao;
                    log.sessionId = sessionIdCtx;
                    log.workId = workIdCtx;

                    salvarLog(log, "erro");
                });
            }

            sfFila.limparFilaErro();

            var classeMetodo = ["",""];
            
            if (stacktrace_ && stacktrace_ !== "") {
                var callerLine = stacktrace_.split("\n")[1];
                var index = callerLine.indexOf("at ");
                var clean = callerLine.slice(index + 2, callerLine.indexOf("("));
                classeMetodo = clean.trim().split(".");
            }

            var objetoLog = {
                camada: "arqSPA",
                classe: origem_ && origem_.classe ? origem_.classe : classeMetodo[0],
                metodo: origem_ && origem_.metodo ? origem_.metodo : classeMetodo[1],
                deviceInfo: device,
                timestamp: objTimestamp.timestamp,
                gmt: objTimestamp.gmt,
                aplicacao: aplicacao,
                sessionId: sessionIdCtx,
                workId: workIdCtx,
                mensagem: mensagem_,
                stacktrace: stacktrace_,
                criticidade: criticidade_
            };

            salvarLog(objetoLog, "erro");

            return this;
        }

        /**
         * @ngdoc object
         * @name escreverLogNavegacao
         * 
         * @methodOf arq-spa-base.services.sfLogger
         * 
         * @description
         * Método responsável por escrever um log de navegação.
         * 
         * @param {string} fluxo_           Fluxo de navegação atual
         * @param {string} estadoOrigem_    Estado de origem do fluxo atual
         * @param {string} transicao_       Transição da navegação
         * @param {string} fluxoDestino_    Fluxo de destino da navegação
         * @param {string} estadoDestino_   Estado de destino da navegação
        */
        function escreverLogNavegacao(fluxoOrigem_, estadoOrigem_, transicao_, fluxoDestino_, estadoDestino_, origem_) {
            var logar = verificarExecucaoLog("info");

            if (logar) {
                var sessionIdCtx = sfContexto.obterValorContextoSessao("IdSessao");
                var workIdCtx = ((sfContexto.contextoIniciado() && sfContexto.verificarExistenciaContextoTrabalho("IdTrabalho")) ? sfContexto.obterValorContextoTrabalho("IdTrabalho") : "");
                var objTimestamp = sfFila.gerarTimestampUTC();
                var aplicacao = appSettings.configuracao.aplicacao;

                var objetoLog = {
                    camada: "arqSPA",
                    classe: origem_ && origem_.classe ? origem_.classe : "",
                    metodo: origem_ && origem_.metodo ? origem_.metodo : "",
                    timestamp: objTimestamp.timestamp,
                    gmt: objTimestamp.gmt,
                    aplicacao: aplicacao,
                    sessionId: sessionIdCtx,
                    workId: workIdCtx,
                    fluxoOrigem: fluxoOrigem_,
                    estadoOrigem: estadoOrigem_,
                    transicao: transicao_,
                    fluxoDestino: fluxoDestino_,
                    estadoDestino: estadoDestino_
                };

                salvarLog(objetoLog, "navegacao");
            }

            return this;
        }

        /**
         * @ngdoc object
         * @name escreverLogExecucao
         * 
         * @methodOf arq-spa-base.services.sfLogger
         * 
         * @description
         * Método responsável por escrever um log de execução e salvar os logs enfileirados, caso existam.
         * 
         * @param {string} mensagem_        Mensagem a ser logada pela aplicação
         * @param {string} funcao_          Função que está sendo executada
         * @param {string} fluxo_           Fluxo de navegação atual
         * @param {string} estado_          Estado atual
         * @param {string} categoria_       Categoria do log (Info ou Warn)
        */
        function escreverLogExecucao(mensagem_, funcao_, fluxo_, estado_, categoria_, origem_) {
            var logar = verificarExecucaoLog(categoria_);

            if (logar) {
                var sessionIdCtx = sfContexto.obterValorContextoSessao("IdSessao");
                var workIdCtx = ((sfContexto.contextoIniciado() && sfContexto.verificarExistenciaContextoTrabalho("IdTrabalho")) ? sfContexto.obterValorContextoTrabalho("IdTrabalho") : "");
                var aplicacao = appSettings.configuracao.aplicacao;
                var device = $window.navigator.userAgent;
                var objTimestamp = sfFila.gerarTimestampUTC();
                var filaExecucao = sfFila.retornarFilaExecucao();

                // Salva os erros armazenados na fila, caso existam
                if (filaExecucao && filaExecucao.length > 0) {
                    filaExecucao.forEach(function (log) {
                        log.device = device;
                        log.aplicacao = aplicacao;
                        log.sessionId = sessionIdCtx;
                        log.workId = workIdCtx;

                        salvarLog(log, "execucao");
                    });
                }

                sfFila.limparFilaExecucao();

                var objetoLog = {
                    camada: "arqSPA",
                    classe: origem_ && origem_.classe ? origem_.classe : "",
                    metodo: origem_ && origem_.metodo ? origem_.metodo : "",
                    timestamp: objTimestamp.timestamp,
                    gmt: objTimestamp.gmt,
                    aplicacao: aplicacao,
                    sessionId: sessionIdCtx,
                    workId: workIdCtx,
                    mensagem: mensagem_,
                    funcao: funcao_,
                    categoria: categoria_,
                    fluxo: fluxo_,
                    estado: estado_,
                    deviceInfo: device
                };

                salvarLog(objetoLog, "execucao");
            }

            return this;
        }

        /**
         * @ngdoc object
         * @name escreverLogComunicacao
         * 
         * @methodOf arq-spa-base.services.sfLogger
         * 
         * @description
         * Método responsável por escrever um log de comunicação.
         * 
         * @param {string} mensagem_            Mensagem a ser logada pela aplicação
         * @param {string} funcao_              Função que está sendo executada
         * @param {string} tipo_                Tipo da comunicação (Request ou Response)
         * @param {string} configRequisicao_    configRequisicao da requisição
         * @param {string} categoria_           Categoria do log (Info ou Warn)
         * @param {string} messageId_           Id de mensagem da requisição
         * @param {string} httpStatus_          Http status do response
        */
        function escreverLogComunicacao(mensagem_, funcao_, tipo_, configRequisicao_, categoria_, messageId_, httpStatus_, origem_) {
            var logar = verificarExecucaoLog("info");

            if (logar) {
                var sessionIdCtx = sfContexto.obterValorContextoSessao("IdSessao");
                var workIdCtx = ((sfContexto.contextoIniciado() && sfContexto.verificarExistenciaContextoTrabalho("IdTrabalho")) ? sfContexto.obterValorContextoTrabalho("IdTrabalho") : "");
                var objTimestamp = sfFila.gerarTimestampUTC();
                var device = $window.navigator.userAgent;
                var aplicacao = appSettings.configuracao.aplicacao;

                var objetoLog = {
                    camada: "arqSPA",
                    classe: origem_ && origem_.classe ? origem_.classe : "",
                    metodo: origem_ && origem_.metodo ? origem_.metodo : "",
                    deviceInfo: device,
                    timestamp: objTimestamp.timestamp,
                    gmt: objTimestamp.gmt,
                    aplicacao: aplicacao,
                    sessionId: sessionIdCtx,
                    workId: workIdCtx,
                    messageId: messageId_,
                    mensagem: mensagem_,
                    funcao: funcao_,
                    tipo: tipo_,
                    configRequisicao: configRequisicao_,
                    categoria: categoria_,
                    httpStatus: httpStatus_
                };

                salvarLog(objetoLog, "comunicacao");
            }

            return this;
        }

        /**
         * @ngdoc object
         * @name salvarLog
         * 
         * @methodOf arq.spa.base.logging.services:sfLogger
         * 
         * @description
         * Método responsável por persistir os logs da aplicação  
        */
        function salvarLog(objLog, funcaoLog) {
            var configLog = {
                tipoLog: funcaoLog,
                data: objLog
            };

            sfConectorLog.executar(configLog);

            return;
        }

        /**
         * @ngdoc object
         * @name verificarExecucaoLog
         * 
         * @methodOf arq.spa.base.logging.services:sfLogger
         * 
         * @description
         * Método responsável por verificar se deve ou não logar
         */
        function verificarExecucaoLog(categoria_) {
            var statusLogExecucao = "";
            if (categoria_.match(/info/i)) {
                statusLogExecucao = sfContexto.obterValorContextoSessao("logInfo");
            } else if (categoria_.match(/warn/i)) {
                statusLogExecucao = sfContexto.obterValorContextoSessao("logWarning");
            }

            if (angular.isUndefined(statusLogExecucao) || statusLogExecucao === "") {
                statusLogExecucao = appSettings.configuracao.padraoLogarInformativo;
            }

            return statusLogExecucao;
        }
    }
})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.mensagens
     * 
     * @description
     * Módulo de mensagens que provê os recursos necessários para exibição de modal.
     */
    angular.module("arq-spa-base.mensagens", []);
})();

(function () {
    /*
    * @description
    * Controller responsável pela tratativa das ações a serem realizadas pelo componente para exibição de modal.
    */
    angular.module("arq-spa-base.mensagens").controller("sfExibicaoModalCtrl", sfExibicaoModalCtrl);


    sfExibicaoModalCtrl.$inject = ["$uibModalInstance", "dados"];
     
     
      /**
         * @ngdoc method
         * @name esfExibicaoModalCtrl
         *
         * @methodOf arq-spa-base.mensagens.controllers:sfExibicaoModalCtrl
         *  
         * @description
         * Método responsável  pela tratativa das ações a serem realizadas pelo componente para exibição de modal.
         * 
         * @param {string} Título que será obtido para exibição no cabeçalho do modal.
         * @param {string} Mensagem que será obtida para ser incluida o corpo do modal.
         */
    function sfExibicaoModalCtrl($uibModalInstance, dados) {

        var vm = this;

        vm.titulo = dados.titulo;
        vm.mensagem = dados.mensagem;

        vm.acaoOK = function (dadosModalOK) {
            $uibModalInstance.close(dadosModalOK);
        };

        vm.acaoCancelar = function (dadosModalCancelar) {
            $uibModalInstance.dismiss(dadosModalCancelar);
        };


    }

})();
(function () {
    "use strict";

    angular.module("arq-spa-base.mensagens").factory("sfExibicaoMensagem", sfExibicaoMensagem);

    sfExibicaoMensagem.$inject = ["$uibModal", "sfLogger", "$uibModalStack", "$rootScope", "appSettings"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.mensagens.factories:sfExibicaoMensagem
     * @module arq-spa-base.mensagens
     * 
     * @requires $uibModal
     * 
     * @description
     * Factory resposável por prover os recursos necessários para a exibição do Modal
     */
    function sfExibicaoMensagem($uibModal, sfLogger, $uibModalStack, $rootScope, appSettings) {
        return {
            exibirModalCustomizado: exibirModalCustomizado,
            exibirModal: exibirModal,
            exibirModalCustomizadoCompleto: exibirModalCustomizadoCompleto,
            fecharModal: fecharModal
        };

        /**
         * @ngdoc method
         * @name exibirModalCustomizado
         *
         * @methodOf arq-spa-base.mensagens.factories:sfExibicaoMensagem
         *  
         * @description
         * Método responsável por consumir os parâmetros necessários para a exibição do Modal
         * 
         * @param {string} Indificador do Html que contém o template para a estruturação do modal.
         * @param {string} Tamanho que será obtido para a exibição do modal.
         * @param {object} Controller responsável por realizar o tratamento da apresentação de dados e eventos dos botões que serão exibidos no modal. 
         * @param {object} Informações que serão incluidas no template do modal, tais como: Título, mensagem
         * @param {Boolean} keyboard Indicador que controla se pode fechar o modal via esc
         * @param {Boolean} backdrop Indicador que controla se pode fechar o modal via click no fundo
         * @param {object} opcoesCustomizado Opcoes utilizadas no popup
         */
        function exibirModalCustomizado(caminhoTemplate, tamanho, controller, controllerAs, dados, keyboard, backdrop, opcoesCustomizado) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfExibicaoMensagem.exibirModalCustomizado", "", "", "Info",
                { classe: "sfExibicaoMensagem", metodo: "exibirModalCustomizado" });
            if (
                angular.isDefined(caminhoTemplate) && angular.isString(caminhoTemplate) && caminhoTemplate !== "" &&
                angular.isDefined(tamanho) && angular.isString(tamanho) && tamanho !== "" &&
                angular.isDefined(controller) && angular.isDefined(controllerAs) &&
                angular.isDefined(dados)
            ) {
                keyboard = (angular.isUndefined(keyboard)) ? true : keyboard;
                backdrop = (angular.isUndefined(backdrop)) ? "static" : backdrop;

                var opcoesDefault = {
                    animation: true,
                    templateUrl: caminhoTemplate,
                    controller: controller,
                    controllerAs: controllerAs,
                    backdrop: backdrop,
                    size: tamanho,
                    keyboard: keyboard,
                    resolve: {
                        dados: function () {
                            return dados;
                        }
                    }
                };

                var opcoes = angular.merge(opcoesDefault, opcoesCustomizado);

                var instanciaModal = $uibModal.open(opcoes);
                
                reiniciarTimeoutNavegacao(instanciaModal);
            } else {
                throw new Error("Não foram informados os dados necessários para exibição do Modal");
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfExibicaoMensagem.exibirModalCustomizado", "", "", "Info",
                { classe: "sfExibicaoMensagem", metodo: "exibirModalCustomizado" });
            return instanciaModal.result;
        }

        /**
         * @ngdoc method
         * @name exibirModal
         *
         * @methodOf arq-spa-base.mensagens.factories:sfExibicaoMensagem
         *  
         * @description
         * Método responsável por consumir os parâmetros necessários para a exibição do Modal
         * 
         * @param {object} Informações que serão incluidas no template do modal, tais como: Título, mensagem
         * @param {string} Indificador do Html que contém o template para a estruturação do modal.
         * @param {string} Tamanho que será obtido para a exibição do modal.
         * @param {Boolean} keyboard Indicador que controla se pode fechar o modal via esc
         * @param {Boolean} backdrop Indicador que controla se pode fechar o modal via click no fundo
         */
        function exibirModal(dados, caminhoTemplate, tamanho, keyboard, backdrop) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfExibicaoMensagem.exibirModal", "", "", "Info",
                { classe: "sfExibicaoMensagem", metodo: "exibirModal" });
            if (angular.isDefined(dados) &&
                angular.isDefined(caminhoTemplate) && angular.isString(caminhoTemplate) && caminhoTemplate !== "" &&
                angular.isDefined(tamanho) && angular.isString(tamanho) && tamanho !== "") {
                keyboard = (angular.isUndefined(keyboard)) ? true : keyboard;
                backdrop = (angular.isUndefined(backdrop)) ? "static" : backdrop;

                var instanciaModal = $uibModal.open({
                    animation: true,
                    templateUrl: caminhoTemplate,
                    controller: "sfExibicaoModalCtrl",
                    controllerAs: "mCtrl",
                    backdrop: backdrop,
                    size: tamanho,
                    keyboard: keyboard,
                    resolve: {
                        dados: function () {
                            return dados;
                        }
                    }
                });
                
                reiniciarTimeoutNavegacao(instanciaModal);

                sfLogger.escreverLogExecucao("Término de execução.", "sfExibicaoMensagem.exibirModal", "", "", "Info",
                    { classe: "sfExibicaoMensagem", metodo: "exibirModal" });

                return instanciaModal.result;
            } else {
                throw new Error("Não foram informados os dados necessários para exibição do Modal");
            }
        }

        /**
         * @ngdoc method
         * @name exibirModalCustomizadoCompleto
         *
         * @methodOf arq-spa-base.mensagens.factories:sfExibicaoMensagem
         *  
         * @description
         * Método responsável por consumir os parâmetros necessários para a exibição do Modal
         * 
         * @param {object} opces Objeto de opções para o $uibModal.
         */
        function exibirModalCustomizadoCompleto(opcoes) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfExibicaoMensagem.exibirModalCustomizadoCompleto", "", "", "Info",
                { classe: "sfExibicaoMensagem", metodo: "exibirModalCustomizadoCompleto" });
            if (angular.isDefined(opcoes)) {

                var opcoesDefault = {
                    animation: true,
                    controller: "sfExibicaoModalCtrl",
                    controllerAs: "mCtrl",
                    backdrop: "static",
                    size: "md",
                    keyboard: true,
                    resolve: {
                        dados: function () {
                            return opcoes.dados;
                        }
                    }
                };

                opcoes = angular.merge(opcoesDefault, opcoes);

                var instanciaModal = $uibModal.open(opcoes);

                sfLogger.escreverLogExecucao("Término de execução.", "sfExibicaoMensagem.exibirModalCustomizadoCompleto", "", "", "Info",
                    { classe: "sfExibicaoMensagem", metodo: "exibirModalCustomizadoCompleto" });

                reiniciarTimeoutNavegacao(instanciaModal);
                return instanciaModal.result;

            } else {
                sfLogger.escreverLogExecucao("Término de execução.", "sfExibicaoMensagem.exibirModalCustomizadoCompleto", "", "", "Info",
                    { classe: "sfExibicaoMensagem", metodo: "exibirModalCustomizadoCompleto" });

                throw new Error("Não foram informados os dados necessários para exibição do Modal");
            }
        }

        /**
         * @ngdoc method
         * @name fecharModal
         *
         * @methodOf arq-spa-base.mensagens.factories:sfExibicaoMensagem
         *  
         * @description
         * Método responsável por esconder todos os modais
         * 
         * @param {object} razoes Motivo para o fechamento dos modais
         */
        function fecharModal(razoes) {
            $uibModalStack.dismissAll(razoes);
        }

        /**
         * @ngdoc method
         * @name reiniciarTimeoutNavegacao
         *
         * @methodOf arq-spa-base.mensagens.factories:sfExibicaoMensagem
         *  
         * @description
         * Método responsável que dispara evento de reinicialização de timeout,
         * verificando se deve se deve ou não reiniciar timeout padrão de sessão de tela
         */
        function reiniciarTimeoutNavegacao(instanciaModal) {
            if (appSettings.navegacao.renovarTimoutAoAbrirModal === true) {
                instanciaModal.opened.then(reiniciar);
                instanciaModal.closed.then(reiniciar);
            }

            /**
             * @ngdoc method
             * @name reiniciar
             *
             * @methodOf arq-spa-base.mensagens.factories:sfExibicaoMensagem
             *  
             * @description
             * Dispara evento de reinicialização
             */
            function reiniciar() {
                $rootScope.$emit("reiniciarTempoSessaoTela");
            }
        }
    }
})();





(function () {
    "use strict";
/**
 * @ngdoc overview
 * @name arq-spa-base.navegacao
 * 
 * @requires ui.router
 * @requires oc.lazyLoad
 * 
 * @description
 * Módulo de navegação da arquitetura base que provê os recursos necessários para configuração e alteração de estados de navegação.
 */
angular.module("arq-spa-base.navegacao", ["ui.router",
                                          "oc.lazyLoad", 
                                          "arq-spa-base.logging"]);
})();
(function () {
    "use strict";

    /**
     * @ngdoc directive
     * @name arq-spa-base.navegacao.directives:sfIniciarFluxo
     * 
     * @module arq-spa-base.navegacao
     * 
     * @description
     * Diretiva responsável por efetuar a iniciação de um fluxo do navegador.
     */
    angular.module("arq-spa-base.navegacao").directive("sfIniciarFluxo", sfIniciarFluxo);

    sfIniciarFluxo.$inject = ["sfNavegador"];

    /**
     * @ngdoc method
     * @name sfIniciarFluxo
     * 
     * @methodOf arq-spa-base.navegacao.directives:sfIniciarFluxo
     * 
     * @description
     * Método responsável por definir a diretiva "sfIniciarFluxo".
     */
    function sfIniciarFluxo(sfNavegador) {
        return {
            restrict: "A",
            priority: 1,
            terminal: false,
            scope: false,
            link: linkIniciarFluxo
        };

        /**
         * @ngdoc method
         * @name linkIniciarFluxo
         * 
         * @methodOf arq-spa-base.navegacao.directives:linkIniciarFluxo
         * 
         * @param {object} scope_ Escopo da aplicação.
         * @param {object} element_ Elemento ao qual a diretiva está associada.
         * 
         * @description
         * Método responsável por tratar o evento "link" da diretiva.
         */
        function linkIniciarFluxo(scope_, element_, attrs_) {
            element_.bind("click", eventoClick);

            /**
             * ngdoc method
             * @name eventoClick
             * 
             * @methodOf arq-spa-base.navegacao.directives:eventoClick
             * 
             * @description
             * Método responsável por tratar o evento "click" do elemento ao qual a diretiva está associado e efetuar a inicialização do fluxo definido como parâmetro.
             */
            function eventoClick() {
                var fluxoDestino = attrs_.sfIniciarFluxo;
                var opcoes;
                if ("sfIniciarFluxoOpcoes" in attrs_) {
                    opcoes = scope_.$eval(attrs_.sfIniciarFluxoOpcoes);
                }

                sfNavegador.iniciarFluxo(fluxoDestino, undefined, opcoes);
            }
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc directive
     * @name arq-spa-base.navegacao.directives:sfNavegar
     * 
     * @module arq-spa-base.navegacao
     * 
     * @description
     * Diretiva responsável por efetuar a navegação entre estados.
     */
    angular.module("arq-spa-base.navegacao").directive("sfNavegar", sfNavegar);

    sfNavegar.$inject = ["sfNavegador"];

    /**
     * @ngdoc method
     * @name sfIniciarFluxo
     * 
     * @methodOf arq-spa-base.navegacao.directives:sfNavegar
     * 
     * @description
     * Método responsável por definir a diretiva "sfNavegar".
     */
    function sfNavegar(sfNavegador) {
        return {
            restrict: "A",
            priority: 1,
            terminal: false,
            scope: false,
            link: linkNavegar
        };

        /**
         * @ngdoc method
         * @name linkNavegar
         * 
         * @methodOf arq-spa-base.navegacao.directives:linkNavegar
         * 
         * @param {object} scope_ Escopo da aplicação.
         * @param {object} element_ Elemento ao qual a diretiva está associada.
         * 
         * @description
         * Método responsável por tratar o evento "link" da diretiva.
         */
        function linkNavegar(scope_, element_, attrs_) {
            element_.bind("click", eventoClick);

            /**
             * ngdoc method
             * @name eventoClick
             * 
             * @methodOf arq-spa-base.navegacao.directives:eventoClick
             * 
             * @description
             * Método responsável por tratar o evento "click" do elemento ao qual a diretiva está associado e efetuar a navegação dos estados, definido como parâmetro na transiçao.
             * 
             */
            function eventoClick() {
                var transicao = attrs_.sfNavegar;
                var opcoes;
                if ("sfNavegarOpcoes" in attrs_) {
                    opcoes = scope_.$eval(attrs_.sfNavegarOpcoes);
                }

                sfNavegador.navegar(transicao, undefined, opcoes);
            }
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc directive
     * @name arq-spa-base.navegacao.directives:sfVoltar
     * 
     * @module arq-spa-base.navegacao
     * 
     * @description
     * Diretiva responsável por efetuar a navegação ao estado anterior.
     */
    angular.module("arq-spa-base.navegacao").directive("sfVoltar", sfVoltar);

    sfVoltar.$inject = ["sfNavegador"];

    /**
     * @ngdoc method
     * @name sfVoltar
     * 
     * @methodOf arq-spa-base.navegacao.directives:sfVoltar
     * 
     * @description
     * Método responsável por definir a diretiva "sfVoltar".
     */
    function sfVoltar(sfNavegador) {
        return {
            restrict: "A",
            priority: 1,
            terminal: false,
            link: linkVoltar
        };

        /**
         * @ngdoc method
         * @name linkVoltar
         * 
         * @methodOf arq-spa-base.navegacao.directives:linkVoltar
         * 
         * @param {object} scope_ Escopo da aplicação.
         * @param {object} element_ Elemento ao qual a diretiva está associada.
         * 
         * @description
         * Método responsável por tratar o evento "link" da diretiva.
         */
        function linkVoltar(scope_, element_) {
            element_.bind("click", eventoClick);

            /**
             * ngdoc method
             * @name eventoClick
             * 
             * @methodOf arq-spa-base.navegacao.directives:eventoClick
             * 
             * @description
             * Método responsável por tratar o evento "click" do elemento ao qual a diretiva está associado e executar o método voltar entre os estados.
             */
            function eventoClick() {
                sfNavegador.voltar();
            }
        }
    }
})();
(function () {
    /**
     * @ngdoc overview
     * @name arq-spa-base.navegacao.providers:sfNavegador
     * @module arq-spa-base.navegacao
     * 
     * @requires $stateProvider
     * 
     * @description
     * Provider responsável por prover os recursos de configuração e execução de navegações entre estados.
     */
    angular.module("arq-spa-base.navegacao").provider("sfNavegador", sfNavegador);

    sfNavegador.$inject = ["$stateProvider", "sfLoggerProvider"];

    /**
     * @ngdoc overview
     * @name sfNavegador
     *
     * @methodOf arq-spa-base.navegacao.providers:sfNavegador
     *  
     * @param {object} $stateProvider Instância do provider do angular-ui-router
     * 
     * @description
     * Método responsável por definir o provider de navegação.
     */
    function sfNavegador($stateProvider, sfLoggerProvider) {
        this.$get = get;
        this.criarFluxoNavegacao = criarFluxoNavegacao;
        this.adicionarFluxoNavegacao = adicionarFluxoNavegacao;

        get.$inject = ["$http", "$rootScope", "$ocLazyLoad", "$state", "appSettings", "sfUtilitarios", "sfLogger", "$timeout", "$transitions", "sfConfiguracaoDinamica", "$analytics", "sfTeclaAtalhoTela", "$window", "sfExibicaoMensagem", "$log", "$q", "sfTradutor"];

        var _fluxosNavegacao = [];

        /**
         * @ngdoc method
         * @name $get
         *
         * @methodOf arq-spa-base.navegacao.providers:sfNavegador
         * 
         * @requires $http
         * @requires $rootScope
         * @requires $ocLazyLoad
         * @requires $state
         * @requires appSettings
         * @requires sfUtilitarios
         * 
         * @description
         * Método responsável por retornar a instância deste provider.
         * 
         * @returns {object} Objeto que representa a instância deste provider.
         */
        function get($http, $rootScope, $ocLazyLoad, $state, appSettings, sfUtilitarios, sfLogger, $timeout, $transitions, sfConfiguracaoDinamica, $analytics, sfTeclaAtalhoTela, $window, sfExibicaoMensagem, $log, $q, sfTradutor) {
            return new Navegador($http, $rootScope, $ocLazyLoad, $state, appSettings, sfUtilitarios, _fluxosNavegacao, sfLogger, $timeout, $transitions, sfConfiguracaoDinamica, $analytics, sfTeclaAtalhoTela, $window, sfExibicaoMensagem, $log, $q, sfTradutor);
        }

        /**
         * @ngdoc method
         * @name criarFluxoNavegacao
         *
         * @methodOf arq-spa-base.navegacao.providers:sfNavegador
         *  
         * @description
         * Método responsável por criar um fluxo de navegação.
         * 
         * @param {string} idFluxo_ Identificador único do fluxo de navegação que deverá ser criado.
         * 
         * @returns {object} Fluxo de navegação criado com base nas configurações definidas.
         */
        function criarFluxoNavegacao(idFluxo_) {
            sfLoggerProvider.enfileirarLogExecucao("Início de execução.", "sfNavegadorProvider.criarFluxoNavegacao", "", "", "Info");
            if (angular.isDefined(idFluxo_) && angular.isString(idFluxo_) && idFluxo_ !== "") {
                sfLoggerProvider.enfileirarLogExecucao("Término de execução.", "sfNavegadorProvider.criarFluxoNavegacao", "", "", "Info");
                return new FluxoNavegacao(idFluxo_);
            }
            else {
                sfLoggerProvider.enfileirarLogExecucao("Término de execução.", "sfNavegadorProvider.criarFluxoNavegacao", "", "", "Info");
                throw new Error("Deve ser definido um identificador único para o fluxo a ser criado.");
            }
        }

        /**
         * @ngdoc method
         * @name adicionarFluxoNavegacao
         *
         * @methodOf arq-spa-base.navegacao.providers:sfNavegador
         *  
         * @description
         * Método responsável por adicionar um fluxo de navegação.
         * 
         * @param {object} fluxoNavegacao_ Configuração do fluxo de navegação que derá adicionado.
         * 
         * @returns {object} Instância do configurador do navegador.
         */
        function adicionarFluxoNavegacao(fluxoNavegacao_) {
            sfLoggerProvider.enfileirarLogExecucao("Início de execução.", "sfNavegadorProvider.adicionarFluxoNavegacao", "", "", "Info");
            if (angular.isDefined(fluxoNavegacao_) && angular.isObject(fluxoNavegacao_)) {
                if (!verificarExistenciaFluxo(fluxoNavegacao_.idFluxo())) {
                    var estadosFluxo = fluxoNavegacao_.estados();

                    if (angular.isDefined(estadosFluxo) && angular.isArray(estadosFluxo) && estadosFluxo.length > 0) {
                        if (angular.isDefined(fluxoNavegacao_.estadoInicial())) {
                            estadosFluxo.forEach(adicionarEstadoMotorNavegacao);

                            _fluxosNavegacao.push(fluxoNavegacao_);
                        }
                        else {
                            sfLoggerProvider.enfileirarLogExecucao("Término de execução.", "sfNavegadorProvider.adicionarFluxoNavegacao", "", "", "Info");
                            throw new Error("Não foi definido um estado inicial para o \"" + fluxoNavegacao_.idFluxo() + "\".");
                        }
                    }
                    else {
                        sfLoggerProvider.enfileirarLogExecucao("Término de execução.", "sfNavegadorProvider.adicionarFluxoNavegacao", "", "", "Info");
                        throw new Error("Não foram definidos estados para o \"" + fluxoNavegacao_.idFluxo() + "\".");
                    }
                }
                else {
                    sfLoggerProvider.enfileirarLogExecucao("Término de execução.", "sfNavegadorProvider.adicionarFluxoNavegacao", "", "", "Info");
                    throw new Error("Já existe um fluxo de navegação com o id \"" + fluxoNavegacao_.idFluxo() + "\" definidio.");
                }
            }
            else {
                sfLoggerProvider.enfileirarLogExecucao("Término de execução.", "sfNavegadorProvider.adicionarFluxoNavegacao", "", "", "Info");
                throw new Error("Não foi informado um fluxo de navegação para adição.");
            }

            sfLoggerProvider.enfileirarLogExecucao("Término de execução.", "sfNavegadorProvider.adicionarFluxoNavegacao", "", "", "Info");
            return this;
        }

        /**
         * @ngdoc method
         * @name verificarExistenciafluxo
         *
         * @methodOf arq-spa-base.navegacao.providers:sfNavegador
         *  
         * @description
         * Método responsável por verificar se o fluxo de navegação informado já existe ou não no motor.
         * 
         * @param {string} idFluxo_ Identificador único do fluxo de navegação que será verificado.
         * 
         * @returns {boolean} True caso o fluxo informado já exista ou false caso contrário.
         */
        function verificarExistenciaFluxo(idFluxo_) {
            var fluxoExistente = false;

            if (_fluxosNavegacao.length > 0) {
                _fluxosNavegacao.some(function (fluxo) {
                    if (fluxo.idFluxo() === idFluxo_) {
                        fluxoExistente = true;
                    }

                    return fluxoExistente;
                });
            }

            return fluxoExistente;
        }

        /**
         * @ngdoc method
         * @name adicionarEstadoMotorNavegacao
         *
         * @methodOf arq-spa-base.navegacao.providers:sfNavegador
         *  
         * @description
         * Método responsável por adicionar o estado definido ao motor de navegação.
         * 
         * @param {object} estado_ Definições do estado que será adicionado ao motor de navegação.
         */
        function adicionarEstadoMotorNavegacao(estado_) {
            $stateProvider.state(estado_.id, estado_.configuracao);
        }
    }

    /**
     * @ngdoc overview
     * @name arq-spa-base.navegacao.services:FluxoNavegacao
     * @module arq-spa-base.navegacao
     * 
     * @param {string} idFluxo_ Identificador único do fluxo de navegação.
     * 
     * @description
     * Definição da estrutura de fluxos de navegação e suas funcionalidades.
     */
    function FluxoNavegacao(idFluxo_) {
        var _idFluxo = idFluxo_;
        var _estados = [];
        var _estadoInicial;

        this.idFluxo = obterIdFluxo;
        this.adicionarEstado = adicionarEstado;
        this.estados = obterEstados;
        this.definirEstadoInicial = definirEstadoInicial;
        this.estadoInicial = obterEstadoIncial;

        /**
         * @ngdoc method
         * @name obterIdFluxo
         * 
         * @methodOf arq-spa-base.navegacao.providers:FluxoNavegacao
         * 
         * @description
         * Método responsável obter o identificador único fluxo atual.
         *
         * @returns {string} Identificador único do fluxo atual. 
         */
        function obterIdFluxo() {
            return _idFluxo;
        }

        /**
         * @ngdoc method
         * @name adicionarEstado
         * 
         * @methodOf arq-spa-base.navegacao.providers:FluxoNavegacao
         * 
         * @description
         * Método responsável adicionar um estado ao fluxo de navegação.
         * 
         * @param {string} idEstado_ Identificador único do estado que será configurado no $stateProvider.
         * @param {object} configEstado_ Objeto que contém a configuração de um estdo e será utilizado como base para a configuração do $stateProvider.
         * @param {array} transicoesEstado_ Transições que o estado está apto a efetuar.
         * @param {object} parametros_ Parânetros do estado que serão disponibilizados quando do acesso ao mesmo.
         * 
         * returns {object} Instância do fluxo de navegação atual.
         */
        function adicionarEstado(idEstado_, configEstado_, transicoesEstado_, parametros_) {
            if (!verificarExistenciaEstado(idEstado_)) {
                _estados.push({
                    id: idEstado_,
                    configuracao: configEstado_,
                    transicoes: transicoesEstado_,
                    parametros: parametros_
                });
            }
            else {
                throw new Error("Já existe um estado com o identificador \"" + idEstado_ + "\" atribuido ao fluxo \"" + _idFluxo + "\".");
            }

            return this;
        }

        /**
         * @ngdoc method
         * @name obterEstados
         * 
         * @methodOf arq-spa-base.navegacao.providers:FluxoNavegacao
         * 
         * @description
         * Método responsável obter a lista de estados de navegação associados ao fluxo atual.
         *
         * @returns {array} Lista de estados de navegação associados ao fluxo atual. 
         */
        function obterEstados() {
            return _estados;
        }

        /**
         * @ngdoc method
         * @name definirEstadoInicial
         * 
         * @methodOf arq-spa-base.navegacao.providers:FluxoNavegacao
         * 
         * @description
         * Método responsável adicionar um estado ao fluxo de navegação.
         * 
         * @param {string} idEstadoInicial_ Identificador único do estado que será definido como estado inicial deste fluxo.
         * 
         * returns {object} Instância do fluxo de navegação atual.
         */
        function definirEstadoInicial(idEstadoInicial_) {
            if (verificarExistenciaEstado(idEstadoInicial_)) {
                _estadoInicial = idEstadoInicial_;
            }
            else {
                throw new Error("Não existe um estado com o identificador \"" + idEstadoInicial_ + "\" atribuido ao fluxo \"" + _idFluxo + "\".");
            }

            return this;
        }

        /**
         * @ngdoc method
         * @name obterEstadoIncial
         * 
         * @methodOf arq-spa-base.navegacao.providers:FluxoNavegacao
         * 
         * @description
         * Método responsável obter o identificador único do estado incial definido para o fluxo atual.
         *
         * @returns {string} Identificador único do estado inicial definido para o fluxo atual. 
         */
        function obterEstadoIncial() {
            return _estadoInicial;
        }

        /**
         * @ngdoc method
         * @name verificarExistenciaEstado
         *
         * @methodOf arq-spa-base.navegacao.providers:FluxoNavegacao
         *  
         * @description
         * Método responsável por verificar se o estado de navegação informado já existe ou não no fluxo atual.
         * 
         * @param {string} idEstado_ Identificador único do estado de navegação que será verificado.
         * 
         * @returns {boolean} True caso o estado informado já exista ou false caso contrário.
         */
        function verificarExistenciaEstado(idEstado_) {
            var estadoExistente = false;

            if (_estados.length > 0) {
                _estados.some(function (estado) {
                    if (estado.id === idEstado_) {
                        estadoExistente = true;
                    }

                    return estadoExistente;
                });
            }

            return estadoExistente;
        }
    }

    /**
     * @ngdoc overview
     * @name arq-spa-base.navegacao.services:Navegador
     * @module arq-spa-base.navegacao
     * 
     * @requires $http
     * @requires $rootScope
     * @requires $ocLazyLoad
     * @requires $state
     * @requires appSettings
     * @requires sfUtilitarios
     * 
     * @param {array} fluxos_ Lista de fluxos de navegação configurados
     * 
     * @description
     * Definição da do serviço de navegação retornado pela instância do provider.
     */
    function Navegador($http, $rootScope, $ocLazyLoad, $state, appSettings, sfUtilitarios, fluxos_, sfLogger, $timeout, $transitions, sfConfiguracaoDinamica, $analytics, sfTeclaAtalhoTela, $window, sfExibicaoMensagem, $log, $q, sfTradutor) {

        this.iniciar = iniciar;
        this.iniciarFluxo = iniciarFluxo;
        this.navegar = navegar;
        this.encadeamento = encadeamento;
        this.voltar = voltar;
        this.obterEstadoAtual = obterEstadoAtual;
        this.iniciarTempoSessaoTela = iniciarTempoSessaoTela;

        var _dependencias;
        var _internacionalizacoes;
        var _navegadorIniciado = false;
        var _estadoAtual;
        var _encadeamento;
        var _timeoutPromise;

        escutarEventosNavegacao();

        /**
          * @ngdoc method
          * @name escutarEventosNavegacao
          * 
          * @methodOf arq-spa-base.navegacao.services:Navegador
          * 
          * @description
          * Método responsável por tratar os eventos atribuidos para a navegação
          */
        function escutarEventosNavegacao() {
            $rootScope.$on("reiniciarTempoSessaoTela", iniciarTempoSessaoTela);
        }

        /**
          * @ngdoc method
          * @name obterEstado
          * 
          * @methodOf arq-spa-base.navegacao.services:Navegador
          * 
          * @description
          * Método por retornar o objeto de estado atual.
          * 
          */
        function obterEstadoAtual() {
            return angular.copy(_estadoAtual);
        }


        /**
          * @ngdoc method
          * @name tratamentoNavegacaoEstados
          * 
          * @methodOf arq-spa-base.navegacao.services:Navegador
          * 
          * @description
          * Método responsável por tratar a transição entre estados.
          * Gravando as informações no analytics e iniciando o tempo de sessão de tela/estado.
          * 
          */
        function tratamentoNavegacaoEstados() {
            if (angular.isDefined(_estadoAtual) && angular.isDefined(_estadoAtual.fluxoAtual)) {
                $analytics.pageTrack("/" + _estadoAtual.fluxoAtual.idFluxo() + "/" + _estadoAtual.id);
            }
            sfTeclaAtalhoTela.descadastrarTodasTeclasTela();
            iniciarTempoSessaoTela();
            $window.scrollTo(0, 0);
        }


        /**
         * @ngdoc method
         * @name iniciarTempoSessaoTela
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por cancelar o timeout do estado anterior e iniciar um timeout novo para o estado navegado.
         * 
         */
        function iniciarTempoSessaoTela() {
            $timeout.cancel(_timeoutPromise);

            var tempoSessaoTela;

            if (angular.isDefined(_estadoAtual) &&
                angular.isDefined(_estadoAtual.configuracao) &&
                angular.isDefined(_estadoAtual.configuracao.timeout) &&
                angular.isNumber(_estadoAtual.configuracao.timeout)) {
                tempoSessaoTela = _estadoAtual.configuracao.timeout;
            }
            else {
                var tempoSessaoTelaConfiguracao = sfConfiguracaoDinamica.obterChaveValor("tempoSessaoTela");
                tempoSessaoTela = angular.isDefined(tempoSessaoTelaConfiguracao) && angular.isNumber(tempoSessaoTelaConfiguracao) ? tempoSessaoTelaConfiguracao : appSettings.navegacao.timeoutPadrao;
            }

            _timeoutPromise = $timeout(timeoutSessaoTela, tempoSessaoTela);
        }


        /**
         * @ngdoc method
         * @name timeoutSessaoTela
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por dar raise em um erro para a aplicação quando o timeout da tela for atingido.
         * 
         */
        function timeoutSessaoTela() {
            $rootScope.$broadcast("eventoExpiracaoSessaoEstado", _estadoAtual);
        }


        /**
         * @ngdoc method
         * @name iniciar
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por efetuar a inicialização do navegador, validando as configurações necessárias.
         * 
         * @returns {object} Instância atual do serviço.
         */
        function iniciar() {
            if (!_navegadorIniciado) {
                if (validarDependenciasInicializacao()) {
                    _navegadorIniciado = true;
                    $transitions.onFinish({ to: "**" }, tratamentoNavegacaoEstados);
                }
                else {
                    throw new Error("As configurações necessárias para inicialização do navegador não foram definidas.");
                }
            }
            else {
                throw new Error("O navegador já foi iniciado e, por tanto, não pode ser iniciado novamente.");
            }

            return this;
        }

        /**
         * @ngdoc method
         * @name validarDependenciasInicializacao
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por efetuar a validação das configurações necessárias para inicialização do navegador.
         * 
         * @returns {boolean} True caso as configurações necessárias tenham sido configuradas ou false caso contrário.
         */
        function validarDependenciasInicializacao() {
            return (angular.isDefined(appSettings.configuracao) &&
                angular.isDefined(appSettings.configuracao.caminhoCatalogoDependencias) &&
                angular.isString(appSettings.configuracao.caminhoCatalogoDependencias) &&
                appSettings.configuracao.caminhoCatalogoDependencias !== "" &&
                angular.isDefined(appSettings.configuracao.caminhoArquivosModulos) &&
                angular.isString(appSettings.configuracao.caminhoArquivosModulos) &&
                appSettings.configuracao.caminhoArquivosModulos !== "" &&
                angular.isDefined(appSettings.configuracao.aplicacao) &&
                angular.isString(appSettings.configuracao.aplicacao) &&
                angular.isDefined(appSettings.navegacao) &&
                angular.isDefined(appSettings.navegacao.fluxoInicial) &&
                angular.isString(appSettings.navegacao.fluxoInicial) &&
                appSettings.navegacao.fluxoInicial !== "" &&
                angular.isDefined(appSettings.navegacao.timeoutPadrao) &&
                angular.isNumber(appSettings.navegacao.timeoutPadrao));
        }

        /**
         * @ngdoc method
         * @name iniciarFluxo
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por efetuar a inicialização de um fluxo de navegação carregando suas dependências e navegando para o estado inicial definido para o mesmo.
         * A inicialização de um fluxo sobrepõe o fluxo atual, perdendo-se os históricos para utilização do voltar.
         * 
         * @param {string} idFluxo_ Identificado único do fluxo que será iniciado.
         * @param {object} parametros_ Parâmetros que serão enviados ao próximo estado.
         * @param {object} opcoes_ Opções do ui router para a navegação
         */
        function iniciarFluxo(idFluxo_, parametros_, opcoes_) {
            inicializarFluxo(idFluxo_, parametros_, false, opcoes_);
        }

        /**
         * @ngdoc method
         * @name iniciarFluxo
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por efetuar a inicialização de um fluxo de navegação carregando suas dependências e navegando para o estado inicial definido para o mesmo.
         * 
         * @param {string} idFluxo_ Identificado único do fluxo que será iniciado.
         * @param {object} parametros_ Parâmetros que serão enviados ao próximo estado.
         * @param {boolean} habilitarVoltar_ Indicador se a opção para voltar ao estado anterior estará disponível ou não.
         * @param {object} opcoes_ Opções do ui router para a navegação
         */
        function inicializarFluxo(idFluxo_, parametros_, habilitarVoltar_, opcoes_) {
            if (_navegadorIniciado) {
                if (angular.isDefined(idFluxo_) && angular.isString(idFluxo_) && idFluxo_ !== "") {
                    carregarDependenciasFluxo(idFluxo_, parametros_, habilitarVoltar_, opcoes_);
                }
                else {
                    throw new Error("O id do fluxo não foi informado.");
                }
            }
            else {
                throw new Error("O navegador ainda não foi inicializado.");
            }
        }

        /**
         * @ngdoc object
         * @name navegar
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por efetuar uma navegação enter estados com base na transição definida.
         * 
         * @param {string} transicao_ Transição que definirá para qual estado a aplicação navegará.
         * @param {object} parametros_ Parâmetros que serão enviados ao próximo estado.
         * @param {object} opcoes_ Opções do ui router para a navegação
         */
        function navegar(transicao_, parametros_, opcoes_) {
            if (_navegadorIniciado) {
                var transicaoRecuperada = recuperarTransicao(transicao_);

                if (angular.isDefined(transicaoRecuperada)) {
                    if (angular.isDefined(transicaoRecuperada.estadoDestino) && angular.isString(transicaoRecuperada.estadoDestino) &&
                        transicaoRecuperada.estadoDestino !== "") {
                        var estadoRecuperado = recuperarEstado(_estadoAtual.fluxoAtual, transicaoRecuperada.estadoDestino);

                        if (estadoRecuperado) {
                            var estadoAnterior = angular.copy(_estadoAtual);

                            _estadoAtual = estadoRecuperado;
                            _estadoAtual.estadoAnterior = estadoAnterior;
                            _estadoAtual.fluxoAtual = estadoAnterior.fluxoAtual;

                            _encadeamento = parametros_;

                            if (_estadoAtual.parametros) {
                                $rootScope.parametrosEstadoAtual = _estadoAtual.parametros;
                            }

                            sfLogger.escreverLogNavegacao(_estadoAtual.fluxoAtual.idFluxo(), _estadoAtual.estadoAnterior.id, transicao_, _estadoAtual.fluxoAtual.idFluxo(), transicaoRecuperada.estadoDestino,
                                { classe: "sfNavegador", metodo: "Navegador.navegar" });
                            $state.go(transicaoRecuperada.estadoDestino, parametros_, opcoes_);
                        }
                        else {
                            throw new Error("O estado \"" + transicaoRecuperada.estadoDestino + "\", referente à transição \"" + transicao_ + "\" não foi definido no fluxo \"" + _estadoAtual.fluxoAtual.idFluxo() + "\".");
                        }
                    }
                    else if (angular.isDefined(transicaoRecuperada.fluxo) && angular.isString(transicaoRecuperada.fluxo) &&
                        transicaoRecuperada.fluxo !== "") {
                        _encadeamento = parametros_;

                        var estadoAnteriorLog = "";
                        if (angular.isDefined(_estadoAtual.estadoAnterior)) {
                            estadoAnteriorLog = _estadoAtual.estadoAnterior.id;
                        }

                        sfLogger.escreverLogNavegacao(_estadoAtual.fluxoAtual.idFluxo(), estadoAnteriorLog, transicao_, _estadoAtual.fluxoAtual.idFluxo(), transicaoRecuperada.estadoDestino,
                            { classe: "sfNavegador", metodo: "Navegador.navegar" });
                        inicializarFluxo(transicaoRecuperada.fluxo, parametros_, true, opcoes_);
                    }
                    else {
                        throw new Error("Nenhum destino definido para a transição \"" + transicao_ + "\", referente ao estado \"" + _estadoAtual.id + "\".");
                    }
                }
                else {
                    sfLogger.escreverLogExecucao("A transição \""
                        + transicao_
                        + "\" não foi definida no estado \""
                        + _estadoAtual.id
                        + "\"."
                        , "sfNavegador.navegar", "", "", "Warn");
                }
            }
            else {
                throw new Error("O navegador ainda não foi inicializado.");
            }
        }

        /**
         * @ngdoc method
         * @name encadeamento
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Function que representa o objeto encadeado na última navegação realizada.
         * 
         * @returns {object} Objeto encadeado entre a última navegação.
         */
        function encadeamento() {
            return _encadeamento;
        }

        /**
         * @ngdoc method
         * @name voltar
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por efetuar uma navegação para o estado anterior.
         */
        function voltar() {
            if (_navegadorIniciado) {
                if (_estadoAtual.estadoAnterior) {
                    var estadoOrigem = angular.copy(_estadoAtual);
                    _estadoAtual = _estadoAtual.estadoAnterior;
                    if (_estadoAtual.parametros) {
                        $rootScope.parametrosEstadoAtual = _estadoAtual.parametros;
                    }

                    sfLogger.escreverLogNavegacao(estadoOrigem.fluxoAtual.idFluxo(), estadoOrigem.id, "voltar", _estadoAtual.fluxoAtual.idFluxo(), _estadoAtual.id,
                        { classe: "sfNavegador", metodo: "Navegador.voltar" });
                    $state.go(_estadoAtual.id, undefined);
                }
                else {
                    throw new Error("Nenhuma navegação efetuada para possibilitar o retorno ao estado anterior.");
                }
            }
            else {
                throw new Error("O navegador ainda não foi inicializado.");
            }
        }

        /**
         * @ngdoc method
         * @name recuperarFluxo
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por recuperar a configuração do fluxo informado.
         * 
         * @param  {string} idFluxo_ Identificador do fluxo que será recuperado. 
         * 
         * @returns {object} Configuração do fluxo informado.
         */
        function recuperarFluxo(idFluxo_) {
            var fluxoRecuperado;

            fluxos_.some(function (fluxo) {
                return fluxoRecuperado = ((fluxo.idFluxo() === idFluxo_) ? fluxo : undefined);
            });

            return fluxoRecuperado;
        }

        /**
         * @ngdoc object
         * @name recuperarTransicao
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por recuperar uma transição específica do estado atual.
         * 
         * @param {string} transicao_ Identificador da transição desejada. 
         * 
         * @returns {object} Configuração da transição solicitada.
         */
        function recuperarTransicao(transicao_) {
            var transicaoRecuperada;

            if (angular.isDefined(_estadoAtual.transicoes) && angular.isArray(_estadoAtual.transicoes) && _estadoAtual.transicoes.length > 0) {
                _estadoAtual.transicoes.some(function (transicao) {
                    return transicaoRecuperada = ((transicao.acao === transicao_) ? transicao : undefined);
                });
            }

            return transicaoRecuperada;
        }

        /**
         * @ngdoc method
         * @name iniciarNavegacaoFluxo
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por iniciar a navegação de um fluxo com base no seu estado incial.
         * 
         * @param {string} idFluxo_ Identificado único do fluxo que será iniciado.
         * @param {object} parametros_ Parâmetros que serão enviados ao estado inicial do fluxo.
         * @param {boolean} habilitarVoltar_ Indicador se a opção para voltar ao estado anterior estará disponível ou não.
         * @param {object} opcoes_ Opções do ui router para a navegação 
         */
        function iniciarNavegacaoFluxo(idFluxo_, parametros_, habilitarVoltar_, opcoes_) {
            var fluxoRecuperado = recuperarFluxo(idFluxo_);

            if (angular.isDefined(fluxoRecuperado)) {
                var estadoRecuperado = recuperarEstado(fluxoRecuperado, fluxoRecuperado.estadoInicial());

                var estadoAnterior = angular.copy(_estadoAtual);
                _estadoAtual = estadoRecuperado;
                _estadoAtual.fluxoAtual = fluxoRecuperado;
                _estadoAtual.estadoAnterior = ((habilitarVoltar_) ? estadoAnterior : undefined);
                _encadeamento = parametros_;

                if (_estadoAtual.parametros) {
                    $rootScope.parametrosEstadoAtual = _estadoAtual.parametros;
                }

                var fluxoAtual = angular.isDefined(estadoAnterior) ? estadoAnterior.fluxoAtual.idFluxo() : "undefined";
                var idEstadoAnterior = angular.isDefined(estadoAnterior) ? estadoAnterior.id : "undefined";

                sfLogger.escreverLogNavegacao(fluxoAtual, idEstadoAnterior, "iniciarFluxo", idFluxo_, estadoRecuperado.id,
                    { classe: "sfNavegador", metodo: "Navegador.iniciarNavegacaoFluxo" });

                sfExibicaoMensagem.fecharModal();
                $state.go(fluxoRecuperado.estadoInicial(), parametros_, opcoes_);
            } else {
                throw new Error("O fluxo \"" + idFluxo_ + "\" não foi carregado.");
            }
        }

        /**
         * @ngdoc method
         * @name recuperarEstado
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @description
         * Método responsável por recuperar um estado específico do fluxo informado.
         * 
         * @param {object} fluxo_ Objeto que representa o fluxo de onde o estado será recuperado. 
         * @param {string} idEstado_ Identificador do estado desejada. 
         * 
         * @returns {object} Configuração do estado recuperado.
         */
        function recuperarEstado(fluxo_, idEstado_) {
            var estadoRecuperado;

            fluxo_.estados().some(function (estado) {
                return estadoRecuperado = ((estado.id === idEstado_) ? estado : undefined);
            });

            return estadoRecuperado;
        }

        /**
         * @ngdoc method
         * @name carregarDependenciasFluxo
         * 
         * @methodOf arq-spa-base.navegacao.services:Navegador
         * 
         * @param {string} idFluxo_ Identificado único do fluxo que será iniciado.
         * @param {object} parametros_ Parâmetros que serão enviados ao próximo estado.
         * @param {boolean} habilitarVoltar_ Indicador se a opção para voltar ao estado anterior estará disponível ou não.
         * @param {object} opcoes_ Opções do ui router para a navegação
         * 
         * @description
         * Método responsável por realizar a carga de dependências do fluxo no catálogo e, então, iniciar o mesmo.
         */
        function carregarDependenciasFluxo(idFluxo_, parametros_, habilitarVoltar_, opcoes_) {
            var promisesCatalago = [];
            if (_dependencias === undefined) {
                promisesCatalago.push($http.get(appSettings.configuracao.caminhoCatalogoDependencias));

                if (appSettings.configuracao.caminhoCatalagoInternacionalizacao) {
                    promisesCatalago.push($http.get(appSettings.configuracao.caminhoCatalagoInternacionalizacao));
                }
     
                $q.all(promisesCatalago)
                    .then(sucessoRecuperacaoDependencias)
                    .catch(erroRecuperacaoDependencias);

            } else {
                sucessoRecuperacaoDependencias([_dependencias, _internacionalizacoes]);
            }
            /**
             * @ngdoc method
             * @name sucessoRecuperacaoDependencias
             * 
             * @methodOf arq-spa-base.navegacao.services:Navegador
             * 
             * @description
             * Método responsável por realizar as tratativas em caso de sucesso na recuperação das dependências do fluxo no catálogo.
             * 
             * @param {[JSON, JSON]} retornos_ Array contendo um objeto de configuração do catálogo de dependências e outro de internacionalizações.
             */
            function sucessoRecuperacaoDependencias(retornos_) {
                _dependencias = retornos_[0];
                _internacionalizacoes = retornos_[1];

                if (angular.isDefined(_dependencias.data) && _dependencias.data.length > 0) {
                    var modulos = [];
                    var dicionarios = [];
                    _dependencias.data.forEach(function (registro) {
                        if (registro.idFluxo === idFluxo_) {
                            registro.dependencias.forEach(function (dep) {
                                modulos.push(sfUtilitarios.combinarCaminhos([appSettings.configuracao.caminhoArquivosModulos, (dep + ".js")]));
                                
                                if(_internacionalizacoes && _internacionalizacoes.data[dep]){
                                      dicionarios = dicionarios.concat(_internacionalizacoes.data[dep]);
                                }
                            });
                     
                        }
                    });
                   
                    var promisesModulo = [];
                    if (modulos.length > 0) {
                        promisesModulo.push($ocLazyLoad.load({ serie: true, files: modulos }));
                    }

                    if (dicionarios.length > 0) {
                        promisesModulo.push(sfTradutor.adicionarDicionarios(dicionarios));
                    }

                    $q.all(promisesModulo).then(sucessoCargaDependencias, erroCargaDependencias);
                }
                else {
                    iniciarNavegacaoFluxo(idFluxo_, parametros_, habilitarVoltar_, opcoes_);
                }

                /**
                 * @ngdoc method
                 * @name sucessoCargaDependencias
                 * 
                 * @methodOf arq-spa-base.navegacao.services:Navegador
                 * 
                 * @description
                 * Método responsável por realizar as tratativas em caso de sucesso na carga de dependências pelo <strong>ocLazyLoad</strong>.
                 */
                function sucessoCargaDependencias() {
                    iniciarNavegacaoFluxo(idFluxo_, parametros_, habilitarVoltar_, opcoes_);
                }

                /**
                 * @ngdoc method
                 * @name erroCargaDependencias
                 * 
                 * @methodOf arq-spa-base.navegacao.services:Navegador
                 * 
                 * @description
                 * Método responsável por realizar as tratativas em caso de erro na carga de dependências pelo <strong>ocLazyLoad</strong>.
                 * 
                 * @param {object} erro_ Objeto contendo o erro retornado no processo de carga de dependências.
                 */
                function erroCargaDependencias(erro_) {
                    $log.error("Erro ao tentar carregar as dependências do fluxo " + idFluxo_);
                    throw new Error(erro_);
                }
            }

            /**
             * @ngdoc object
             * @name erroRecuperacaoDependencias
             * 
             * @methodOf arq-spa-base.navegacao.services:Navegador
             * 
             * @description
             * Método responsável por realizar as tratativas em caso de erro ao recuperar o catálogo de dependências.
             * 
             * @param {object} erro_ Objeto referente ao erro retornado no processo de carga de dependências.
             */
            function erroRecuperacaoDependencias(erro_) {
                $log.error("Erro ao tentar carregar as dependências do fluxo " + idFluxo_);
                throw new Error(erro_);
            }
        }
    }
})();
(function () {
    "use strict";
/**
 * @ngdoc overview
 * @name arq-spa-base.personalizacao
 * @description
 * Módulo de personalizacao da arquitetura base que provê as funcionalidades ..
 */
angular.module("arq-spa-base.personalizacao", []);
})();
(function () {
    "use strict";

    angular.module("arq-spa-base.personalizacao").factory("sfPersonalizacao", sfPersonalizacao);

    sfPersonalizacao.$inject = ["$http", "appSettings", "sfUtilitarios", "sfConectorAPI", "sfLogger"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.perifericos.factories:sfPersonalizacao
     * @module arq-spa-base.perifericos
     * 
     * @requires $http
     * @requires appSettings
     * @requires sfUtilitarios
     * 
     * @description
     * Factory resposável por obter Personalizacao
     */
    function sfPersonalizacao($http, appSettings, sfUtilitarios, sfConectorAPI, sfLogger) {

        return {
            obterPersonalizacao: obterPersonalizacao,
            gravarPersonalizacao: gravarPersonalizacao,
            alterarPersonalizacao: alterarPersonalizacao,
            obterPersonalizacaoParams: obterPersonalizacaoParams,
            alterarPersonalizacaoParams: alterarPersonalizacaoParams
        };

        /**
         * @ngdoc method
         * @name obterPersonalizacao
         *
         * @methodOf arq-spa-base.personalizacao.factories:sfPersonalizacao
         *  
         * @description
         * Método responsável por retornar a estrutura personalizada.
         * 
         * @param {string} userLogado Identificador do usuário logado.
         * @param {string} aplicacao Sigla da aplicação a qual a personalização estará associada. Caso não seja informado, será considerada a aplicação configurada.
         * @param {boolean} exibirLoader Indicador se o loader deve ser exibido ou não.
         */
        function obterPersonalizacao(userLogado, aplicacao, exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfPersonalizacao.obterPersonalizacao", "", "", "Info",
                { classe: "sfPersonalizacao", metodo: "obterPersonalizacao" });
            if (angular.isDefined(userLogado) && angular.isString(userLogado) && userLogado !== "") {

                var configHttp = {
                    method: "GET",
                    url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "personalizacao/obter", userLogado]),
                    params: {
                        aplicacao: ((angular.isDefined(aplicacao) && aplicacao !== "") ? aplicacao : appSettings.configuracao.aplicacao)
                    }
                };

                sfLogger.escreverLogExecucao("Término de execução.", "sfPersonalizacao.obterPersonalizacao", "", "", "Info",
                    { classe: "sfPersonalizacao", metodo: "obterPersonalizacao" });
                return sfConectorAPI.executar(configHttp, exibirLoader);
            }
            else {
                throw new Error("O ID do usuário deve ser informado.");
            }
        }

        /**
         * @ngdoc method
         * @name gravarPersonalizacao
         *
         * @methodOf arq-spa-base.personalizacao.factories:sfPersonalizacao
         *  
         * @description
         * Método responsável por gravar a personalização do cliente.
         * 
         * @param {string} userLogado Identificador do usuário logado.
         * @param {string} personalizacoes Parametros recebidos da aplicacao.
         * @param {string} aplicacao Sigla da aplicação a qual a personalização estará associada. Caso não seja informado, será considerada a aplicação configurada.
         * @param {boolean} exibirLoader Indicador se o loader deve ser exibido ou não.
         */
        function gravarPersonalizacao(userLogado, personalizacoes, aplicacao, exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfPersonalizacao.gravarPersonalizacao", "", "", "Info",
                { classe: "sfPersonalizacao", metodo: "gravarPersonalizacao" });
            if (angular.isDefined(userLogado) && angular.isString(userLogado) && userLogado !== "") {
                if (angular.isDefined(personalizacoes) && angular.isObject(personalizacoes)) {

                    var personalizacao = {
                        personalizacoes: personalizacoes,
                        aplicacao: ((angular.isDefined(aplicacao) && aplicacao !== "") ? aplicacao : appSettings.configuracao.aplicacao),
                        codUserCliente: userLogado
                    };

                    var configHttp = {
                        method: "POST",
                        data: personalizacao,
                        url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "personalizacao/criar"])
                    };

                    sfLogger.escreverLogExecucao("Término de execução.", "sfPersonalizacao.gravarPersonalizacao", "", "", "Info",
                        { classe: "sfPersonalizacao", metodo: "gravarPersonalizacao" });
                    return sfConectorAPI.executar(configHttp, exibirLoader);
                }
                else {
                    throw new Error("As personalizações devem ser informados.");
                }
            }
            else {
                throw new Error("O ID do usuário deve ser informado.");
            }
        }

        /**
         * @ngdoc method
         * @name alterarPersonalizacao
         *
         * @methodOf arq-spa-base.personalizacao.factories:sfPersonalizacao
         *  
         * @description
         * Método responsável por alterar a personalização do cliente.
         * 
         * @param {string} idPersonalizacao Identificador da personalizacao.
         * @param {string} parametros Parametros recebidos da aplicacao.
         * @param {boolean} exibirLoader Indicador se o loader deve ser exibido ou não.
         */
        function alterarPersonalizacao(idPersonalizacao, parametros, exibirLoader, aplicacao) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfPersonalizacao.alterarPersonalizacao", "", "", "Info",
                { classe: "sfPersonalizacao", metodo: "alterarPersonalizacao" });
            if (angular.isDefined(idPersonalizacao) && angular.isString(idPersonalizacao) && idPersonalizacao !== "") {
                if (angular.isDefined(parametros) && angular.isObject(parametros)) {
                    var caminhos = [sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "personalizacao/alterar", idPersonalizacao];

                    if (angular.isDefined(aplicacao)) {
                        caminhos.push(aplicacao);
                    }

                    var configHttp = {
                        method: "PUT",
                        data: parametros,
                        url: sfUtilitarios.combinarCaminhos(caminhos)
                    };

                    sfLogger.escreverLogExecucao("Término de execução.", "sfPersonalizacao.alterarPersonalizacao", "", "", "Info",
                        { classe: "sfPersonalizacao", metodo: "alterarPersonalizacao" });
                    return sfConectorAPI.executar(configHttp, exibirLoader);
                }
                else {
                    throw new Error("Os parametros devem ser informados.");
                }
            }
            else {
                throw new Error("O ID do usuário deve ser informado.");
            }
        }

        /**
         * @ngdoc method
         * @name obterPersonalizacaoParams
         *
         * @methodOf arq-spa-base.personalizacao.factories:sfPersonalizacao
         *  
         * @description
         * Método responsável por retornar a estrutura personalizada.
         * 
         * @param {string} userLogado Identificador do usuário logado.
         * @param {string} aplicacao Sigla da aplicação a qual a personalização estará associada. Caso não seja informado, será considerada a aplicação configurada.
         * @param {boolean} exibirLoader Indicador se o loader deve ser exibido ou não.
         */
        function obterPersonalizacaoParams(userLogado, exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfPersonalizacao.obterPersonalizacaoPOST", "", "", "Info",
                { classe: "sfPersonalizacao", metodo: "obterPersonalizacao" });
            if (angular.isDefined(userLogado) && angular.isString(userLogado) && userLogado !== "") {

                var configHttp = {
                    method: "POST",
                    url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "personalizacao/obter"]),
                    data: {
                        params: {
                            codusercliente: userLogado
                        }
                    }
                };

                sfLogger.escreverLogExecucao("Término de execução.", "sfPersonalizacao.obterPersonalizacaoPOST", "", "", "Info",
                    { classe: "sfPersonalizacao", metodo: "obterPersonalizacao" });
                return sfConectorAPI.executar(configHttp, exibirLoader);
            }
            else {
                throw new Error("O ID do usuário deve ser informado.");
            }
        }

        /**
         * @ngdoc method
         * @name alterarPersonalizacaoParams
         *
         * @methodOf arq-spa-base.personalizacao.factories:sfPersonalizacao
         *  
         * @description
         * Método responsável por alterar a personalização do cliente.
         * 
         * @param {string} idPersonalizacao Identificador da personalizacao.
         * @param {string} parametros Parametros recebidos da aplicacao.
         * @param {boolean} exibirLoader Indicador se o loader deve ser exibido ou não.
         */
        function alterarPersonalizacaoParams(idPersonalizacao, parametros, exibirLoader, aplicacao) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfPersonalizacao.alterarPersonalizacao", "", "", "Info",
                { classe: "sfPersonalizacao", metodo: "alterarPersonalizacao" });
            if (angular.isDefined(idPersonalizacao) && angular.isString(idPersonalizacao) && idPersonalizacao !== "") {
                if (angular.isDefined(parametros) && angular.isObject(parametros)) {
                    var caminhos = [sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "personalizacao/alterar"];

                    if (angular.isDefined(aplicacao)) {
                        caminhos.push(aplicacao);
                    }

                    parametros = angular.merge(parametros, { params: { idPersonalizacao: idPersonalizacao }});

                    var configHttp = {
                        method: "PUT",
                        data: parametros,
                        url: sfUtilitarios.combinarCaminhos(caminhos)
                    };

                    sfLogger.escreverLogExecucao("Término de execução.", "sfPersonalizacao.alterarPersonalizacao", "", "", "Info",
                        { classe: "sfPersonalizacao", metodo: "alterarPersonalizacao" });
                    return sfConectorAPI.executar(configHttp, exibirLoader);
                }
                else {
                    throw new Error("Os parametros devem ser informados.");
                }
            }
            else {
                throw new Error("O ID do usuário deve ser informado.");
            }
        }
    }
})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.recursos
     * 
     * @description
     * Módulo de recursos da arquitetura base que provê os recursos necessários para acesso aos recursos disponibilizados..
     */
    angular.module("arq-spa-base.recursos", [
        "pascalprecht.translate",
        "ngSanitize",
        "arq-spa-base.logging",
        "LocalStorageModule"
    ]);
})();
(function () {
    "use strict";

    /**
    * @ngdoc overview
    * @name arq-spa-base.recursos.factories:sfGerenciadorMaquina
    * @module arq-spa-base.recursos
    *
    */
    angular.module("arq-spa-base.recursos").factory("sfGerenciadorMaquina", sfGerenciadorMaquina);

    sfGerenciadorMaquina.$inject = ["appSettings", "sfUtilitarios", "sfConectorAPI", "$window", "sfLogger"];

    /**
     * @ngdoc overview
     * @name * @name arq-spa-base.recursos:sfGerenciadorMaquina
     * @module arq-spa-base.recursos
     * 
     * @requires $http
     * @requires appSettings
     * @requires sfUtilitarios
     * 
     * @description
     * Factory responsável 
     */
    function sfGerenciadorMaquina(appSettings, sfUtilitarios, sfConectorAPI, $window, sfLogger) {

        return {
            obterIP: obterIP
        };

        /**
         * @ngdoc method
         * @name obterIP
         *
         * @methodOf * @name arq-spa-base.recursos:sfGerenciadorMaquina
         *  
         * @description
         * Método 
         * @param {boolean} exibirLoader indica se o loader deve ser exibido ou não.
         * @param {String} mensagem mensagem que será exibida quando o loader está visível.
         */
        function obterIP(exibirLoader, mensagem) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfGerenciadorMaquina.obterIP", "", "", "Info");

            var configHttp = {
                method: "GET",
                url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "obter-ip"])
            };

            sfLogger.escreverLogExecucao("Término de execução.", "sfGerenciadorMaquina.obterIP", "", "", "Info");
            return sfConectorAPI.executar(configHttp, exibirLoader, mensagem);
        }
    }

})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.factories:sfAnalyticsScriptLoader
     * @module arq-spa-base
     *
     * @description
     * 
     */
    angular.module("arq-spa-base.recursos").factory("sfAnalyticsScriptLoader", sfAnalyticsScriptLoader);

    sfAnalyticsScriptLoader.$inject = ["$window", "$q", "appSettings"];

    /**
     * @ngdoc overview
     * @name sfAnalyticsScriptLoader
     *
     * @methodOf arq-spa-base.factories:sfAnalyticsScriptLoader
     * 
     * @requires $window
     * @requires $q
     * 
     * @description
     * Factory resposável por carregar dinamiacamente o script do maps.
     */
    function sfAnalyticsScriptLoader($window, $q, appSettings) {
        var deferred = $q.defer();

        /**
         * @ngdoc overview
         * @name loadScript
         *
         * @methodOf arq-spa-base.factories:sfAnalyticsScriptLoader
         * 
         * 
         * @description
         * Função responsável por criar o elemento do objeto script e carregar a API do Maps.
         */
        function loadScript(caminho) {
            var script = document.createElement("script");

            // eslint-disable-next-line
            script.src = caminho;
            script.async = "async";
            script.defer = "defer";

            document.body.appendChild(script);
        }

        if (appSettings.configuracao.urlScriptGoogleAnalytics &&
            appSettings.configuracao.caminhoGoogleAnalyticsConfig) {
            loadScript(appSettings.configuracao.urlScriptGoogleAnalytics);
            loadScript(appSettings.configuracao.caminhoGoogleAnalyticsConfig);
        } else {
            deferred.reject();
        }

        return deferred.promise;
    }

})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.recurso.factories:sfConfiguracaoDinamica
     * @module arq-spa-base.recurso
     *
     * @description
     * 
     */
    angular.module("arq-spa-base.recursos").factory("sfConfiguracaoDinamica", sfConfiguracaoDinamica);

    sfConfiguracaoDinamica.$inject = ["appSettings", "sfConectorAPI", "sfUtilitarios", "$httpParamSerializer", "$q", "sfContexto", "sfLogger"];

    /**
     * @ngdoc overview
     * @name sfConfiguracaoDinamica
     *
     * @methodOf arq-spa-base.recurso.factories:sfConfiguracaoDinamica
     * 
     * @requires appSettings
     * @requires sfConectorAPI
     * @requires $q
     * 
     * @description
     * Factory resposável por recuperar as configurações dinâmicas
     */
    function sfConfiguracaoDinamica(appSettings, sfConectorAPI, sfUtilitarios, $httpParamSerializer, $q, sfContexto, sfLogger) {
        return {
            obterTodasConfiguracoes: obterTodasConfiguracoes,
            obterConfiguracaoEspecifica: obterConfiguracaoEspecifica,
            obterChaveValor: obterChaveValor,
            obterConfiguracoesLog: obterConfiguracoesLog
        };

        /**
         * @ngdoc overview
         * @name obterTodasConfiguracoes
         *
         * @methodOf arq-spa-base.recurso.factories:sfConfiguracaoDinamica
         *
         * @description
         * Método responsável por recuperar as configurações iniciais dinâmicas.
         */
        function obterTodasConfiguracoes() {
            sfLogger.escreverLogExecucao("Início de execução.", "sfConfiguracaoDinamica.obterTodasConfiguracoes", "", "", "Info",
                { classe: "sfConfiguracaoDinamica", metodo: "obterTodasConfiguracoes" });
            var deferred = $q.defer();

            var configHttp = {
                method: "GET",
                url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "configuracoes"])
            };

            sfConectorAPI.executar(configHttp, false).then(sucessoObterConfiguracao).catch(erroObterConfiguracao);

            return deferred.promise;

            /**
             * @ngdoc method
             * @name erroObterConfiguracao
             *
             * @methodOf arq-spa-base.recursos.factories:sfConfiguracaoDinamica
             *  
             * @description
             * Método responsável por informar o erro durante a obtenção da configuração específica sem dna.
             * 
             */
            function erroObterConfiguracao(msg) {
                sfLogger.escreverLogExecucao("Término de execução.", "sfConfiguracaoDinamica.obterTodasConfiguracoes", "", "", "Info",
                    { classe: "sfConfiguracaoDinamica", metodo: "obterTodasConfiguracoes.erroObterConfiguracao" });
                deferred.reject(msg);
            }

            /**
             * @ngdoc method
             * @name sucessoObterConfiguracao
             *
             * @methodOf arq-spa-base.recursos.factories:sfConfiguracaoDinamica
             *  
             * @description
             * Método responsável por interpretar o sucesso da obtenção de configuração específica
             * 
             */
            function sucessoObterConfiguracao(response) {
                sfContexto.definirValorContextoSessao("configuracoes", response.data);
                sfLogger.escreverLogExecucao("Término de execução.", "sfConfiguracaoDinamica.obterTodasConfiguracoes", "", "", "Info",
                    { classe: "sfConfiguracaoDinamica", metodo: "obterTodasConfiguracoes.sucessoObterConfiguracao" });
                deferred.resolve(response);
            }
        }

        /**
         * @ngdoc overview
         * @name obterConfiguracaoEspecifica
         *
         * @methodOf arq-spa-base.recurso.factories:sfConfiguracaoDinamica
         *
         * @description
         * Método responsável por recuperar a configuração dinâmica dos argumentos preenchidos
         * 
         * @param {string} nomeConfiguracao - Texto para consulta de configuração, Ex: LogExecucao (Opcional) 
         * @param {string} plataforma       - Texto para consulta de uma plataforma, Ex: iOS e Android (Opcional)
         * @param {bool} exibirLoader       - Trata se deve exibir ou não o loader ao processar requisição (Opcional) 
         */
        function obterConfiguracaoEspecifica(nomeConfiguracao, plataforma, exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfConfiguracaoDinamica.obterConfiguracaoEspecifica", "", "", "Info",
                { classe: "sfConfiguracaoDinamica", metodo: "obterConfiguracaoEspecifica" });

            nomeConfiguracao = nomeConfiguracao || "";
            plataforma = plataforma || "";

            var params = {
                nomeConfiguracao: nomeConfiguracao,
                plataforma: plataforma
            };

            if (params.plataforma === "") {
                delete params.plataforma;
            }
            if (params.nomeConfiguracao === "") {
                delete params.nomeConfiguracao;
            }

            var configHttp = {
                method: "GET",
                url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "configuracoes"]),
                params: params
            };

            sfLogger.escreverLogExecucao("Término de execução.", "sfConfiguracaoDinamica.obterConfiguracaoEspecifica", "", "", "Info",
                { classe: "sfConfiguracaoDinamica", metodo: "obterConfiguracaoEspecifica" });
            return sfConectorAPI.executar(configHttp, exibirLoader);
        }

        /**
         * @ngdoc overview
         * @name obterChaveValor
         *
         * @methodOf arq-spa-base.recurso.factories:sfConfiguracaoDinamica
         *
         * @description
         * Método responsável por recuperar o valor para chave parametrizada
         * 
         * @param {string} nomeConfiguracao     - Texto para consulta de configuração, Ex: log, principal (obrigatório) 
         * @param {string} chaveSecundaria      - Texto para consulta de uma plataforma, Ex: info, warning (Opcional)
         * @param {bool} configuracaoEspecifica - Nova configuracao especifica para buscar (Opcional)  
         * 
         */
        function obterChaveValor(nomeConfiguracao, chaveSecundaria, configuracaoEspecifica) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfConfiguracaoDinamica.obterChaveValor", "", "", "Info",
                { classe: "sfConfiguracaoDinamica", metodo: "obterChaveValor" });
            var configuracoes = configuracaoEspecifica || sfContexto.obterValorContextoSessao("configuracoes");

            var valor = undefined;
            if (angular.isDefined(configuracoes) &&
                angular.isArray(configuracoes) &&
                configuracoes.length > 0) {

                var configuracao;
                var existeConfiguracao = configuracoes.some(function (itemConfiguracao) {
                    if (itemConfiguracao && itemConfiguracao.nomeConfiguracao === nomeConfiguracao) {
                        configuracao = itemConfiguracao;
                        return true;
                    } return false;
                });

                if (existeConfiguracao) {
                    if (angular.isDefined(chaveSecundaria) && chaveSecundaria !== "") {
                        configuracao.configuracoes.some(function (item) {
                            if (angular.isDefined(item) && item.chave == chaveSecundaria) {
                                return valor = item.valor;
                            }
                            return false;
                        });
                    } else {
                        valor = configuracao;
                    }
                }
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfConfiguracaoDinamica.obterChaveValor", "", "", "Info",
                { classe: "sfConfiguracaoDinamica", metodo: "obterChaveValor" });
            return valor;
        }

        /**
         * @ngdoc overview
         * @name obterConfiguracoesLog
         *
         * @methodOf arq-spa-base.recurso.factories:sfConfiguracaoDinamica
         *
         * @description
         * Método responsável por recuperar as configurações iniciais dinâmicas.
         */
        function obterConfiguracoesLog() {
            sfLogger.escreverLogExecucao("Início de execução.", "sfConfiguracaoDinamica.obterTodasConfiguracoes", "", "", "Info",
                { classe: "sfConfiguracaoDinamica", metodo: "obterConfiguracoesLog" });
            var deferred = $q.defer();

            var configHttp = {
                method: "GET",
                log: true,
                url: sfUtilitarios.combinarCaminhos([appSettings.comunicacao.urlLog, "configuracoes"])
            };

            sfConectorAPI.executar(configHttp, false).then(sucessoObterConfiguracaoLog).catch(erroObterConfiguracaoLog);

            return deferred.promise;

            /**
             * @ngdoc method
             * @name erroObterConfiguracaoLog
             *
             * @methodOf arq-spa-base.recursos.factories:sfConfiguracaoDinamica
             *  
             * @description
             * Método responsável por informar o erro durante a obtenção da configuração específica sem dna.
             * 
             */
            function erroObterConfiguracaoLog(msg) {
                sfLogger.escreverLogExecucao("Término de execução.", "sfConfiguracaoDinamica.obterTodasConfiguracoes", "", "", "Info",
                    { classe: "sfConfiguracaoDinamica", metodo: "obterConfiguracoesLog.erroObterConfiguracaoLog" });
                deferred.reject(msg);
            }

            /**
             * @ngdoc method
             * @name sucessoObterConfiguracaoLog
             *
             * @methodOf arq-spa-base.recursos.factories:sfConfiguracaoDinamica
             *  
             * @description
             * Método responsável por interpretar o sucesso da obtenção de configuração específica
             * 
             */
            function sucessoObterConfiguracaoLog(response) {
                var logarWarning = obterChaveValor("log", "warning", response.data);
                var logarInfo = obterChaveValor("log", "info", response.data);

                logarWarning = angular.isDefined(logarWarning) ? (logarWarning === "true") : logarWarning;
                logarInfo = angular.isDefined(logarInfo) ? (logarInfo === "true") : logarInfo;

                sfContexto.definirValorContextoSessao("logWarning", logarWarning);
                sfContexto.definirValorContextoSessao("logInfo", logarInfo);
                sfLogger.escreverLogExecucao("Término de execução.", "sfConfiguracaoDinamica.obterTodasConfiguracoes", "", "", "Info",
                    { classe: "sfConfiguracaoDinamica", metodo: "obterConfiguracoesLog.sucessoObterConfiguracaoLog" });
                deferred.resolve(response);
            }
        }
    }

})();
(function () {
    "use strict";

    /**
     * @ngdoc service
     * @name arq-spa-base.recursos.services:Contexto
     * 
     * @module arq-spa-base.recursos
     * 
     * @description
     * Serviço responsável por prover os recursos de contextos da aplicação.
     */
    angular.module("arq-spa-base.recursos").factory("sfContexto", sfContexto);

    /**
    * @ngdoc overview
    * @name sfContexto
    * 
    * @methodOf arq-spa-base.recursos.services:Contexto
    * 
    * @description
    * Método responsável por iniciar a factory do sfContexto.
    */
    function sfContexto() {
        var contextosBase = {};
        var contextoAtual;
        var contextoIniciado = false;
        var contextoSessao = {
            "token": "",
            "IdSessao": "",
            "chaveSimetrica": "",
            "configuracoes": "",
            "logWarning": "",
            "logInfo": "",
            "idioma": "pt-BR",
            "handshakeFinalizado": "",
            "PortaUrlContainer": "",
            "erroDistribuicao": "",
            "versaoAplicacao": "",
            "versaoContainer": ""
        };

        return {
            contextoIniciado: statusInicializacaoContexto,
            iniciar: iniciar,
            verificarExistenciaContextoSessao: verificarExistenciaContextoSessao,
            obterValorContextoSessao: obterValorContextoSessao,
            definirValorContextoSessao: definirValorContextoSessao,
            verificarExistenciaContextoTrabalho: verificarExistenciaContextoTrabalho,
            obterValorContextoTrabalho: obterValorContextoTrabalho,
            definirValorContextoTrabalho: definirValorContextoTrabalho,
            reiniciarContextoTrabalho: reiniciarContextoTrabalho
        };

        /**
         * @ngdoc object
         * @name contextoIniciado
         * 
         * @methodOf arq-spa-base.recursos.services:Contexto
         * 
         * @description
         * Método responsável por indicar se o sfContexto já foi incializado ou não.
         * 
         * @returns {boolean} True caso o sfContexto já tenha sido inciado ou false caso contrário. 
         */
        function statusInicializacaoContexto() {
            return contextoIniciado;
        }

        /**
         * @ngdoc method
         * @name iniciar
         * 
         * @methodOf arq-spa-base.recursos.services:Contexto
         * 
         * @description
         * Método responsável por inciar os contextos da aplicação com base no arquivo de configuração definido durante a configuração do provider.
         * 
         * @param {object} configuracaoContexto_ Objeto que possui as configurações do sfContexto.
         */
        function iniciar(configuracaoContexto_) {
            if (!contextoIniciado) {
                if (configuracaoContexto_) {

                    contextosBase.sessao = contextoSessao;

                    if (configuracaoContexto_.trabalho) {
                        contextosBase.trabalho = configuracaoContexto_.trabalho;
                    }
                    else {
                        throw new Error("Não foram encontradas definições de sfContexto de trabalho.");
                    }

                    contextoAtual = angular.copy(contextosBase);
                    contextoIniciado = true;
                }
                else {
                    throw new Error("Não foram definidas as configurações do sfContexto.");
                }
            }
            else {
                throw new Error("O sfContexto já foi inicializado e, por tanto, não pode ser iniciado novamente.");
            }
        }

        /**
         * @ngdoc method
         * @name verificarExistenciaContextoSessao
         * 
         * @methodOf arq-spa-base.recursos.services:Contexto
         * 
         * @description
         * Método responsável por verificar a existência de uma chave específica no sfContexto de sessão.
         * 
         * @param {string} chaveContexto_ Chave de sfContexto que será verificada.
         * 
         * @returns {boolean} True caso a chave de sfContexto informada exista ou false caso contrário.
         */
        function verificarExistenciaContextoSessao(chaveContexto_) {
            return contextoSessao.hasOwnProperty(chaveContexto_);
        }

        /**
         * @ngdoc method
         * @name obterValorContextoSessao
         * 
         * @methodOf arq-spa-base.recursos.services:Contexto
         * 
         * @description
         * Método responsável por obter um valor específico do sfContexto de sessão.
         * 
         * @param {string} chaveContexto_ Chave de sfContexto cujo valor será obtido.
         * 
         * @returns {objeto} Objeto associado à chave de sfContexto definido.
         */
        function obterValorContextoSessao(chaveContexto_) {
            if (verificarExistenciaContextoSessao(chaveContexto_)) {
                return angular.copy(contextoSessao[chaveContexto_]);
            }
            else {
                throw new Error("A chave '" + chaveContexto_ + "' não existe no sfContexto de sessão.");
            }
        }

        /**
         * @ngdoc object
         * @name definirValorContextoSessão
         * 
         * @methodOf arq-spa-base.recursos.services:Contexto
         * 
         * @description
         * Método responsável por definir um valor específico do sfContexto de sessão.
         * 
         * @param {string} chaveContexto_ Chave de sfContexto cujo valor será definido.
         * @param {object} valor_ Valor que será atribuído à chave de sfContexto.
         * 
         * @returns {objeto} Objeto definido no sfContexto de sessão.
         */
        function definirValorContextoSessao(chaveContexto_, valor_) {
            if (verificarExistenciaContextoSessao(chaveContexto_)) {
                return contextoSessao[chaveContexto_] = valor_;
            }
            else {
                throw new Error("A chave '" + chaveContexto_ + "' não existe no sfContexto de sessão.");
            }
        }

        /**
         * @ngdoc method
         * @name verificarExistenciaContextoTrabalho
         * 
         * @methodOf arq-spa-base.recursos.services:Contexto
         * 
         * @description
         * Método responsável por verificar a existência de uma chave específica no sfContexto de trabalho.
         * 
         * @param {string} chaveContexto_ Chave de sfContexto que será verificada.
         * 
         * @returns {boolean} True caso a chave de sfContexto informada exista ou false caso contrário.
         */
        function verificarExistenciaContextoTrabalho(chaveContexto_) {
            return contextoAtual.trabalho.hasOwnProperty(chaveContexto_);
        }

        /**
         * @ngdoc object
         * @name obterValorContextoTrabalho
         * 
         * @methodOf arq-spa-base.recursos.services:Contexto
         * 
         * @description
         * Método responsável por obter um valor específico do sfContexto de trabalho.
         * 
         * @param {string} chaveContexto_ Chave de sfContexto cujo valor será obtido.
         * 
         * @returns {objeto} Objeto associado à chave de sfContexto definido ou undefined caso a chave informada não exista no sfContexto.
         */
        function obterValorContextoTrabalho(chaveContexto_) {
            if (verificarExistenciaContextoTrabalho(chaveContexto_)) {
                return angular.copy(contextoAtual.trabalho[chaveContexto_]);
            }
            else {
                throw new Error("A chave '" + chaveContexto_ + "' não existe no sfContexto de trabalho.");
            }
        }

        /**
         * @ngdoc object
         * @name definirValorContextoTrabalho
         * 
         * @methodOf arq-spa-base.recursos.services:Contexto
         * 
         * @description
         * Método responsável por definir um valor específico do sfContexto de trabalho.
         * 
         * @param {string} chaveContexto_ Chave de sfContexto cujo valor será definido.
         * @param {object} valor_ Valor que será atribuído à chave de sfContexto.
         * 
         * @returns {objeto} Objeto definido no sfContexto de trabalho.
         */
        function definirValorContextoTrabalho(chaveContexto_, valor_) {
            if (verificarExistenciaContextoTrabalho(chaveContexto_)) {
                return contextoAtual.trabalho[chaveContexto_] = valor_;
            }
            else {
                throw new Error("A chave '" + chaveContexto_ + "' não existe no sfContexto de trabalho.");
            }
        }

        /**
         * @ngdoc object
         * @name reiniciarSessaoTrabalho
         * 
         * @methodOf arq-spa-base.recursos.services:Contexto
         * 
         * @description
         * Método responsável por redefinir as informações da sessão de trabalho para seu estado logo após a inicialização do sfContexto.
         */
        function reiniciarContextoTrabalho() {
            contextoAtual.trabalho = angular.copy(contextosBase.trabalho);
        }
    }
})();
(function () {
    "use strict";

    angular.module("arq-spa-base.recursos").factory("sfEmail", sfEmail);

    sfEmail.$inject = ["$http", "appSettings", "sfUtilitarios", "sfConectorAPI", "sfLogger"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.recursos.factories:sfEmail
     * @module arq-spa-base.recursos
     * 
     * @requires $http
     * @requires appSettings
     * @requires sfUtilitarios
     * @requires sfConectorAPI
     * @requires sfLogger
     * 
     * @description
     * Factory resposável por realizar a chamada à api de email
     */
    function sfEmail($http, appSettings, sfUtilitarios, sfConectorAPI, sfLogger) {

        return {
            enviar: enviar
        };

        /**
         * @ngdoc method
         * @name obterPersonalizacao
         *
         * @methodOf arq-spa-base.personalizacao.factories:sfPersonalizacao
         *  
         * @description
         * Método responsável por retornar a estrutura personalizada.
         * 
         * @param {string} userLogado Identificador do usuário logado.
         * @param {boolean} exibirLoader Indicador se o loader deve ser exibido ou não.
         */
        function enviar(parametros, exibirLoader, mensagem) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfEmail.enviar", "", "", "Info",
                { classe: "sfEmail", metodo: "enviar" });

            var configHttp = {
                method: "POST",
                url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "envia-email"]),
                data: parametros
            };
            
            sfLogger.escreverLogExecucao("Término de execução.", "sfEmail.enviar", "", "", "Info",
                { classe: "sfEmail", metodo: "enviar" });

            return sfConectorAPI.executar(configHttp, exibirLoader, mensagem);
        }

    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.factories:sfMapsScriptLoader
     * @module arq-spa-base
     *
     * @description
     * 
     */
    angular.module("arq-spa-base.recursos").factory("sfMapsScriptLoader", sfMapsScriptLoader);

    sfMapsScriptLoader.$inject = ["$window", "$q", "appSettings"];

    /**
     * @ngdoc overview
     * @name sfMapsScriptLoader
     *
     * @methodOf arq-spa-base.factories:sfMapsScriptLoader
     * 
     * @requires $window
     * @requires $q
     * 
     * @description
     * Factory resposável por carregar dinamiacamente o script do maps.
     */
    function sfMapsScriptLoader($window, $q, appSettings) {
        var deferred = $q.defer();

        /**
         * @ngdoc overview
         * @name loadScript
         *
         * @methodOf arq-spa-base.factories:sfMapsScriptLoader
         * 
         * 
         * @description
         * Função responsável por criar o elemento do objeto script e carregar a API do Maps.
         */
        function loadScript() {
            var script = document.createElement("script");

            if (appSettings.configuracao.urlScriptGoogleMaps) {
                // eslint-disable-next-line
                script.src = appSettings.configuracao.urlScriptGoogleMaps;
            } else {
                deferred.reject();
            }

            document.body.appendChild(script);
        }

        // Script loaded callback, send resolve
        $window["initMap"] = function () {
            deferred.resolve();
        };

        loadScript();

        return deferred.promise;
    }

})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.recursos.factories:sfMemorizador
     * 
     * @module arq-spa-base.recursos
     * 
     * @description
     * Serviço responsável pela interface de armazenamento local de informações
     */
    angular.module("arq-spa-base.recursos").factory("sfMemorizador", sfMemorizador);

    sfMemorizador.$inject = ["localStorageService", "$injector"];

    /**
     * @ngdoc object
     * @name sfMemorizador
     *
     * @methodOf arq-spa-base.recursos
     *  
     * @param {object} localStorageService_ Instância do service do Local Storage
     * 
     * @description
     * Método responsável por iniciar a factory "sfMemorizador"
     */
    function sfMemorizador(localStorageService_, $injector) {

        return {
            definir: definir,
            obter: obter,
            removerChave: removerChave
        };

        /**
         * @ngdoc method
         * @name definir
         *
         * @methodOf arq-spa-base.recursos.factories:sfMemorizador
         * 
         * @param {string} chave_ Chave em que deseja-se armazenar valor no memorizador
         * @param {string} valor_ Valor que deseja-se armazenar no memorizador
         *  
         * @description
         * Método responsável por definir informação em variável de memorizador
         * 
         */
        function definir(chave_, valor_) {
            if (angular.isDefined(chave_) && angular.isString(chave_) && chave_ !== "") {
                if (angular.isDefined(valor_)) {
                    if (verificarMemorizadorEspecifico(chave_)) {
                        recuperarMemorizadorEspecifico().definir(chave_, valor_);
                    }

                    localStorageService_.set(chave_, valor_);
                }
                else {
                    throw new Error("Não foi definida nenhuma informação para armazenamento no memorizador.");
                }

            } else {
                throw new Error("Não foi definida nenhuma informação para armazenamento no memorizador.");
            }
        }

        /**
         * @ngdoc method
         * @name obter
         *
         * @methodOf arq-spa-base.recursos.factories:sfMemorizador
         * 
         * @param {string} chave_ Chave cujo valor deseja-se recuperar do memorizador.
         *  
         * @description
         * Método responsável por obter valor de variável do memorizador
         */
        function obter(chave_) {
            if (angular.isDefined(chave_) && angular.isString(chave_) && chave_ != "") {
                return localStorageService_.get(chave_);
            }
            else {
                throw new Error("Não foi possível obter informações da variável local.");
            }
        }

        /**
         * @ngdoc method
         * @name remover
         *
         * @methodOf arq-spa-base.recursos.factories:sfMemorizador
         *  
         * @description
         * Método responsável por excluir a chave de armazenamento solicitada.
         * 
         * @param {string} chave_ Chave que deseja-se excluir do memorizador.
         */
        function removerChave(chave_) {
            if (angular.isDefined(chave_) && angular.isString(chave_) && chave_ != "") {
                if (verificarMemorizadorEspecifico(chave_)) {
                    recuperarMemorizadorEspecifico().removerChave(chave_);
                }

                localStorageService_.remove(chave_);
            }
            else {
                throw new Error("Não foi possível excluir a chave do memorizador.");
            }
        }

        /**
         * @ngdoc object
         * @name verificarMemorizadorEspecifico
         *
         * @methodOf arq-spa-base.recursos
         * 
         * @description
         * Método responsável por verificar se deve utilizar o device storage
         */
        function verificarMemorizadorEspecifico(chave) {
            return chave !== "represaLog" &&
                $injector.has("sfMemorizadorEspecifico");
        }

        /**
         * @ngdoc object
         * @name recuperarMemorizadorEspecifico
         *
         * @methodOf arq-spa-base.recursos
         * 
         * @description
         * Método responsável por recuperar o modulo do memorizador especifico
         */
        function recuperarMemorizadorEspecifico() {
            return $injector.get("sfMemorizadorEspecifico");
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.teclaAtalho.directives:sfTeclaAtalhoElemento
     * @module arq-spa-base.teclaAtalho
     *
     * @description
     * 
     */
    angular.module("arq-spa-base.recursos").directive("sfTeclaAtalhoElemento", sfTeclaAtalhoElemento);

    sfTeclaAtalhoElemento.$inject = ["$compile", "sfUtilitarios"];

    /**
     * @ngdoc overview
     * @name sfTeclaAtalhoElemento
     *
     * @methodOf arq-spa-base.teclaAtalho.directives:sfTeclaAtalhoElemento
     *
     * @description
     * Diretiva que injeta no elemento parametrizado no evento keydown
     */
    function sfTeclaAtalhoElemento($compile, sfUtilitarios) {
        return {
            restrict: "A",
            scope: false,
            compile: compile
        };

        /**
         * @ngdoc method
         * @name compile
         *
         * @methodOf arq-spa-base.teclaAtalho.directives:sfTeclaAtalhoElemento
         *
         * @description
         * Evento executado ao compilar o html
         */
        function compile() {
            return function (scope, elemento, atributos) {
                elemento.removeAttr("sf-tecla-atalho-elemento");

                var expression = "";
                var atributoFormatado = formatarAtributoAtalho(atributos.sfTeclaAtalhoElemento);
                var atalhos = atributoFormatado.split(",");

                angular.forEach(atalhos, function (configuracao, index) {

                    expression = expression + "(";
                    var chaveFuncao = configuracao.split(":");

                    if (chaveFuncao.length === 2) {

                        var chave = chaveFuncao[0];
                        var funcao = chaveFuncao[1].replace(/ /g, "");
                        var listaChave = chave.split("+");

                        angular.forEach(listaChave, function (modifierKey) {
                            if (modifierKey.indexOf("ctrl") >= 0) {
                                expression = expression + "$event.ctrlKey && ";
                            }
                            if (modifierKey.indexOf("alt") >= 0) {
                                expression = expression + "$event.altKey && ";
                            }
                            if (modifierKey.indexOf("shift") >= 0) {
                                expression = expression + "$event.shiftKey && ";
                            }
                        });

                        var codigo = listaChave[listaChave.length - 1];

                        expression = expression + "$event.which === " + sfUtilitarios.recuperarKeycode(codigo.trim());
                        expression = expression + " && " + funcao;
                        expression = expression + ")";
                        if (index !== atalhos.length - 1) {
                            expression = expression + " || ";
                        }
                    } else {
                        throw new Error("Atalho incorretamente formatado: " + configuracao);
                    }
                });
                
                elemento.attr("ng-keydown", expression);
                $compile(elemento)(scope);
            };
        }

        /**
         * @ngdoc method
         * @name formatarAtributoAtalho
         *
         * @methodOf arq-spa-base.teclaAtalho.directives:sfTeclaAtalhoElemento
         * @requires atributo 
         *         
         * @description
         * Método responsável por formatar corretamente as valor da diretiva
         */
        function formatarAtributoAtalho(atributo) {
            if (atributo.indexOf("{") === 0 && atributo.match("}" + "$") == "}") {
                atributo = atributo.substr(1);
                return atributo = atributo.substr(0, atributo.length - 1);
            } else {
                return atributo;
            }
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.recursos.factories:sfTeclaAtalho
     * @module arq-spa-base.recursos
     *
     * @description
     * Modulo recursos
     */
    angular.module("arq-spa-base.recursos").factory("sfTeclaAtalho", sfTeclaAtalho);

    sfTeclaAtalho.$inject = ["$window", "sfLogger"];

    /**
     * @ngdoc overview
     * @name sfTeclaAtalho
     *
     * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalho
     *
     * @description
     * Inicia o serviço
     */
    function sfTeclaAtalho($window, sfLogger) {
        var dicionarioTeclas = [];

        return {
            cadastrarTecla: cadastrarTecla,
            descadastrarTecla: descadastrarTecla,
            recuperarTeclasCadastradas: recuperarTeclasCadastradas,
            descadastrarTeclasEscopo: descadastrarTeclasEscopo
        };

        /**
         * @ngdoc overview
         * @name atalhoHandler
         *
         * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalhoGlobal
         *
         * @description
         * Método disparado ao pressionar uma tecla de atalho
         */
        function atalhoHandler(evento) {
            var dicionarioFiltrado = dicionarioTeclas.filter(function (atalho) {
                return (atalho.tecla === evento.keyCode &&
                    atalho.modificadores.ctrl === evento.ctrlKey &&
                    atalho.modificadores.shift === evento.shiftKey &&
                    atalho.modificadores.alt === evento.altKey);
            });

            if (dicionarioFiltrado.length > 0) {
                var configFuncao;
                if (dicionarioFiltrado.length > 1) {
                    dicionarioFiltrado.some(function (atalho) {
                        if (atalho.escopoAtalho === "tela") {
                            configFuncao = {
                                funcao: atalho.funcao,
                                propagacao: atalho.propagacao,
                                escopoAtalho: atalho.escopoAtalho
                            };
                        }
                    });
                } else {
                    configFuncao = dicionarioFiltrado[0];
                }

                configFuncao.funcao();
                if (configFuncao.propagacao === true) {
                    evento.preventDefault();
                }
            }
        }

        /**
         * @ngdoc overview
         * @name cadastrarTecla
         *
         * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalho
         *
         * @description
         * Método responsável por cadastrar tecla
         */
        function cadastrarTecla(atalho) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfTeclaAtalho.cadastrarTecla", "", "", "Info",
                { classe: "sfTeclaAtalho", metodo: "cadastrarTecla" });

            var deveSubscreverAtalho = dicionarioTeclas.some(function (dicionarioAtalho) {
                return (dicionarioAtalho.tecla === atalho.tecla &&
                    dicionarioAtalho.escopoAtalho === atalho.escopoAtalho);
            });

            if (deveSubscreverAtalho) {
                descadastrarTecla(atalho);
            }

            if (dicionarioTeclas.length === 0) {
                angular.element($window).on("keydown", atalhoHandler);
            }

            atalho.propagacao = (angular.isUndefined(atalho.propagacao)) ? true : atalho.propagacao;

            if (angular.isDefined(atalho.modificadores) &&
                angular.isObject(atalho.modificadores)) {
                var ctrl, shift, alt;
                ctrl = (angular.isDefined(atalho.modificadores.ctrl) && (atalho.modificadores.ctrl == true || atalho.modificadores.ctrl == "true"));
                shift = (angular.isDefined(atalho.modificadores.shift) && (atalho.modificadores.shift == true || atalho.modificadores.shift == "true"));
                alt = (angular.isDefined(atalho.modificadores.alt) && (atalho.modificadores.alt == true || atalho.modificadores.alt == "true"));
                atalho.modificadores = {
                    ctrl: ctrl,
                    shift: shift,
                    alt: alt
                };
            } else {
                atalho.modificadores = {
                    ctrl: false,
                    shift: false,
                    alt: false
                };
            }

            dicionarioTeclas.push(atalho);

            sfLogger.escreverLogExecucao("Término de execução.", "sfTeclaAtalho.cadastrarTecla", "", "", "Info",
                { classe: "sfTeclaAtalho", metodo: "cadastrarTecla" });
        }

        /**
         * @ngdoc overview
         * @name cadastrarTecla
         *
         * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalho
         *
         * @description
         * Método responsável por descadastrar tecla
         */
        function descadastrarTecla(atalho) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfTeclaAtalho.descadastrarTecla", "", "", "Info",
                { classe: "sfTeclaAtalho", metodo: "descadastrarTecla" });

            dicionarioTeclas = dicionarioTeclas.filter(function (atalhoDicionario) {
                return !(atalhoDicionario.tecla === atalho.tecla &&
                    atalhoDicionario.escopoAtalho === atalho.escopoAtalho);
            });

            if (dicionarioTeclas.length === 0) {
                angular.element($window).off("keydown");
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfTeclaAtalho.descadastrarTecla", "", "", "Info",
                { classe: "sfTeclaAtalho", metodo: "descadastrarTecla" });
        }

        /**
         * @ngdoc overview
         * @name descadastrarTeclasEscopo
         *
         * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalhoGlobal
         *
         * @description
         * Método responsável por descadastrar todas as teclas atribuídas à tela
         */
        function descadastrarTeclasEscopo(escopoAtalho) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfTeclaAtalho.descadastrarTeclasEscopo", "", "", "Info",
                { classe: "sfTeclaAtalho", metodo: "descadastrarTeclasEscopo" });

            dicionarioTeclas = dicionarioTeclas.filter(function (atalhoDicionario) {
                return atalhoDicionario.escopoAtalho !== escopoAtalho;
            });

            if (dicionarioTeclas.length === 0) {
                angular.element($window).off("keydown");
            }

            sfLogger.escreverLogExecucao("Término de execução.", "sfTeclaAtalho.descadastrarTeclasEscopo", "", "", "Info",
                { classe: "sfTeclaAtalho", metodo: "descadastrarTeclasEscopo" });
        }

        /**
         * @ngdoc overview
         * @name recuperarTeclasCadastradas
         *
         * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalhoGlobal
         *
         * @description
         * Método responsável por recuperar a lista de teclas cadastradas no global
         */
        function recuperarTeclasCadastradas() {
            return dicionarioTeclas;
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.recursos.factories:sfTeclaAtalhoGlobal
     * @module arq-spa-base.arq-base-spa
     *
     * @description
     * Serviço responsável por controlar o cadastro e descadastro das teclas de atalho global
     */
    angular.module("arq-spa-base.recursos").factory("sfTeclaAtalhoGlobal", sfTeclaAtalhoGlobal);

    sfTeclaAtalhoGlobal.$inject = ["sfUtilitarios", "sfTeclaAtalho"];

    /**
     * @ngdoc overview
     * @name sfTeclaAtalhoGlobal
     *
     * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalhoGlobal
     *
     * @description
     * Iniciar o serviço
     */
    function sfTeclaAtalhoGlobal(sfUtilitarios, sfTeclaAtalho) {
        var escopoAtalho = "global";
        
        return {
            cadastrarTeclaGlobal: cadastrarTeclaGlobal,
            descadastrarTeclaGlobal: descadastrarTeclaGlobal 
        };

        /**
         * @ngdoc overview
         * @name cadastrarTeclaGlobal
         *
         * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalhoGlobal
         *
         * @requires tecla
         * @requires funcao
         * @requires modificadores {JSON} - { alt: true, shift: false, ctrl: true} 
         * @requires propagacao 
         * 
         * @description
         * Método responsável por cadastrar a tecla no global
         */
        function cadastrarTeclaGlobal(tecla, funcao, modificadores, propagacao) {
            if (angular.isDefined(tecla) && tecla !== "") {
                if (angular.isDefined(funcao) && funcao !== "") {
                    
                    tecla = sfUtilitarios.recuperarKeycode(tecla);

                    var atalho = {
                        tecla: tecla,
                        funcao: funcao,
                        modificadores: modificadores,
                        propagacao: propagacao,
                        escopoAtalho: escopoAtalho
                    };  
                    sfTeclaAtalho.cadastrarTecla(atalho);                                      
                } else {
                    throw new Error("Erro ao cadastrar tecla global - função não informada");
                }
            } else {
                throw new Error("Erro ao cadastrar tecla global - tecla de atalho não informada");
            }
        }

        /**
         * @ngdoc overview
         * @name descadastrarTeclaGlobal
         *
         * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalhoGlobal
         * 
         * @requires tecla
         *
         * @description
         * Método responsável por descadastrar a tecla no global
         */
        function descadastrarTeclaGlobal(tecla) {
            if (angular.isDefined(tecla) && tecla !== "") {
                tecla = sfUtilitarios.recuperarKeycode(tecla);
                var atalho = {
                    tecla: tecla,
                    escopoAtalho: escopoAtalho
                };                
                sfTeclaAtalho.descadastrarTecla(atalho);
            }
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.recursos.factories:sfTeclaAtalhoTela
     * @module arq-spa-base.recursos
     *
     * @description
     * Serviço responsável por controlar o cadastro e descadastro das teclas de atalho tela
     */
    angular.module("arq-spa-base.recursos").factory("sfTeclaAtalhoTela", sfTeclaAtalhoTela);

    sfTeclaAtalhoTela.$inject = ["sfUtilitarios", "sfTeclaAtalho"];

    /**
     * @ngdoc overview
     * @name sfTeclaAtalhoTela
     *
     * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalhoTela
     *
     * @description
     * Iniciar serviço
     */
    function sfTeclaAtalhoTela(sfUtilitarios, sfTeclaAtalho) {
        var escopoAtalho = "tela";

        return {
            cadastrarTeclaTela: cadastrarTeclaTela,
            descadastrarTeclaTela: descadastrarTeclaTela,
            descadastrarTodasTeclasTela: descadastrarTodasTeclasTela
        };

        /**
         * @ngdoc overview
         * @name cadastrarTeclaTela
         *
         * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalhoTela
         *
         * @requires tecla
         * @requires funcao
         * @requires modificadores {JSON} - { alt: true, shift: false, ctrl: true} 
         * @requires propagacao 
         * 
         * @description
         * Método responsável por cadastrar a tecla no tela
         */
        function cadastrarTeclaTela(tecla, funcao, modificadores, propagacao) {
            if (angular.isDefined(tecla) && tecla !== "") {
                if (angular.isDefined(funcao) && funcao !== "") {                  

                    tecla = sfUtilitarios.recuperarKeycode(tecla);

                    var atalho = {
                        tecla: tecla,
                        funcao: funcao,
                        modificadores: modificadores,
                        propagacao: propagacao,
                        escopoAtalho: escopoAtalho
                    };

                    sfTeclaAtalho.cadastrarTecla(atalho);
                } else {
                    throw new Error("Erro ao cadastrar tecla tela - função não informada");
                }
            } else {
                throw new Error("Erro ao cadastrar tecla tela - tecla de atalho não informada");
            }
        }

        /**
         * @ngdoc overview
         * @name descadastrarTeclaTela
         *
         * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalhoTela
         *
         * @requires tecla 
         * 
         * @description
         * Método responsável por descadastrar a tecla da tela
         */
        function descadastrarTeclaTela(tecla) {
            if (angular.isDefined(tecla) && tecla !== "") {
                tecla = sfUtilitarios.recuperarKeycode(tecla);
                var atalho = {
                    tecla: tecla,
                    escopoAtalho: escopoAtalho
                };
                sfTeclaAtalho.descadastrarTecla(atalho);
            }
        }

        /**
         * @ngdoc overview
         * @name descadastrarTeclaTela
         *
         * @methodOf arq-spa-base.recursos.factories:sfTeclaAtalhoTela
         *
         * @description
         * Método responsável por descadastrar todas as teclas de atalho atribuídas à tela
         */
        function descadastrarTodasTeclasTela() {
            sfTeclaAtalho.descadastrarTeclasEscopo(escopoAtalho);
        }
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc directive
     * @name arq-spa-base.recursos.directives:sfTraducao
     * 
     * @module arq-spa-base.recursos
     * 
     * @description
     * Diretiva responsável por incluir as diretivas do angular translate para tradução e cloak.
     */
    angular.module("arq-spa-base.recursos").directive("sfTraducao", traducao);

    traducao.$inject = ["$compile"];

    /**
     * @ngdoc overview
     * @name traducao
     * 
     * @methodOf arq-spa-base.recursos.directives:traducao
     * 
     * @description
     * Método responsável por definir a diretiva "sfTraducao".
     */
    function traducao($compile) {
        return {
            restrict: "A",
            priority: 9999,
            terminal: true,
            scope: false,
            compile: function () {
                return function (scope, elemento, atributos) {
                    elemento.removeAttr("sf-traducao");
                    elemento.attr("translate", atributos.sfTraducao);
                    elemento.attr("translate-cloak", atributos.sfTraducao);

                    $compile(elemento)(scope);
                };
            }
        };
    }
})();
(function () {
    "use strict";

    /**
     * @ngdoc provider
     * @name arq-spa-base.recursos.providers:sfTradutor
     * 
     * @module arq-spa-base.recursos
     * 
     * @requires $translateProvider
     * 
     * @description
     * Serviço responsável por prover os recursos de tradução à aplicação.
     */
    angular.module("arq-spa-base.recursos").provider("sfTradutor", sfTradutor);

    sfTradutor.$inject = ["$translateProvider", "sfLoggerProvider"];

    /**
     * @ngdoc object
     * @name sfTradutor
     *
     * @methodOf arq-spa-base.recursos.providers:sfTradutor
     *  
     * @description
     * Método responsável por inicializar o provider.
     */
    function sfTradutor($translateProvider, sfLoggerProvider) {
        this.configurarTradutor = configurarTradutor;
        this.$get = get;

        get.$inject = ["$translate", "$translatePartialLoader", "sfLogger"];

        /**
         * @ngdoc object
         * @name $get
         *
         * @methodOf arq-spa-base.recursos.providers:sfTradutor
         *  
         * @description
         * Método responsável por retornar a instância deste provider.
         * 
         * @returns {object} Objeto que representa a instância deste provider.
         */
        function get($translate, $translatePartialLoader, sfLogger) {
            return new Tradutor($translate, $translatePartialLoader, sfLogger);
        }

        /**
         * @ngdoc method
         * @name configurarTradutor
         *
         * @methodOf arq-spa-base.recursos.providers:sfTradutor
         *  
         * @description
         * Método responsável por efetuar as configurações do translateProvider para utilização na aplicação.
         */
        function configurarTradutor() {
            sfLoggerProvider.enfileirarLogExecucao("Início de execução.", "sfTradutor.configurarTradutor", "", "", "Info");
            $translateProvider.useLoader("$translatePartialLoader", {
                urlTemplate: "{part}/{lang}.json"
            });

            $translateProvider.preferredLanguage("pt-BR");

            $translateProvider.useSanitizeValueStrategy("sanitizeParameters");
            sfLoggerProvider.enfileirarLogExecucao("Término de execução.", "sfTradutor.configurarTradutor", "", "", "Info");
        }
    }

    /**
     * @ngdoc service
     * @name arq-spa-base.recursos.services:sfTradutor
     * @module arq-spa-base.recursos
     * 
     * @requires $translate
     * @requires $translatePartialLoader
     * 
     * @description
     * Definição do serviço responsável por prover os recursos de tradução.
     */
    function Tradutor($translate, $translatePartialLoader, sfLogger) {
        sfLogger.escreverLogExecucao("Início de execução.", "sfTradutor.Tradutor", "", "", "Info",
            { classe: "sfTradutor", metodo: "Tradutor" });
        this.adicionarDicionarios = adicionarDicionarios;
        this.alterarIdioma = alterarIdioma;
        this.atualizar = atualizar;

        /**
         * @ngdoc object
         * @name adicionarDicionarios
         * 
         * @methodOf arq-spa-base.recursos.services:sfTradutor
         * 
         * @description
         * Método responsável por adicionar os dicionários fornecidos ao processo de tradução.
         * 
         * @param {array(string)} Caminhos para os dicionarios que serão adicionados ao processo de tradução. 
         */
        function adicionarDicionarios(caminhosDicionarios) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfTradutor.adicionarDicionarios", "", "", "Info",
                { classe: "sfTradutor", metodo: "Tradutor.adicionarDicionarios" });
            var caminhos;

            if (angular.isString(caminhosDicionarios)) {
                caminhos = [caminhosDicionarios];
            }
            else {
                caminhos = caminhosDicionarios;
            }

            caminhos.forEach(function (caminho) {
                $translatePartialLoader.addPart(caminho);
            });

            sfLogger.escreverLogExecucao("Término de execução.", "sfTradutor.adicionarDicionarios", "", "", "Info",
                { classe: "sfTradutor", metodo: "Tradutor.adicionarDicionarios" });
            return $translate.refresh();
        }


        /**
         * @ngdoc object
         * @name alterarIdioma
         * 
         * @methodOf arq-spa-base.recursos.services:sfTradutor
         * 
         * @description
         * Método responsável por alterar o idioma.
         * 
         * @param {String} Idioma a ser utilizado. 
         */
        function alterarIdioma(idioma) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfTradutor.alterarIdioma", "", "", "Info",
                { classe: "sfTradutor", metodo: "Tradutor.alterarIdioma" });
            $translate.use(idioma);
            sfLogger.escreverLogExecucao("Término de execução.", "sfTradutor.alterarIdioma", "", "", "Info",
                { classe: "sfTradutor", metodo: "Tradutor.alterarIdioma" });
        }
        sfLogger.escreverLogExecucao("Término de execução.", "sfTradutor.Tradutor", "", "", "Info",
            { classe: "sfTradutor", metodo: "Tradutor" });


        /**
         * @ngdoc object
         * @name atualizar
         * 
         * @methodOf arq-spa-base.recursos.services:sfTradutor
         * 
         * @description
         * Método responsável forçar o carregamento dos jsons
         */
        function atualizar() {
            sfLogger.escreverLogExecucao("Início de execução.", "sfTradutor.atualizar", "", "", "Info",
                { classe: "sfTradutor", metodo: "Tradutor.atualizar" });
            $translate.refresh();
            sfLogger.escreverLogExecucao("Término de execução.", "sfTradutor.atualizar", "", "", "Info",
                { classe: "sfTradutor", metodo: "Tradutor.atualizar" });
        }
    }
})();
(function () {
    "use strict";

    var sfUtilitarios = {
        removerFormatacaoCaminho: removerFormatacaoCaminho,
        combinarCaminhos: combinarCaminhos,
        terminaCom: terminaCom,
        comecaCom: comecaCom,
        contem: contem,
        zerosAEsquerda: zerosAEsquerda,
        obterSequenciaCodigoBarrasITF25: obterSequenciaCodigoBarrasITF25,
        obterOSDispositivo: obterOSDispositivo,
        obterUrlServicosCanal: obterUrlServicosCanal,
        recuperarKeycode: recuperarKeycode,
        verificarBrowser: verificarBrowser,
        gerarNumerosAleatoriosParaCaracteres: gerarNumerosAleatoriosParaCaracteres,
        gerarLetrasAletoriosParaNumeros: gerarLetrasAletoriosParaNumeros,
        validarCMC7: validarCMC7,
        obterDadosPorCMC7: obterDadosPorCMC7,
        completarCaracteresDireita: completarCaracteresDireita,
        removerCaracteresNaoAlfaNumericos: removerCaracteresNaoAlfaNumericos
    };

    /**
     * @ngdoc object
     * @name removerFormatacaoCaminho
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável por remover a formatação de uma url adicionando.
     * 
     * @param {string} caminho_ Caminho que será formatado. 
     */
    function removerFormatacaoCaminho(caminho_) {
        var caminhoFormatado;

        if (caminho_ && caminho_.length > 0) {
            caminhoFormatado = caminho_;

            if (sfUtilitarios.terminaCom(caminhoFormatado, "/")) {
                do {
                    caminhoFormatado = caminhoFormatado.slice(0, (caminhoFormatado.length - 1));
                } while (sfUtilitarios.terminaCom(caminhoFormatado, "/"));
            }

            if (sfUtilitarios.comecaCom(caminhoFormatado, "/")) {
                do {
                    caminhoFormatado = caminhoFormatado.slice(1, caminhoFormatado.length);
                } while (sfUtilitarios.comecaCom(caminhoFormatado, "/"));
            }
        }
        else {
            caminhoFormatado = caminho_;
        }

        return caminhoFormatado;
    }

    /**
     * @ngdoc object
     * @name combinarCaminhos
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável por combiar os caminhos informados.
     * 
     * @param {string|array} caminhos_ Caminhos que serão combinados. 
     */
    function combinarCaminhos(caminhos_) {
        var caminhoCombinado = "";

        if (caminhos_) {
            if (caminhos_.length > 1) {
                caminhoCombinado = sfUtilitarios.removerFormatacaoCaminho(caminhos_[0]) + "/" + sfUtilitarios.combinarCaminhos(caminhos_.slice(1, caminhos_.length));
            }
            else {
                caminhoCombinado = sfUtilitarios.removerFormatacaoCaminho(caminhos_[0]);
            }
        }

        return caminhoCombinado;
    }

    /**
     * @ngdoc object
     * @name terminaCom
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável por verificar se a estring informada termina com o sufixo informado.
     * 
     * @param {string} string_ String que será comparada.
     * @param {string} sufixo_ Sufixo que será verificado.
     * 
     * @returns {boolean} True caso a string informada termine com o sufixo definido ou false caso contrário.
     */
    function terminaCom(string_, sufixo_) {
        return string_.match(sufixo_ + "$") == sufixo_;
    }

    /**
     * @ngdoc object
     * @name comecaCom
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável por verificar se a estring informada começa com o prefixo informado.
     * 
     * @param {string} string_ String que será comparada.
     * @param {string} prefixo_ Prefixo que será verificado.
     * 
     * @returns {boolean} True caso a string informada comece com o prefixo definido ou false caso contrário.
     */
    function comecaCom(string_, prefixo_) {
        return string_.indexOf(prefixo_) === 0;
    }

    /**
     * @ngdoc object
     * @name contem
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável por verificar se a estring informada contém o valor informado.
     * 
     * @param {string} string_ String que será comparada.
     * @param {string} conteudo_ Conteúdo que será verificado.
     * 
     * @returns {boolean} True caso a string informada comece com o prefixo definido ou false caso contrário.
     */
    function contem(string_, conteudo_) {
        return string_.indexOf(conteudo_) >= 0;
    }

    /**
     * @ngdoc object
     * @name rq-spa-base.recursos.constants:sfUtilitarios.zerosAEsquerda
     * 
     * @param {string} string_ Número que deseja-se incrementar com zeros a esquerda
     * @param {int} tamanho_ Quantidade de caracteres que o número deve conter após incremento de zeros a esquerda
     */
    function zerosAEsquerda(string_, tamanho_) {
        if (angular.isDefined(string_) && angular.isDefined(tamanho_)) {
            var pad = "";
            for (var i = 0; i < tamanho_; i++) {
                pad += "0";
            }
            return (pad + string_).slice(-pad.length);
        }
        else {
            return string_;
        }
    }

    /**
     * @ngdoc object
     * @name obterSequenciaCodigoBarrasITF25
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável retornar uma sequência de caracteres representando o código de barras
     * 
     * @param {string} Número do código de barras
     * 
     * @returns {String} Código de Barras interpretado pela fonte ITF 2 de 9 Intercalado
     */
    function obterSequenciaCodigoBarrasITF25(codigo) {

        if (codigo.length === 0 || codigo.length % 2 !== 0) {
            return undefined;
        }

        var i;
        var codigoFinal = "";

        for (i = 0; i < codigo.length; i = i + 2) {
            var codigoTmp = Number(codigo.substring(i, i + 2));

            if (codigoTmp <= 49) {
                codigoTmp = codigoTmp + 48;
            }
            else {
                codigoTmp = codigoTmp + 142;
            }

            codigoFinal = codigoFinal + String.fromCharCode(codigoTmp);
        }

        codigoFinal = "(" + codigoFinal + ")";

        return codigoFinal;
    }

    /**
     * @ngdoc object
     * @name recuperarKeycode
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável por obter a keycode do atalho parametrizado
     * 
     * @param {string} Atalho, ex: down, up, 1, etc...
     * 
     * @returns {String} keycode, ex: 40, 32, 52, etc...
     */
    function recuperarKeycode(atalho) {
        return keyCodes[atalho] || atalho;
    }

    /**
     * @ngdoc object
     * @name obterTipoDispositivo
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável obter o OS do dispositivo.
     * 
     * @param {string} User Agent
     * 
     * @returns {String} Windows/Android/iOS
     */
    function obterOSDispositivo(userAgent) {
        if (/windows phone/i.test(userAgent)) {
            return "Windows Phone";
        }

        else if (/android/i.test(userAgent)) {
            return "Android";
        }

        if (/iPad|iPhone|iPod/.test(userAgent)) {
            return "iOS";
        }

        return "";
    }

    /**
     * @ngdoc object
     * @name obterUrlServicosCanal
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável retornar a url backend específica para o serviços canal
     * 
      @param {string} Url backend
     * 
     * @returns {String} url backend de serviços canal
     */
    function obterUrlServicosCanal(urlBackend) {
        return combinarCaminhos([urlBackend, "servicoscanal"]);
    }

    /**
     * @ngdoc object
     * @name verificaBrowser
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável um objeto com todos os dados 
     * do browser utilizado no client.
     * 
     * @param {string} Objeto navigator
     * 
     * @returns {Object} Objeto contendo sistema operacional, plataforma, navegador, versao navegador, tipo Windows
     */
    function verificarBrowser(navigator) {
        var sistemaOperacional = "";
        var plataforma = "";
        var navegador = "";
        var versaoNavegador = "";
        var tipoWindows = "";
        var versao = 0;

        if (navigator.userAgent.match(/(Linux)|(unix)/)) {
            sistemaOperacional = "LIN";
        } else if (navigator.userAgent.match(/(Win)/)) {
            sistemaOperacional = "WIN";
            if (navigator.platform.match(/(32)/)) {
                plataforma = "32"; //32 bits
            } else {
                plataforma = "64"; //64 bits
            }
            tipoWindows = navigator.userAgent.substring(navigator.userAgent.indexOf("Windows NT"), navigator.userAgent.indexOf("Windows NT") + 14);
        } else if (navigator.userAgent.match(/(Mac)/)) {
            sistemaOperacional = "MAC";
        } else {
            sistemaOperacional = "OUT";
        }

        if (navigator.userAgent.match(/(Opera)|(OPR)/)) {
            navegador = "OPER";
            if (navigator.userAgent.match(/(Version)/)) {
                versaoNavegador = navigator.userAgent.substring(navigator.userAgent.indexOf("Version") + 8);
            } else if (navigator.userAgent.match(/OPR/)) {
                versaoNavegador = navigator.userAgent.substring(navigator.userAgent.indexOf("OPR") + 4);
            } else {
                versaoNavegador = navigator.userAgent.substring(navigator.userAgent.indexOf("Opera") + 6);
            }
        } else if (navigator.userAgent.match(/(MSIE)/)) {
            navegador = "MSIE";
            versaoNavegador = navigator.userAgent.substring(navigator.userAgent.indexOf("MSIE") + 5);
            versao = versaoNavegador.substring(0, 2).replace(".", "");
            versao = Number(versao);
        } else if (navigator.userAgent.match(/(Chrome)/)) {
            navegador = "CHRO";
            versaoNavegador = navigator.userAgent.substring(navigator.userAgent.indexOf("Chrome") + 7);
        } else if (navigator.userAgent.match(/(Safari)|(iPad)|(iPhone)/)) {
            navegador = "SAFA";
            if (navigator.userAgent.match(/(Version)/)) {
                versaoNavegador = navigator.userAgent.substring(navigator.userAgent.indexOf("Version") + 8);
            } else if (navigator.userAgent.match(/(Safari)/)) {
                versaoNavegador = navigator.userAgent.substring(navigator.userAgent.indexOf("Safari") + 7);
            }
        } else if (navigator.userAgent.match(/(Firefox)/)) {
            navegador = "FIRE";
            versaoNavegador = navigator.userAgent.substring(navigator.userAgent.indexOf("Firefox") + 8);
        } else if (navigator.userAgent.match(/(Trident)/)) {
            navegador = "MSIE";
            versaoNavegador = navigator.userAgent.substring(navigator.userAgent.indexOf("rv:") + 3, navigator.userAgent.indexOf("rv:") + 7);
            versao = Number(versaoNavegador);
        } else {
            navegador = "OUTR";
            versaoNavegador = "OUTR";
        }

        return {
            sistemaOperacional: sistemaOperacional,
            plataforma: plataforma,
            navegador: navegador,
            tipoWindows: tipoWindows,
            versaoNavegador: versaoNavegador,
            versao: versao
        };
    }

    /**
     * @ngdoc object
     * @name gerarNumerosAleatoriosParaCaracteres
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável por retornar um array de caracteres x códigos
     * 
     * @param {string} sequenciaCaracteres Sequência de caracteres que receberá um código aleatório respectivo
     * @param {int} minimo Número mínimo do código aleatório
     * @param {int} maximo Número máximo do código aleatório
     * 
     * @returns {Array} Array de objeto {char, code}
     */
    function gerarNumerosAleatoriosParaCaracteres(sequenciaCaracteres, minimo, maximo) {
        var min = minimo || 0;
        var max = maximo || 99;
        var chars = sequenciaCaracteres || "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        if (chars.length > (max - min + 1)) {
            throw new Error("Não é possível gerar códigos aleatórios diferentes para sequência informada");
        }

        var charArray = chars.split("");
        var codigosAleatorios = [];
        var codigosAux = [];

        angular.forEach(charArray, gerarCodigoAleatorio);

        /**
         * @ngdoc object
         * @name gerarCodigoAleatorio
         * 
         * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
         * 
         * @description
         * Método responsável por gerar um código aleatório 
         * para um determinado caractere
         * 
         * @param {string} Caractere a receber um código aleatório
         * 
         */
        function gerarCodigoAleatorio(char) {
            var codigoAleatorio = obterCodigoAleatorio();

            var item = {
                char: char,
                code: codigoAleatorio
            };

            codigosAleatorios.push(item);
        }

        /**
         * @ngdoc object
         * @name obterCodigoAleatorio
         * 
         * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
         * 
         * @description
         * Método responsável por gerar um código aleatório 
         * diferente para o contexto dessa chamada
         * 
         */
        function obterCodigoAleatorio() {
            var codigo = window.chance.integer({ min: min, max: max });

            if (contem(codigosAux, codigo)) {
                codigo = obterCodigoAleatorio();
            } else {
                codigosAux.push(codigo);
            }

            return zerosAEsquerda(codigo, 2);
        }

        return codigosAleatorios;
    }

    /**
     * @ngdoc object
     * @name gerarLetrasAletoriosParaNumeros
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável por retornar um array de número x letras aleatórias
     * 
     * @param {string} sequenciaNumeros Sequência de números que receberá uma letra aleatória
     * @param {string} sequenciaLetras Sequência de letras que irão ser atribuídas aleatoriamente à sequência numérica
     * 
     * @returns {Array} Array de objeto {letra, número}
     */
    function gerarLetrasAletoriosParaNumeros(sequenciaNumeros, sequenciaLetras) {
        var sequencia = [];
        var letrasAux = [];
        var letras = sequenciaLetras || "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        var numeros = sequenciaNumeros || "0123456789";
        var arrayNumeros = numeros.split("");

        if (letras.length < numeros.length) {
            throw new Error("Não é possível gerar letras aleatórias diferentes para sequência numérica informada");
        }

        angular.forEach(arrayNumeros, gerarLetraAletoria);

        /**
         * @ngdoc object
         * @name gerarLetraAletoria
         * 
         * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
         * 
         * @description
         * Método responsável por gerar uma letra aleatória 
         * para um determinado número
         * 
         * @param {string} Número a receber uma letra aleatória
         * 
         */
        function gerarLetraAletoria(numero) {
            var letraAleatoria = obterLetraAleatoria();

            var item = {
                numero: Number(numero),
                letra: letraAleatoria
            };

            sequencia.push(item);
        }

        /**
         * @ngdoc object
         * @name obterLetraAleatoria
         * 
         * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
         * 
         * @description
         * Método responsável por gerar uma letra aleatória 
         * diferente para o contexto dessa chamada
         * 
         */
        function obterLetraAleatoria() {
            var letra = window.chance.character({ pool: letras });
            if (contem(letrasAux, letra)) {
                letra = obterLetraAleatoria();
            } else {
                letrasAux.push(letra);
            }

            return letra;
        }

        return sequencia;
    }

    /**
     * @ngdoc object
     * @name validarCMC7
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável por válidar o código CMC7
     * 
     * @param {string} CodigoCMC7 Código do cheque
     * 
     * @returns {boolean} Resultado da validação
     */
    function validarCMC7(codigoCMC7) {
        if (angular.isUndefined(codigoCMC7) || codigoCMC7 === null) {
            return false;
        }

        codigoCMC7 = removeEspacoECaracteresEspeciais(codigoCMC7);

        if (codigoCMC7.length < 30 || !validarCampoNumerico(codigoCMC7)) {
            return false;
        }

        var digitos = {
            primeiro: parseInt(codigoCMC7.substr(7, 1)) //C
            , segundo: parseInt(codigoCMC7.substr(18, 1)) //F
            , terceiro: parseInt(codigoCMC7.substr(29, 1)) //J
        };

        var pedacos = {
            primeiro: codigoCMC7.substr(0, 7) //Código banco + Agência
            , segundo: codigoCMC7.substr(8, 10) //Comp. + Número do Cheque + Tipificação Cheque
            , terceiro: codigoCMC7.substr(19, 10) //Número da Conta
        };

        var digitosCalculados = {
            primeiro: calcularModulo10(pedacos.primeiro)
            , segundo: calcularModulo10(pedacos.segundo)
            , terceiro: calcularModulo10(pedacos.terceiro)
        };

        if ((digitosCalculados.segundo != digitos.primeiro)
            || (digitosCalculados.primeiro != digitos.segundo)
            || (digitosCalculados.terceiro != digitos.terceiro)) {
            return false;
        }
        return true;


        /**
         * @ngdoc object
         * @name recuperarDigitoVerificadorMod10
         * 
         * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
         * 
         * @description
         * Método responsável por válidar o conteudo do modulo 10
         * 
         * @param {string} str valor do modulo 10
         * 
         * @returns {boolean} Resultado da validação
         */
        function calcularModulo10(numeroString) {
            var tamanho = numeroString.length - 1;
            var calculo = 0;
            var peso = 2;

            for (var i = tamanho; i >= 0; i--) {
                var total = numeroString.substr(i, 1) * peso;
                if (total > 9) {
                    calculo = calculo + 1 + (total - 10);
                } else {
                    calculo = calculo + total;
                }
                if (peso == 1) {
                    peso = 2;
                } else {
                    peso = 1;
                }
            }
            var sobra = mod(calculo, 10);
            var dv = 10 - sobra;
            if (dv == 10) {
                dv = 0;
            }
            return dv;
        }

        /**
         * @ngdoc object
         * @name mod
         * 
         * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
         * 
         * @description
         * Método responsável por válidar o digito verificador
         * 
         * @param {string} dividend dividendo
         * @param {string} divisor divisor
         * 
         * @returns {boolean} Resultado da validação
         */
        function mod(dividend, divisor) {
            return Math.round(dividend - (Math.floor(dividend / divisor) * divisor));
        }

        /**
         * @ngdoc object
         * @name removeEspacoECaracteresEspeciais
         * 
         * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
         * 
         * @description
         * Método responsável por remover os caracteres especiais e espaços em branco
         * 
         * @param {string} codigo código do cmc7
         * 
         * @returns {string} valor formatado
         */
        function removeEspacoECaracteresEspeciais(codigo) {
            return codigo.replace(/<|>|_| |:\s/g, "");
        }

        /**
         * @ngdoc object
         * @name validarCampoNumerico
         * 
         * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
         * 
         * @description
         * Método responsável por verificar se o campo é numérico
         * 
         * @param {string} codigo código do cmc7
         * 
         * @returns {boolean} indica se o campo é número
         */
        function validarCampoNumerico(codigo) {
            return codigo.match(/(^[0-9])\w+/);
        }
    }

    /**
     * @ngdoc object
     * @name obterDadosPorCMC7
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável destrinchar os dados do CMC7
     * 
     * @param {string} CodigoCMC7 Código do cheque
     * 
     * @returns {object} objeto contendo agência, conta, número, complemento, dv's, c's e etc
     */
    function obterDadosPorCMC7(codigoCMC7) {
        if (angular.isUndefined(codigoCMC7) || codigoCMC7.length < 30) {
            return undefined;
        }

        codigoCMC7 = codigoCMC7.replace(/<|>| |:/g, "");

        var dados = {};

        dados.banco = codigoCMC7.substring(0, 3);
        dados.agencia = codigoCMC7.substring(3, 7);
        dados.comp = codigoCMC7.substring(8, 11);
        dados.numeroCheque = codigoCMC7.substring(11, 17);
        dados.tipificacao = codigoCMC7.substring(17, 18);
        
        /** @deprecated numero de serie deve vir vazio.*/
        dados.serie = "";
        dados.numeroConta = parseInt(codigoCMC7.substring(19, 29));

        dados.primeiraBanda = codigoCMC7.substring(0, 8);
        dados.segundaBanda = codigoCMC7.substring(8, 18);
        dados.terceiraBanda = codigoCMC7.substring(18, 30);

        dados.dv1 = codigoCMC7.substring(18, 19);
        dados.dv2 = codigoCMC7.substring(7, 8);
        dados.dv3 = codigoCMC7.substring(29, 30);

        dados.c1 = "" + calcularModulo11(dados.comp + dados.banco + dados.agencia);
        dados.c2 = "" + calcularModulo11(dados.serie + dados.numeroConta);
        dados.c3 = "" + calcularModulo11(dados.numeroCheque);

        return dados; 

        /**
         * @ngdoc overview
         * @name calcularModulo11
         *
         * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
         * 
         * @description Método que calcula módulo 11 de um número em formato String
         *   
         * @param {String} numero numeros para o cálculo
         * 
         */
        function calcularModulo11(numero) {
            var tamanho = numero.length - 1;
            var peso = 2;
            var calculo = 0;

            for (var i = tamanho; i >= 0; i--) {
                calculo += numero.substr(i, 1) * peso;
                peso = (peso === 9) ? 2 : peso + 1;
            }

            var resto = (calculo * 10) % 11;
            var dv = resto;

            if (dv >= 10) {
                dv = 0;
            }

            return dv;
        }
    }

    /**
     * @ngdoc object
     * @name completarCaracteresDireita
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável por completar o valor parametrizado 
     * com os caracteres no tamanho parametrizado
     * 
     * @param {string} valor valor que será completado
     * @param {string} tamanho tamanho que o valor deverá conter
     * @param {string} caractere caracteres preenchedor de espaços
     * 
     * @returns {string} Resultado do preenchimento
     */
    function completarCaracteresDireita(valor, tamanho, caractere) {
        if (angular.isDefined(valor) && angular.isDefined(tamanho) && angular.isDefined(caractere)) {
            return (valor.toString().length < tamanho) ? completarCaracteresDireita(valor + caractere, tamanho, caractere) : valor;
        }
        else {
            return valor;
        }
    }   

    /**
     * @ngdoc object
     * @name removerCaracteresNaoAlfaNumericos
     * 
     * @methodOf arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @description
     * Método responsável por remover caracteres não alfa numéricos
     * 
     * @param {string} str valor que será substituido
     * @param {string} valor valor que será completado
     * 
     * @returns {string} Resultado da remoção
     */
    function removerCaracteresNaoAlfaNumericos(string, valor) {
        if (angular.isDefined(string)) {
            valor = valor || "";
            return string.toString().replace(/[^a-z0-9]+/gi, valor);
        } else {
            return string;
        }
    }


    /**
     * @ngdoc object
     * @name arq-spa-base.recursos.constants:sfUtilitarios
     * 
     * @module arq-spa-base.recursos
     * 
     * @description
     * Constante responsável por prover recursos utilitários para aplicação.
     */
    angular.module("arq-spa-base.recursos").constant("sfUtilitarios", sfUtilitarios);

    var keyCodes = {
        "break": 3,
        "backspace / delete": 8,
        "tab": 9,
        "clear": 12,
        "enter": 13,
        "shift": 16,
        "ctrl ": 17,
        "alt": 18,
        "pause/break": 19,
        "caps lock": 20,
        "escape": 27,
        "space": 32,
        "page up": 33,
        "page down": 34,
        "end": 35,
        "home": 36,
        "left": 37,
        "up": 38,
        "right": 39,
        "down": 40,
        "select": 41,
        "print": 42,
        "execute": 43,
        "Print Screen": 44,
        "insert": 45,
        "delete": 46,
        "0": 48,
        "1": 49,
        "2": 50,
        "3": 51,
        "4": 52,
        "5": 53,
        "6": 54,
        "7": 55,
        "8": 56,
        "9": 57,
        ":": 58,
        "semicolon (firefox), equals": 59,
        "<": 60,
        "equals (firefox)": 61,
        "ß": 63,
        "@ (firefox)": 64,
        "a": 65,
        "b": 66,
        "c": 67,
        "d": 68,
        "e": 69,
        "f": 70,
        "g": 71,
        "h": 72,
        "i": 73,
        "j": 74,
        "k": 75,
        "l": 76,
        "m": 77,
        "n": 78,
        "o": 79,
        "p": 80,
        "q": 81,
        "r": 82,
        "s": 83,
        "t": 84,
        "u": 85,
        "v": 86,
        "w": 87,
        "x": 88,
        "y": 89,
        "z": 90,
        "Windows Key / Left ⌘ / Chromebook Search key": 91,
        "right window key ": 92,
        "Windows Menu / Right ⌘": 93,
        "numpad 0": 96,
        "numpad 1": 97,
        "numpad 2": 98,
        "numpad 3": 99,
        "numpad 4": 100,
        "numpad 5": 101,
        "numpad 6": 102,
        "numpad 7": 103,
        "numpad 8": 104,
        "numpad 9": 105,
        "multiply": 106,
        "add": 107,
        "numpad period (firefox)": 108,
        "subtract": 109,
        "decimal point": 110,
        "divide": 111,
        "f1": 112,
        "f2": 113,
        "f3": 114,
        "f4": 115,
        "f5": 116,
        "f6": 117,
        "f7": 118,
        "f8": 119,
        "f9": 120,
        "f10": 121,
        "f11": 122,
        "f12": 123,
        "f13": 124,
        "f14": 125,
        "f15": 126,
        "f16": 127,
        "f17": 128,
        "f18": 129,
        "f19": 130,
        "f20": 131,
        "f21": 132,
        "f22": 133,
        "f23": 134,
        "f24": 135,
        "num lock ": 144,
        "scroll lock": 145,
        "^": 160,
        "!": 161,
        "#": 163,
        "$": 164,
        "ù": 165,
        "page backward": 166,
        "page forward": 167,
        "closing paren (AZERTY)": 169,
        "": 170,
        "~ +  key": 171,
        "minus (firefox), mute/unmute": 173,
        "decrease volume level": 174,
        "increase volume level": 175,
        "next": 176,
        "previous": 177,
        "stop": 178,
        "play/pause": 179,
        "e-mail": 180,
        "mute/unmute (firefox)": 181,
        "decrease volume level (firefox)": 182,
        "increase volume level (firefox)": 183,
        "semi-colon / ñ": 186,
        "equal sign ": 187,
        "comma": 188,
        "dash ": 189,
        "period ": 190,
        "forward slash / ç": 191,
        "grave accent / ñ": 192,
        "?, / or °": 193,
        "numpad period (chrome)": 194,
        "open bracket": 219,
        "back slash": 220,
        "close bracket": 221,
        "single quote": 222,
        "`": 223,
        "left or right ⌘ key (firefox)": 224,
        "altgr": 225,
        "< /git >": 226,
        "GNOME Compose Key": 230,
        "XF86Forward": 233,
        "XF86Back": 234,
        "toggle touchpad": 255
    };

})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.tabelas-gerais
     * @description
     * Módulo de tabelas gerais da arquitetura base que provê as funcionalidades ..
     */
    angular.module("arq-spa-base.tabelas-gerais", []);
})();

(function () {
    "use strict";

    angular.module("arq-spa-base.tabelas-gerais").factory("sfTabelasGerais", sfTabelasGerais);

    sfTabelasGerais.$inject = ["$http", "appSettings", "sfUtilitarios", "sfConectorAPI", "sfLogger"];

    /**
     * @ngdoc overview
     * @name arq-spa-base.sfTabelasGerais.factories:sfTabelasGerais
     * @module arq-spa-base.sfTabelasGerais
     * 
     * @requires $http
     * @requires appSettings
     * @requires sfUtilitarios
     * 
     * @description
     * Factory resposável por consumir o arquivo de configuração de tabelas gerais
     */
    function sfTabelasGerais($http, appSettings, sfUtilitarios, sfConectorAPI, sfLogger) {

        return {
            obterDominio: obterDominio,
            obterDeCodigos: obterDeCodigos
        };

        /**
         * @ngdoc method
         * @name obterDominio
         *
         * @methodOf arq-spa-base.sfTabelasGerais.factories:sfTabelasGerais
         *  
         * @description
         * Método responsável por  retornar os dados de domínio da tabelas gerais.
         * 
         * @param {string} Domínio que será obtido.
         * @param {boolean} Indicador se o loader deve ser exibido ou não.
         */
        function obterDominio(dominio, exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfTabelasGerais.obterDominio", "", "", "Info",
                { classe: "sfTabelasGerais", metodo: "obterDominio" });
            if (angular.isDefined(dominio) && angular.isString(dominio) && dominio !== "") {
                var configHttp = {
                    method: "GET",
                    url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "reference-data", dominio])
                };

                sfLogger.escreverLogExecucao("Término de execução.", "sfTabelasGerais.obterDominio", "", "", "Info",
                    { classe: "sfTabelasGerais", metodo: "obterDominio" });
                return sfConectorAPI.executar(configHttp, exibirLoader);
            }
            else {
                throw new Error("O domínio deve ser informado.");
            }
        }

        /**
         * @ngdoc method
         * @name obterDeCodigo
         *
         * @methodOf arq-spa-base.sfTabelasGerais.factories:sfTabelasGerais
         *  
         * @description
         * Método responsável por retornar os dados com Domínio e de Código
         * 
         * @param {string} Domínio do que será obtido.
         * @param {string} Código que será obtido.
         * @param {boolean} Indicador se o loader deve ser exibido ou não. 
         */
        function obterDeCodigos(dominio, codigo, exibirLoader) {
            sfLogger.escreverLogExecucao("Início de execução.", "sfTabelasGerais.obterDeCodigos", "", "", "Info",
                { classe: "sfTabelasGerais", metodo: "obterDeCodigos" });
            if (angular.isDefined(dominio) && angular.isString(dominio) && dominio !== "") {
                if (angular.isDefined(codigo) && angular.isString(codigo) && codigo !== "") {
                    var configHttp = {
                        method: "GET",
                        url: sfUtilitarios.combinarCaminhos([sfUtilitarios.obterUrlServicosCanal(appSettings.comunicacao.urlBackend), "reference-data", dominio, codigo])
                    };

                    sfLogger.escreverLogExecucao("Término de execução.", "sfTabelasGerais.obterDeCodigos", "", "", "Info",
                        { classe: "sfTabelasGerais", metodo: "obterDeCodigos" });
                    return sfConectorAPI.executar(configHttp, exibirLoader);
                }
                else {
                    throw new Error("O código deve ser informado.");
                }
            }
            else {
                throw new Error("O domínio deve ser informado.");
            }
        }
    }
})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base.validacoes
     * 
     * @requires ui.router
     * @requires oc.lazyLoad
     * 
     * @description
     * Módulo de navegação da arquitetura base que provê os recursos necessários para validações comuns de campos de formulário.
     */
    angular.module("arq-spa-base.validacoes", ["ui.mask"]);
})();
(function(){
    "use strict";
    
    /**
     * @ngdoc object
     * @name ValidarAnoBissexto
     * 
     * @param {string} strAnoBissexto String que contém um ano inserido pelo usuário
     * @returns {boolean} Flag que indica se um ano é bissexto ou não
     * 
     * @description
     * Método responsável por verificar se o ano recebido é bissexto ou não.
     */
    function validarAnoBissexto (strAnoBissexto) {
        if (strAnoBissexto != undefined)
        {
            if (strAnoBissexto != "" && strAnoBissexto.length == 8) {
                var ano = strAnoBissexto.substring(4, strAnoBissexto.length);
                if (((ano % 4) == 0) && ((ano % 100) != 0) || ((ano % 400) == 0)) {
                    return true;
                }
                return false;
            }
        }
        return false;
        
    }
    
    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: ValidacaoAnoBissexto
     * @module arq-spa-base.validacoes
     * 
     * @description      
     * Responsável por realizar validação do campo de Ano Bissexto
     */
    function validacaoAnoBissexto() {
        return {
            restrict: "A",
            require: "ngModel",
            scope: {ngModel:"="},
            replace: "true",
            link: function link(scope, ele, attrs, ngModelController) {
                ele.attr("ui-mask","99/99/9999");
                ele.attr("ui-mask-placeholder-char","_");

                ngModelController.$validators.anobissexto = function(modelValue, viewValue)
                {
                    return validarAnoBissexto(viewValue);
                };
            }
        };
    }
    
     angular.module("arq-spa-base.validacoes").directive("sfAnoBissexto", validacaoAnoBissexto);
    
})();
(function () {
    "use strict";
    
    angular.module("arq-spa-base.validacoes").directive("sfCaracteresEspeciais", validarCaracteresEspeciais);
    
    validarCaracteresEspeciais.$inject = ["appSettings"];
    
    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: validarCaracteresEspeciais
     * @module arq-spa-base.validacoes
     *  
     * @description
     * Método responsável por verificar se o e-mail informado é valido.
     */
    function validarCaracteresEspeciais(appSettings) {
        return {
            restrict: "A",
            link: link                                  
        };
        
        /**
        * @ngdoc object
        * @name link
        * 
        * @description
        * Método responsável por verificar se o campo de confirmação é igual o campo informado anteriormente.
        */
        function link(scope, element) {
            var regex = new RegExp(appSettings.configuracao.expressaoRegularCaracteresEspeciais);
            element.bind("keypress paste", bloquearCaracteres);
            
            /**
             * @ngdoc object
             * @name bloquearCaracteres
             * 
             * @description
             * Método contendo a lógica para bloquear os caracteres especiais informados no HTML do código.
             */
            function bloquearCaracteres (event) {
                var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
                
                if(!regex.test(key)){
                    event.preventDefault();
                }
            }
        }
    }
})();
(function(){
    "use strict";
    
     /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes:aplicarMascaraCEP
     * @module arq-spa-base.validacoes
     * 
     * @description      
     * Responsável por disponibilizar controle de tela para inclusão de CEP
     */
    function aplicarMascaraCEP() {
        return {
            restrict: "E",
            require: "ngModel",
            scope: {ngModel:"=", valorComMascara: "&", valorSemMascara:"&"},
            replace: "true",
            template: "<input type=\"text\" ui-options=\"{clearOnBlur:false}\"  ui-mask=\"99999-999\" ui-mask-placeholder-char=\"_\" valor-com-mascara=\"valorComMascara()\" valor-sem-mascara=\"valorSemMascara()\" />",
            link: function link(scope, ele, attrs) {
                
                scope.valorSemMascara = function(){
                    return scope.ngModel;
                };
                
                scope.valorComMascara = function(){
                    var resultado = "";
                    var posicaoModel = 0;
                    for(var i = 0; i < attrs.uiMask.length; i++){
                        if(attrs.uiMask.charAt(i) == "9"){
                            resultado += scope.ngModel.charAt(posicaoModel);
                            posicaoModel++;
                        }
                        else{
                            resultado += attrs.uiMask.charAt(i);
                        } 
                    }
                    return resultado;
                };
            }
        };
    }
    
    angular.module("arq-spa-base.validacoes").directive("sfCep", aplicarMascaraCEP);
    
})();
(function(){
    "use strict";
    
    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: ValidacaoCMC7
     * @module arq-spa-base.validacoes
     * 
     * @requires arq-spa-base.validacoes.service:ValidacaoCMC7Service
     * 
     * @description      
     * Responsável por realizar validação e aplicação de máscara no campo de CMC7
     */
    function validacaoCMC7(sfUtilitarios) {
        return {
            restrict: "E",
            require: "ngModel",
            scope: {ngModel:"=", valorComMascara: "&", valorSemMascara:"&"},
            replace: "true",
            template: "<input type=\"text\" ui-options=\"{clearOnBlur:false}\"  ui-mask=\"99999999 9999999999 999999999999\" ui-mask-placeholder-char=\"_\" valor-com-mascara=\"valorComMascara()\" valor-sem-mascara=\"valorSemMascara()\"/>",
            link: function (scope, ele, attrs, ngModelController) {
                
                ngModelController.$validators.cmc7 = function (modelValue, viewValue) {
                    return sfUtilitarios.validarCMC7(viewValue);
                };

                scope.valorSemMascara = function(){
                    return scope.ngModel;
                };
                
                scope.valorComMascara = function(){
                    var resultado = "";
                    var posicaoModel = 0;
                    for(var i = 0; i < attrs.uiMask.length; i++){
                        if(attrs.uiMask.charAt(i) == "9"){
                            resultado += scope.ngModel.charAt(posicaoModel);
                            posicaoModel++;
                        }
                        else{
                            resultado += attrs.uiMask.charAt(i);
                        } 
                    }
                    return resultado;
                };
                
                
            }
        };
    }

    validacaoCMC7.$inject = ["sfUtilitarios"];
    
    angular.module("arq-spa-base.validacoes").directive("sfCmc7", validacaoCMC7);
    
})();
(function(){
    "use strict";
    
     /**
     * @ngdoc object
     * @name algoritmoCnpj
     *
     * @param {string} CNPJ String que contém o valor de um CNPJ inserido pelo usuário
     * @returns {boolean} Flag que indica se é um CNPJ valido ou não
     *
     * @description
     * Método responsável por encapsular algoritmo de cálculo de um CNPJ válido.
     */
    function algoritmoCnpj(cnpj) {
        var tamanhoCnpj = cnpj.length;

        var tamanho = tamanhoCnpj - 2;
        var numeros = cnpj.substring(0, tamanho);
        var digitos = cnpj.substring(tamanho);
        var soma = 0;
        var pos = tamanho - 7;
        for (var i = tamanho; i >= 1; i--) {
            soma += numeros.charAt(tamanho - i) * pos--;
            if (pos < 2) {
                pos = 9;
            }
        }
        var resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;

        if (resultado.toString() !== digitos.charAt(0).toString()) {
            return false;
        }
        tamanho = tamanho + 1;
        numeros = cnpj.substring(0, tamanho);
        soma = 0;
        pos = tamanho - 7;
        for (i = tamanho; i >= 1; i--) {
            soma += numeros.charAt(tamanho - i) * pos--;
            if (pos < 2) {
                pos = 9;
            }
        }
        resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
        return resultado.toString() === digitos.charAt(1);
    }
        
    /**
     * @ngdoc object
     * @name validarCNPJ
     * 
     * @param {string} cnpj String que contém o valor de um CNPJ inserido pelo usuário
     * @returns {boolean} Flag que indica se é um CNPJ valido ou não
     * 
     * @description
     * Método responsável por verificar se o CNPJ recebido é válido ou não.
     */
    function validarCNPJ (cnpj) {
        var cnpjPattern = /^\d{2}\.\d{3}\.\d{3}\/\d{4}\-\d{2}$/;
        if (cnpj) {
            cnpj = cnpj.toString();
            if (cnpjPattern.test(cnpj)) {
                cnpj = cnpj.replace(/\D/g, "");
            }
            return cnpj === "00000000000000" ?  false : algoritmoCnpj(cnpj);
        } else {
            return true;
        }
    }

    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: validacaoCNPJ
     * @module arq-spa-base.validacoes
     * 
     * @description      
     * Responsável por realizar validação do campo de CNPJ
     */
    function validacaoCNPJ() {
        return {
            restrict: "E",
            require: "ngModel",
            scope: {ngModel:"=", valorComMascara:"&", valorSemMascara:"&"},
            template: "<input type=\"text\" ui-options=\"{clearOnBlur:false}\" ui-mask-placeholder ui-mask=\"99.999.999/9999-99\" ui-mask-placeholder-char=\"_\" valor-com-mascara=\"valorComMascara()\" valor-sem-mascara=\"valorSemMascara()\" />" ,
            replace: "true",
            link: function link(scope, ele, attrs, ngModelController) {
                
                ngModelController.$validators.cnpj = function(modelValue, viewValue)
                {
                    return validarCNPJ(viewValue);
                };
                
                scope.valorSemMascara = function(){
                    return scope.ngModel;
                };
                
                scope.valorComMascara = function(){
                    var resultado = "";
                    var posicaoModel = 0;
                    for(var i = 0; i < attrs.uiMask.length; i++){
                        if(attrs.uiMask.charAt(i) == "9"){
                            resultado += scope.ngModel.charAt(posicaoModel);
                            posicaoModel++;
                        }
                        else{
                            resultado += attrs.uiMask.charAt(i);
                        } 
                    }
                    return resultado;
                };
            }
        };
    }
    
    angular.module("arq-spa-base.validacoes").directive("sfCnpj", validacaoCNPJ);
    
})();
(function(){
    "use strict";
    
     /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: validacaoCodBarrasConcessionaria
     * @module arq-spa-base.validacoes
     * 
     * @description      
     * Responsável por realizar validação do campo de código de barras de concessionária
     */
    function validacaoCodBarrasConcessionaria() {
        return {
            restrict: "E",
            require: "ngModel",
            scope: {ngModel:"=", valorComMascara: "&", valorSemMascara: "&"},
            replace: "true",
            template: "<input type=\"text\" ui-options=\"{clearOnBlur:false}\"  ui-mask=\"99999999999-9 99999999999-9 99999999999-9 99999999999-9\" ui-mask-placeholder-char=\"_\" valor-com-mascara=\"valorComMascara()\" valor-sem-mascara=\"valorSemMascara()\"/>",
            link: function link(scope, ele, attrs) {
                
                scope.valorSemMascara = function(){
                    return scope.ngModel;
                };
                
                scope.valorComMascara = function(){
                    var resultado = "";
                    var posicaoModel = 0;
                    for(var i = 0; i < attrs.uiMask.length; i++){
                        if(attrs.uiMask.charAt(i) == "9"){
                            resultado += scope.ngModel.charAt(posicaoModel);
                            posicaoModel++;
                        }
                        else{
                            resultado += attrs.uiMask.charAt(i);
                        } 
                    }
                    return resultado;
                };
            }
        };
    }
    
    angular.module("arq-spa-base.validacoes").directive("sfCodBarrasConcessionaria", validacaoCodBarrasConcessionaria);
    
})();
(function(){
    "use strict";
    
     /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: validacaoCodBarrasTitulo
     * @module arq-spa-base.validacoes
     * 
     * @description      
     * Responsável por realizar validação do campo de código de barras de título bancário
     */
    function aplicarMascaraCodBarrasTitulo() {
        return {
            restrict: "E",
            require: "ngModel",
            scope: {ngModel:"=", valorComMascara: "&", valorSemMascara: "&"},
            replace: "true",
            template: "<input type=\"text\" ui-options=\"{clearOnBlur:false}\" ui-mask=\"99999.99999 99999.999999 99999.999999 9 99999999999999\" ui-mask-placeholder-char=\"_\" valor-com-mascara=\"valorComMascara()\" valor-sem-mascara=\"valorSemMascara()\" />",
            link: function link(scope, ele, attrs) {
                
                scope.valorSemMascara = function(){
                    return scope.ngModel;
                };
                
                scope.valorComMascara = function(){
                    var resultado = "";
                    var posicaoModel = 0;
                    for(var i = 0; i < attrs.uiMask.length; i++){
                        if(attrs.uiMask.charAt(i) == "9"){
                            resultado += scope.ngModel.charAt(posicaoModel);
                            posicaoModel++;
                        }
                        else{
                            resultado += attrs.uiMask.charAt(i);
                        } 
                    }
                    return resultado;
                };
            }
        };
    }
    
    angular.module("arq-spa-base.validacoes").directive("sfCodBarrasTitulo", aplicarMascaraCodBarrasTitulo);
    
})();
(function () {
    "use strict";

    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: validarConfirmacaoDados
     * @module arq-spa-base.validacoes
     *  
     * @description
     * Método responsável por verificar se o campo de confirmação é igual o campo informado anteriormente.
     */
    function validarConfirmacaoDados() {
        return {
            restrict: "A",
            require: "ngModel",
            scope: { 
                required: "@", sfConfirmacaoDados: "=" },
            link: link
        };

        /**
        * @ngdoc object
        * @name link
        * 
        * @description
        * Método responsável por verificar se o campo de confirmação é igual o campo informado anteriormente.
        */
        function link(scope, element, attrs, ngModelController) {
            element.on("cut paste", cancelarEvento);
            // element_.bind("click", eventoClick);

            scope.$watch(expressao, observacao);

            var destroy = scope.$on("$destroy", function () {
                element.off("cut paste");
                destroy();
            });

            // function eventoClick() {
            //     validarConfirmacaoDados.scope.required
                
            // }

            /**
            * @ngdoc object
            * @name expressao
            * 
            * @returns {boolean} Flag que indica se o modelValue está definido.
            * 
            * @description
            * Método responsável por verificar se a expressão está definida.
            */
            function expressao() {
                return attrs.required + scope.sfConfirmacaoDados + ngModelController.$modelValue;
            }

            /**
            * @ngdoc object
            * @name observacao
            * 
            * @returns {boolean} Flag que indica se o campoConfirmacao é igual ao modelValue.
            * 
            * @description
            * Método responsável por verificar se o campoConfirmacao é igual ao modelValue e retornar true ou false.
            */
            function observacao() {
                if (attrs.required || scope.sfConfirmacaoDados !== "") {
                    ngModelController.$setValidity("sfConfirmacaoDados", scope.sfConfirmacaoDados === ngModelController.$modelValue);
                }
            }

            /**
            * @ngdoc object
            * @name cancelarEvento
            *             * 
            * @description
            * Método responsável por cancelar um evento, o seja, a ação padrão que pertence ao evento não ocorrerá.
            */
            function cancelarEvento(event) {
                event.preventDefault();

            }
        }
    }
    angular.module("arq-spa-base.validacoes").directive("sfConfirmacaoDados", validarConfirmacaoDados);
})();
(function(){
    "use strict";
    
    /**
     * @ngdoc object
     * @name numerosIguais
     *
     * @param {string} string String que contém o valor de um cpf inserido pelo usuário
     * @returns {boolean} Booleano que indica se os caracteres da string são todos iguais ou não
     *
     * @description
     * Método responsável por verificar se uma determinada string possui todos caracteres iguais.
     */
    function numerosIguais(string) {
        var comp = string.length - 1;
        for (var i = 0; i < comp; i++){
            if(string.charAt(i) !== string.charAt(i + 1)){
                return false;
            }
        }
        return true;
    }
    
    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: validacaoCPF
     * @module arq-spa-base.validacoes
     * 
     * @description      
     * Responsável por realizar validação do campo de CPF
     */
    function validacaoCPF() {
        return {
            restrict: "E",
            //require: ["ngModel", "^?form"],
            require: "ngModel",
            scope: {ngModel:"=", valorComMascara:"&", valorSemMascara:"&"},
            replace: "true",
            template: "<input type=\"text\" ui-options=\"{clearOnBlur:false}\" ui-mask=\"999.999.999-99\" ui-mask-placeholder ui-mask-placeholder-char=\"_\" valor-com-mascara=\"valorComMascara()\" valor-sem-mascara=\"valorSemMascara()\"/>",
            link: function link(scope, ele, attrs, ngModelController) {
                ngModelController.$validators.cpf = function(modelValue, viewValue)
                {
                    return validarCPF(viewValue);
                };
                
                scope.valorSemMascara = function(){
                    return scope.ngModel;
                };
                
                scope.valorComMascara = function(){
                    var resultado = "";
                    var posicaoModel = 0;
                    for(var i = 0; i < attrs.uiMask.length; i++){
                        if(attrs.uiMask.charAt(i) == "9"){
                            resultado += scope.ngModel.charAt(posicaoModel);
                            posicaoModel++;
                        }
                        else{
                            resultado += attrs.uiMask.charAt(i);
                        } 
                    }
                    return resultado;
                };
            }
        };
    }
            
    /**
     * @ngdoc object
     * @name validarCPF
     * 
     * @param {string} strCPF String que contém o valor de um cpf inserido pelo usuário
     * @returns {boolean} Flag que indica se é um CPF válido ou não
     * 
     * @description
     * Método responsável por verificar se o cpf recebido é válido ou não.
     */
    function validarCPF (strCPF) {
        var cpfPattern = /^\d{3}\.\d{3}\.\d{3}\-\d{2}$/;
        if (strCPF) {
            strCPF = strCPF.toString();
            if (cpfPattern.test(strCPF)) {
                strCPF = strCPF.replace(/\D/g, "");
            }
            var cpfTamanho = strCPF.length;
            if (cpfTamanho === 11) {
                if (numerosIguais(strCPF)) {
                    return false;
                }
                var soma, resto;
                soma = 0;

                for (var i = 1; i <= 9; i++) {
                    soma = soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
                }
                resto = (soma * 10) % 11;
                if ((resto === 10) || (resto === 11)) {
                    resto = 0;
                }
                if (resto !== parseInt(strCPF.substring(9, 10))) {
                    return false;
                }
                soma = 0;
                for (var j = 1; j <= 10; j++) {
                    soma = soma + parseInt(strCPF.substring(j - 1, j)) * (12 - j);
                }
                resto = (soma * 10) % 11;
                if ((resto === 10) || (resto === 11)) {
                    resto = 0;
                }
                if (resto !== parseInt(strCPF.substring(10, 11))) {
                    return false;
                }
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return true;
        }
    }
    
    angular.module("arq-spa-base.validacoes").directive("sfCpf", validacaoCPF);
    
})();
(function(){
    "use strict";
    
    /**
     * @ngdoc object
     * @name ValidarDV10
     * 
     * @param {string} strDV10 String que contém o valor de um dígito verificador 10 inserido pelo usuário
     * @returns {boolean} Flag que indica se um dígito verificador 10 é válido ou não
     * 
     * @description
     * Método responsável por verificar se o dígito verificador 10 recebido é válido ou não.
     */
    function validarDV10(strDV10) {
        if(strDV10 == undefined)
        {
            return false;
        }
        var dado = strDV10.substring(0, strDV10.length - 1);
        var dv = strDV10.substring(strDV10.length - 1, strDV10.length);
        var soma = 0;
        var multiplicador = 1;
        var produto2 = 0;
        
        //Percorre os números da string, multiplicando-os por 1 e 2
        for(var char = 0; char < dado.length; char++){
            
            var produto1 = multiplicador * parseInt(dado.charAt(char));
            if(produto1.toString().length > 1){
                
                produto2 = 0;
                for(var caractereProduto = 0; caractereProduto < produto1.toString().length; caractereProduto++){
                   
                    produto2 = produto2 + parseInt(produto1.toString().charAt(caractereProduto));
                }    
            }
            else{
                produto2 = produto1;
            }
            
            soma = parseInt(soma) + parseInt(produto2);
            multiplicador = multiplicador == 1 ? 2 : 1;
        }
        
        //Calcula o resto da divisão da soma realizada por 10
        var resto = soma % 10;
        
        //Calcula o dígito subtraindo o resto de 10
        var digitoCalculado = 10 - resto;
                
        return digitoCalculado == dv;
    }

    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: ValidacaoDV10
     * @module arq-spa-base.validacoes
     * 
     * @description      
     * Responsável por realizar validação de dígito verificador 10
     */
    function validacaoDV10() {
        return {
            restrict: "A",
            require: "ngModel",
            scope: {ngModel:"="},
            replace: "true",
            link: function link(scope, ele, attrs, ngModelController) {
                ngModelController.$validators.validardv10 = function(modelValue, viewValue)
                {
                    return validarDV10(viewValue);
                };
            }
        };
    }
    
    angular.module("arq-spa-base.validacoes").directive("sfDv10", validacaoDV10);
    
})();
(function () {
    "use strict";

    /**
     * @ngdoc object
     * @name validarDV11
     * 
     * @param {string} strDV11 String que contém o valor de um dígito verificador 11 inserido pelo usuário
     * @returns {boolean} Flag que indica se um dígito verificador 11 é válido ou não
     * 
     * @description
     * Método responsável por verificar se o dígito verificador 11 recebido é válido ou não.
     */
    function validarDV11(strDV11) {
        if (strDV11 == undefined) { return false; }
        
        var dado = strDV11.substring(0, strDV11.length - 1);
        var dv = strDV11.substring(strDV11.length - 1, strDV11.length);
        var soma = 0;

        //Base de multiplicação (subtraída sucessivamente)
        var multiplicador = strDV11.length;

        //Percorre os números da string, multiplicando-os pelo valor do multiplicador
        for (var char = 0; char < dado.length; char++) {
            var produto = multiplicador * parseInt(dado.charAt(char));
            soma = parseInt(soma) + parseInt(produto);
            multiplicador--;
        }

        //Calcula o resto da divisão da soma realizada por 11
        var resto = soma % 11;

        //Calcula o dígito subtraindo o resto de 11
        var digitoCalculado = 11 - resto;
        
        return digitoCalculado == dv;
    }

    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: validacaoDV11
     * @module arq-spa-base.validacoes
     * 
     * @description      
     * Responsável por realizar validação de dígito verificador 11
     */
    function validacaoDV11() {
        return {
            restrict: "A",
            require: "ngModel",
            scope: { ngModel: "=" },
            replace: "true",
            link: function link(scope, ele, attrs, ngModelController) {
                ngModelController.$validators.validardv11 = function(modelValue, viewValue)
                {
                    return validarDV11(viewValue);
                };
            }
        };
    }

    angular.module("arq-spa-base.validacoes").directive("sfDv11", validacaoDV11);

})();
(function(){
    "use strict";
    
    /**
     * @ngdoc object
     * @name validarDV13
     * 
     * @param {string} strDV13 String que contém o valor de um dígito verificador 13 inserido pelo usuário
     * @returns {boolean} Flag que indica se um dígito verificador 13 é válido ou não
     * 
     * @description
     * Método responsável por verificar se o dígito verificador 13 recebido é válido ou não.
     */
    function validarDV13(strDV13) {
        if (strDV13 == undefined) { return false; }
        var dado = strDV13.substring(0, strDV13.length - 1);
        var dv = strDV13.substring(strDV13.length - 1, strDV13.length);
        var produto = 0;
        
        var somaPar = 0;
        var somaImpar = 0;
        
        //Percorre os números da string, multiplicando-os por 1 e 2
        for(var char = 0; char < dado.length; char++){
            if((char + 1) % 2 != 0){
                somaImpar = somaImpar + parseInt(dado.charAt(char));
            }
            else{
                somaPar = somaPar + parseInt(dado.charAt(char));
            }
        }
        
        somaPar = somaPar * 3;
        
        produto = somaPar + somaImpar;
        var multiplo10 = produto;
        
        while(multiplo10 % 10 != 0){
            multiplo10++;
        }
         
        var resultado = multiplo10 - produto;
                
        return resultado == dv;
    }

    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: ValidacaoDV13
     * @module arq-spa-base.validacoes
     * 
     * @description      
     * Responsável por realizar validação de dígito verificador 13
     */
    function validacaoDV13() {
        return {
            restrict: "A",
            require: "ngModel",
            scope: {ngModel:"="},
            replace: "true",
            link: function link(scope, ele, attrs, ngModelController) {
                ngModelController.$validators.validardv13 = function(modelValue, viewValue)
                {
                    return validarDV13(viewValue);
                };
            }
        };
    }
    
    angular.module("arq-spa-base.validacoes").directive("sfDv13", validacaoDV13);
    
})();
(function () {
    "use strict";

    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: ValidacaoAnoBissexto
     * @module arq-spa-base.validacoes
     *  
     * @description
     * Método responsável por verificar se o e-mail informado é valido.
     */
    function validarEmail() {
        return {
            restrict: "A",
            require: "ngModel",
            scope: { ngModel: "=" },
            replace: "true",
            link: function link(scope, element, attrs, ngModelController) {

                ngModelController.$validators.email = function (modelValue, viewValue) {
                    var reg = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
                    return reg.test(viewValue);
                };
            }
        };
    }
    angular.module("arq-spa-base.validacoes").directive("sfEmail", validarEmail);
})();
(function(){
    "use strict";
    
    /**
     * @ngdoc directive
     * @name arq-spa-base.validacoes: ValidacaoNumCartao
     * @module arq-spa-base.validacoes
     * 
     * @description      
     * Responsável por realizar validação e aplicação de máscara do campo de número de cartão
     */
    function aplicarMascaraNumCartao() {
        return {
            restrict: "E",
            require: "ngModel",
            scope: {ngModel:"=", valorComMascara: "&", valorSemMascara: "&"},
            replace: "true",
            template: "<input type=\"text\" ui-options=\"{clearOnBlur:false}\" ui-mask=\"9999.9999.9999.9999\" ui-mask-placeholder-char=\"_\" valor-com-mascara=\"valorComMascara()\" valor-sem-mascara=\"valorSemMascara()\"/>",
            link: function (scope, ele, attrs) {
                
                scope.valorSemMascara = function(){
                    return scope.ngModel;
                };
                
                scope.valorComMascara = function(){
                    var resultado = "";
                    var posicaoModel = 0;
                    for(var i = 0; i < attrs.uiMask.length; i++){
                        if(attrs.uiMask.charAt(i) == "9"){
                            resultado += scope.ngModel.charAt(posicaoModel);
                            posicaoModel++;
                        }
                        else{
                            resultado += attrs.uiMask.charAt(i);
                        } 
                    }
                    return resultado;
                };
            }
        };
    }
    
    angular.module("arq-spa-base.validacoes").directive("sfNumeroCartao", aplicarMascaraNumCartao);
    
})();
(function () {
    "use strict";
    /**
     * @ngdoc overview
     * @name arq-spa-base
     * 
     * @requires arq-spa-base.navegacao
     * 
     * @description
     * Módulo principal dos componentes de arquitetura base que provê os recursos necessários para criação de aplicações SPA em angular para o banco Safra.
     */
    angular.module("arq-spa-base", [
        "angular-jwt",
        "angulartics",
        "angulartics.google.analytics",
        "ui.bootstrap",
        "arq-spa-base.autenticacao",
        "arq-spa-base.comunicacao",
        "arq-spa-base.configuracao",
        "arq-spa-base.controles-visuais",
        "arq-spa-base.criptografia",
        "arq-spa-base.excecao",
        "arq-spa-base.filtros",
        "arq-spa-base.gerenciadorArquivos",
        "arq-spa-base.logging",
        "arq-spa-base.mensagens",
        "arq-spa-base.navegacao",
        "arq-spa-base.personalizacao",
        "arq-spa-base.recursos",
        "arq-spa-base.validacoes",
        "arq-spa-base.tabelas-gerais",
        "angularMoment",
        "duScroll",
        "LocalStorageModule",
        "ngAnimate",
        "ngAria",
        "ngFileUpload",
        "ngFileSaver",
        "ngSanitize",
        "ngTouch",
        "oc.lazyLoad",
        "pascalprecht.translate",
        "ui.bootstrap",
        "ui.mask",
        "ui.router",
        "ui.tree"
    ]).config(configurar).run(executar);

    configurar.$inject = ["configuradorAplicacaoProvider"];
    executar.$inject = ["configuradorAplicacao"];

    /**
     * @ngdoc overview
     * @name arq-spa-base
     * 
     * @requires arq-spa-base.navegacao
     * 
     * @description
     * Função para configurar a aplicação.
     */
    function configurar(configuradorAplicacaoProvider) {
        
        configuradorAplicacaoProvider.configurarModuloPrincipal();
    }

    /**
     * @ngdoc overview
     * @name arq-spa-base
     * 
     * @requires arq-spa-base.navegacao
     * 
     * @description
     * Função para executar a aplicação.
     */
    function executar(configuradorAplicacao) {
        configuradorAplicacao.executarModuloPrincipal();
    }
})();