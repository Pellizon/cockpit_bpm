(function () {
    "use strict";

    /**
     * @ngdoc overview
     * @name arq-spa-base.recursos.constants:app.config
     * @module arq-spa-base.recursos
     *
     * @description
     * Constantes que armazenam as configurações da aplicação.
     */
    angular.module("arq-spa-base.recursos").constant("appSettings", {
        configuracao: {
            caminhoArquivoConfigContexto: "./app/assets/config/contexto.json",
            caminhoCatalogoDependencias: "./app/assets/config/dependencias.json",
            caminhoArquivosModulos: "./app/assets/js/",
            caminhoDefinicoesFiltros: "./app/assets/config/filtros.json",
            caminhoCatalagoInternacionalizacao: "./app/assets/config/internacionalizacoes.json",
            aplicacao: "CKP",
            memorizador: {
                expiracao: 0
            },
            tratamentoExcecao: {
                servico: "tratamentoExcecao",
                funcao: "tratarErroGeral"
            },
            criptografia: {
                habilitada: false,
                numeroMaximoTentativas: 2
            },
            padraoLogarInformativo: false,
            limparContextoTrabalhoLogoff: true,
            localizacao: {
                timezone: "America/Sao_Paulo",
                local: "pt-br"
            },
            seguranca: {
                urlWhiteList: []
            }
        },
        comunicacao: {            
            urlBackend: "https://api-bi-ti.safra.com.br/ckp",
            urlLog: "https://apiext-bi-ti.safra.com.br/log",
            timeoutPadrao: 600000000
        },
        navegacao: {
            fluxoInicial: "ckp-login",
            timeoutPadrao: 600000000
        },
        tipoSpinner: {
            loader: {
                color: "gray"
            },
            spinner: {
                elementHeight: "5px",
                elementWidth: "5px"
            }
        },
        aplicacao: {
            deslogarErroGeral: false,
            exibirErrosModal: false 
        }
    });
}());
